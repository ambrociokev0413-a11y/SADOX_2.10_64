# Stage 1 — What must be ported before a real SDX replacement exists

## Available now

- Original ARM32 `libSDX.so` binary and its exported symbols.
- Readable `~~CScripts~~Initialise.txt`, compiled `.x` scripts, `function.bin`, and `ScriptCommands.hash` from the SA_DOX Ultra preset.
- The sample GTA SA Android 2.10 AArch64 `libGTASA.so` symbol table (16 key SDX-referenced symbols were verified).
- AML 1.4.1 interface headers and the GTA SA PSDK headers with 2.10 / AArch64 declarations.
- A PSDK `sautils_2_10_x64.cpp` reference implementation.

## Still missing or not yet reconstructed

1. The C++ source corresponding to the original native `onSDXLoad` routine. The original binary is stripped, and the native implementation must be reconstructed from disassembly and observed behavior.
2. The custom helper headers referenced by the old PSDK integration source (`AArch64_ModHelper/ARMv8_ASMHelper.h` and `GTASA_STRUCTS_210.h`). They are not present in the supplied ZIPs. This package includes the modern PSDK header tree as an alternative reference, but the old source file does not compile standalone.
3. A compiler/rebuild path for the existing `.x` files, or proof that the target 64-bit script VM can consume them without recompilation.
4. A full mapping of each legacy patch operation to an AArch64-safe hook, symbol or data interface. The patch inventory is provided as a line-by-line starting point.
5. Runtime logs from the target device to validate load order, symbol resolution, save/resume and graphics initialization.

## Do not do yet

- Do not rename `libSDX_ARM64_AUDIT.so` to `libSDX.so` and install it as the replacement. It only probes AML and exports.
- Do not execute legacy ARM32 `ARM.memprotect2` or `longPatch` sequences in the 64-bit process.
- Do not apply sample offsets to a different build of `libGTASA.so` without checking its symbol map/fingerprint.
