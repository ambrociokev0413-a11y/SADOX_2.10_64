# SA_DOX 2.0 preset — missing source dependencies

The supplied Ultra preset contains many assets and the direct script binaries, but the readable `~~CScripts~~Initialise.txt` is not a complete source tree.

## Missing script includes

- `../SAAdox.h`
- `../OpenGL.h`
- `../menu.h`

## Missing referenced files

- `SAAdox/data/script/include/ARMLabel.bin`
- `SAAdox/data/script/include/arm64.bin`
- `SAAdox/data/script/include/string.hash`
- `SAAdox/data/script/~~CProcess~~Entity.x`
- `SAAdox/data/script/~~CProcess~~Object.x`
- `SAAdox/data/script/~~CProcess~~Ped.x`
- `SAAdox/data/script/~~CProcess~~Vehicle.x`
- `SAAdox/data/script/~~CSprites~~Loadfromfile.x`
- menu images under `SAAdox/Tx/menu/` (apply, checkbox, close, decrease, increase)

Some source literals use `SAAdox/`, while the uploaded preset directory is `SA_DOX/`. Android paths are case-sensitive; do not silently assume this mismatch is harmless.

The native ARM32 binary directly embeds only three SDX paths: `Initialise.x`, `Main.x`, and `function.bin`. Their presence does not prove that all scripts can run in an AArch64 script VM. The absent files matter to rebuilding the script package from text source.
