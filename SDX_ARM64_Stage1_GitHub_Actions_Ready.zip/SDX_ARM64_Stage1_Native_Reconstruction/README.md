# SDX ARM64 — Stage 1 Native Reconstruction

This is the next engineering package after Stage 0. It contains the Stage 1 AML source, copied SDK/resource references, a native reverse-engineering report, the original ARM32 Thumb disassembly, and a symbol report for the supplied GTA SA ARM64 library.

## Important status

**This is not a finished SDX replacement and it does not include a built `.so`.** The source is a diagnostic bootstrap that resolves the original SDX native dependencies through AML and logs whether the supplied 2.10 sample's symbols are present. It does not perform memory writes, hook game functions, load the custom script VM, or render SDX effects yet.

Do not rename `libSDX_ARM64_STAGE1.so` and replace the original `libSDX.so` with it.

## Build

1. Install Android NDK with `ndk-build`.
2. Set `ANDROID_NDK_HOME` to the NDK root directory.
3. Run:

```bash
./tools/build_arm64.sh
```

4. Expected diagnostic output:

```text
out/libs/arm64-v8a/libSDX_ARM64_STAGE1.so
```

## Stage 1 objective

Establish an AArch64-safe native dependency layer before porting any rendering hook. The report explains how original `OnModLoad` and `onSDXLoad` work, why the 32-bit ARMHook cannot be reused, and which custom SA_DOX script dependencies are absent from the uploaded preset.

## Next stage

Stage 2 should implement a minimal reversible AArch64 hook only after the Stage 1 module has been built and its AML log has confirmed the exact target game's 16/16 symbols and expected sample offsets. Rendering, script VM modifications, and the original `putFunction` equivalents remain disabled until independently ported and tested.
