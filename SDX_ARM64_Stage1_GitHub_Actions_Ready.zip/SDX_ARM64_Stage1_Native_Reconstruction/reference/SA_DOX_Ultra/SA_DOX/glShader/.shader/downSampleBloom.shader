<vert>
#version 300 es
precision highp float;
layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 TexCoord;

out vec2 vTexCoord;
out vec2 vpos;

void main() {    
	gl_Position = vec4(Position, 0.0, 1.0);
	
	vpos = Position;
	vTexCoord = Position * 0.5 + 0.5;
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform highp sampler2D Diffuse;
uniform vec2 canvasData;
in vec2 vTexCoord;
layout (location = 0) out vec4 fragColor;

vec3 texsample(sampler2D tex, vec2 texCoord){
	if(texCoord.x > 1.0 || texCoord.y > 1.0 || texCoord.x < 0.0 || texCoord.y < 0.0)
		return vec3(0.0, 0.0, 0.0);
		
	return textureLod(tex, texCoord, 0.0).rgb;
}

void main()
{
	vec2 srcTexelSize = vec2(1.0) / canvasData;
    float x = srcTexelSize.x * 2.0;
    float y = srcTexelSize.y * 2.0;
    float range = 2.0;

    vec2 texCoord = vTexCoord;
    vec3 a = texsample(Diffuse, vec2(texCoord.x - range *x, texCoord.y + range *y));
    vec3 b = texsample(Diffuse, vec2(texCoord.x,       texCoord.y + range *y));
    vec3 c = texsample(Diffuse, vec2(texCoord.x + range *x, texCoord.y + range *y));

    vec3 d = texsample(Diffuse, vec2(texCoord.x - range *x, texCoord.y));
    vec3 e = texsample(Diffuse, vec2(texCoord.x,       texCoord.y));
    vec3 f = texsample(Diffuse, vec2(texCoord.x + range *x, texCoord.y));

    vec3 g = texsample(Diffuse, vec2(texCoord.x - range *x, texCoord.y - range *y));
    vec3 h = texsample(Diffuse, vec2(texCoord.x,       texCoord.y - range *y));
    vec3 i = texsample(Diffuse, vec2(texCoord.x + range *x, texCoord.y - range *y));

    vec3 j = texsample(Diffuse, vec2(texCoord.x - x, texCoord.y + y));
    vec3 k = texsample(Diffuse, vec2(texCoord.x + x, texCoord.y + y));
    vec3 l = texsample(Diffuse, vec2(texCoord.x - x, texCoord.y - y));
    vec3 m = texsample(Diffuse, vec2(texCoord.x + x, texCoord.y - y));
    
	vec3 downsample = e*0.125;
    downsample += (a+c+g+i)*0.03125;
    downsample += (b+d+f+h)*0.0625;
    downsample += (j+k+l+m)*0.125;
    fragColor = vec4(downsample, 1.0);
}

</frag>