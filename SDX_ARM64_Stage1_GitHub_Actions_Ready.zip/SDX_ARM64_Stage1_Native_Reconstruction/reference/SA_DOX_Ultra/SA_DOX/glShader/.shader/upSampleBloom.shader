<vert>
#version 300 es
precision highp float;
layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 TexCoord;

out vec2 vTexCoord;
out vec2 vpos;

void main() {    
	gl_Position = vec4(Position, 0.0, 1.0);
	
	vpos = Position;
	vTexCoord = Position * 0.5 + 0.5;
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform highp sampler2D DownSampleBloom1;
uniform highp sampler2D DownSampleBloom2;
uniform highp sampler2D DownSampleBloom3;
uniform highp sampler2D DownSampleBloom4;
uniform highp sampler2D DownSampleBloom5;
uniform vec2 canvasData;
in vec2 vTexCoord;
layout (location = 0) out vec4 fragColor;

vec3 texsample(sampler2D tex, vec2 texCoord){
	if(texCoord.x > 1.0 || texCoord.y > 1.0 || texCoord.x < 0.0 || texCoord.y < 0.0)
		return vec3(0.0, 0.0, 0.0);
		
	return textureLod(tex, texCoord, 0.0).rgb;
}

vec3 upSample(sampler2D tex) {
	float filterRadius = 0.012;
	float x = filterRadius;
    float y = filterRadius;
    
	vec2 texCoord = vTexCoord;
    vec3 a = texsample(tex, vec2(texCoord.x - x, texCoord.y + y)).rgb;
    vec3 b = texsample(tex, vec2(texCoord.x,     texCoord.y + y)).rgb;
    vec3 c = texsample(tex, vec2(texCoord.x + x, texCoord.y + y)).rgb;

    vec3 d = texsample(tex, vec2(texCoord.x - x, texCoord.y)).rgb;
    vec3 e = texsample(tex, vec2(texCoord.x,     texCoord.y)).rgb;
    vec3 f = texsample(tex, vec2(texCoord.x + x, texCoord.y)).rgb;

    vec3 g = texsample(tex, vec2(texCoord.x - x, texCoord.y - y)).rgb;
    vec3 h = texsample(tex, vec2(texCoord.x,     texCoord.y - y)).rgb;
    vec3 i = texsample(tex, vec2(texCoord.x + x, texCoord.y - y)).rgb;
	vec3 upsample = e*4.0;
    upsample += (b+d+f+h)*2.0;
    upsample += (a+c+g+i);
    upsample *= 1.0 / 16.0;
    return upsample;
}

void main()
{
	vec3 color = upSample(DownSampleBloom1);
		color += upSample(DownSampleBloom2) * 1.1;
		color += upSample(DownSampleBloom3) * 1.1;
		color += upSample(DownSampleBloom4) * 1.1;
		color += upSample(DownSampleBloom5) * 1.1;
		color.rgb /= 5.0;
	fragColor = vec4(color, 1.0);
}

</frag>