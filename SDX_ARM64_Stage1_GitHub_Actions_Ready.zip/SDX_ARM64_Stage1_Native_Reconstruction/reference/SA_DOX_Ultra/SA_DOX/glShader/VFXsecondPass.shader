<vert>
#version 300 es
precision highp float;
layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 TexCoord;

uniform vec3 CameraPosition;

out vec3 campos;
out vec2 vTexCoord;
out vec2 vpos;
out vec4 interpolatorA;
out vec4 interpolatorB;
out vec4 interpolatorC;

void main() {    
	gl_Position = vec4(Position, 0.0, 1.0);
	
	campos = CameraPosition;
	vpos = Position;
	vTexCoord = Position * 0.5 + 0.5;
	
	vec2 texel = vec2(0.0009765625,0.00130208333333333333333333333333);
	texel *= 2.0;
	vec4 extents;
	vec2 offset = ( texel.xy ) * 0.215;
	extents.xy = vTexCoord.xy - offset;
	extents.zw = vTexCoord.xy + offset;
	
	vec4 rcpSize;
	rcpSize.xy = -texel.xy * 0.5;
	rcpSize.zw = texel.xy * 0.7;			
	
	interpolatorA = extents;
	interpolatorB = rcpSize;
	interpolatorC = rcpSize;
	
	interpolatorC.xy *= 0.0;
	interpolatorC.zw *= 0.0;
	
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform highp sampler2D Diffuse,
											GodRay,
											BloomMap,
											componentMap,
											DepthMap,
											SamplerMask;

sampler2D SamplerNoise = texture_load { texture = "enbnoise.png"; } 
sampler2D SamplerRain = texture_load { texture = "Rain.png"; } 
sampler2D SamplerRain2 = texture_load { texture = "Rain2.png"; } 
	
uniform mat4 invProjMatrix;
uniform mat4 PreviousProjMatrix;
uniform mat4 PreviousViewMatrix;
uniform mat4 ProjMatrix; uniform mat4 ViewMatrix; uniform mat4 invViewMatrix; uniform mat4 invVPMatrix; uniform mat4 VPMatrix;

uniform vec2 canvasData;
uniform mediump vec4 RedGrade;
uniform mediump vec4 GreenGrade;
uniform mediump vec4 BlueGrade;
uniform vec2 DetailTiling;
uniform float TimeMS;
uniform vec4 TouchScreenPos;
uniform vec4 RainValue;
uniform vec3 prevCameraPosition;
uniform vec2 sunPosition;
uniform vec3 sunColor;

// godrays
@bool isGodRayEnable_menu < class = "GodRays", name = "enable", default = true; >
@float godRaysIntentsity < class = "GodRays", name = "intensity", default = 1.0; >



// DOF
@bool isDOF < class = "DOF", name = "enable", default = false; >
@float near_plane < class = "DOF", name = "near_plane", default = 0.0; >
@float far_plane < class = "DOF", name = "far_plane", default = 0.0; >
@float blur_radius < class = "DOF", name = "blur_radius", default = 0.0; >
@bool isMotionBlur < class = "main", name = "Motion_Blur", default = false; >
@float Motion_Blur_Density < class = "main", name = "Motion_Blur_Density", default = 0.5; >

in vec3 campos;
in vec2 vTexCoord;
in vec2 vpos;
in vec4 interpolatorA;
in vec4 interpolatorB;
in vec4 interpolatorC;
	

layout (location = 0) out vec4 fragColor;

#include "function.shader";

vec3 LinearToSrgb(vec3 color) { return mix(1.055 * pow(color, vec3(1.0 / 2.4)) - 0.055, color * 12.92, step(color, vec3(0.0031308))); }
vec2 rand(vec2 c){ mat2 m = mat2(12.9898,.16180,78.233,.31415); return fract(sin(m * c) * vec2(43758.5453, 14142.1)); }

#include "posFunction.shader";

vec4 rainFx() {
    float iTime = (TimeMS / 1000.0) * 0.4;
    vec2 c = vTexCoord;
    vec2 uv = vTexCoord;
    vec2 iResolution = canvasData;
	vec2 u = vTexCoord,
         v = (c*.1),
         n = texture(SamplerNoise, uv *1.48).rg; // Displacement
    
    vec4 f = vec4(0.0);
    
    // Loop through the different inverse sizes of drops
    for (float r = 4. ; r > 0. ; r--) {
        vec2 x = vec2(4500.0 * r * 0.015),  // Number of potential drops (in a grid)
             p = 6.28 * u * x + (n - .5) * 2.,
             s = sin(p);
        
        vec4 d = texture(SamplerNoise, round(uv * x - 0.5) / x);
        
        // Drop shape and fading
        float t = (s.x+s.y) * max(0., 1. - fract(iTime * (d.b + .1) + d.g) * 2.);
        
        // d.r -> only x% of drops are kept on, with x depending on the size of drops
        if (d.r < (4.0-r) *.08 && t > .027) {
            // Drop normal
            vec3 v = normalize(-vec3(cos(p), mix(.2, 2., t-.5)));
            // fragColor = vec4(v * 0.5 + 0.5, 1.0);  // show normals
            
            // Poor man's refraction (no visual need to do more)
            f = texture(Diffuse, u - v.xy * .3);
            break;
        }
    }
    return f;
}


float Rain0(in vec2 cd)
{	
    vec2 uv = cd.yx;
	vec2 p = uv / 10.0;
	float r = textureLod(SamplerRain2, p * vec2(10.0, 2.0), 0.0).r;
	return r;
}

float Rain1(in vec2 cd)
{	
    vec2 uv = cd.yx;
	vec2 p = uv / 1.2;
	float r = textureLod(SamplerRain, p * vec2(3.5, 0.3), 0.0).r;	
	return r;
}

float Rain2(in vec2 cd)
{	
    vec2 uv = cd.yx;
	vec2 p = uv / 0.5;
	float r = textureLod(SamplerRain, p * vec2(3.0, 0.5), 0.0).r;
	float r2 = textureLod(SamplerRain2, p * vec2(2.0, 0.5), 0.0).r;
	float j = (r + r2);
	return j;
}

vec3 PS_Rain(vec3 worldpos, vec2 coord, vec3 color, float depth)
{	
	vec3 dir = normalize(worldpos.xyz);
	
	float wpos = length(vec3(worldpos.xy + (campos.xy * 2.0), depth));
	
	
	mat3x3 vec = mat3x3(1.0 , 0.0, 0.0, 0.0, cos(0.25), sin(0.25), 0.0, -sin(0.25), cos(0.25));				   
	vec3 rp = dir * vec;		

	vec2 f0 = vec2(acos(rp.z),atan(rp.x/rp.y));		  
	vec2 time = vec2(TimeMS / 1000.0 , 0.0); 

	float raindx0 = Rain0(-f0.xy + time * 2.7);
	float raindx2 = Rain2(-f0.xy + time * 0.35);
   
	float rd0 = depth;
	float rd2 = depth < 0.999 ?  0.0 : depth;		   
	
	float dr0 = rd0 * raindx0;
	float dr2 = rd2 * raindx2;
	
	vec2 uv0 = vTexCoord.xy - raindx2 * vec2(0.0, -0.07);
	vec2 uv2 = vTexCoord.xy-raindx0*vec2(0.0, -0.11);
	
	if(rayIsOutofScreen(uv0)) 
		uv0 = vTexCoord.xy;
	
	if(rayIsOutofScreen(uv2))
		uv2 = vTexCoord.xy;
		
	vec3 rn0 = texture(Diffuse, uv0).rgb;
	vec3 rn2 = texture(Diffuse, uv2).rgb;
	   
	float ws = RainValue[0] * 0.7;

	color.xyz = mix(color.xyz, 1.23 * rn0 + 0.022, ws * dr2);		 
	color.xyz = mix(color.xyz, 1.33 * rn2 + 0.024, ws * dr0);		
		
	return vec3(color.rgb);
}

#define IterSize 64
#define GoldenAngle 2.399996 // rad

mat2 rot(float a)
{
    float c = cos(a);
    float s = sin(a);
    return mat2(c, s, -s, c);
}

vec3 bokeh(in sampler2D tex, in vec2 uv, in vec2 pixelsize, in float radius)
{
    vec3 total = vec3(0.);
    vec3 divsor = vec3(0.);
    float r = 1.;
    mat2 G = rot(GoldenAngle);
    vec2 offset = vec2(radius, 0.);
    for (int i = 0; i < IterSize; ++i) {
        r += 1./r;
        offset = G * offset;
        if(!rayIsOutofScreen(uv + offset * (r - 1.) * pixelsize)){
        	vec3 col = texture(tex, uv + offset * (r - 1.) * pixelsize).rgb;
        	vec3 bokeh = pow(col, vec3(4.));
        	total += col * bokeh;
        	divsor += bokeh;
		}
    }
    return total / divsor;
}

// func masking
	bool isMaskBuilding(float mask) { 
		if(mask >= 0.0 && mask < 0.2) return true; else return false;
	}

	bool isMaskPed(float mask) { 
		if(mask >= 0.2-0.01 && mask < 0.4) return true; else return false;
	}

	bool isMaskVehicle(float mask) { 
		if(mask >= 0.4-0.01 && mask < 0.6) return true; else return false;
	}

	bool isMaskWater(float mask) { 
		if(mask >= 0.6-0.01 && mask < 0.8) return true; else return false;
	}
	
	bool isMaskEffect(float mask) { 
		if(mask >= 0.8-0.01 && mask < 1.0) return true; else return false;
	}
	
	float getMaskCoefficient(float mask){
		
		float coeff = 0.0;
		
		if(isMaskBuilding(mask))
			coeff = mask * 10.0;
		else
			if(isMaskPed(mask))
				coeff = (mask-0.2) * 10.0;
			else
				if(isMaskVehicle(mask))
					coeff = (mask-0.4) * 10.0;
				else
					if(isMaskWater(mask))
						coeff = (mask-0.6) * 10.0;
					else
						if(isMaskEffect(mask))
							coeff = (mask-0.8) * 10.0;
							
		return clamp(coeff, 0.0, 1.0);
	}

void main()
{
	float curDepth = texture(DepthMap, vTexCoord).r;
	float mask = textureLod(componentMap, vTexCoord, 0.0).r;

	
	vec3 worldpos = GWP(vTexCoord, curDepth).xyz;
	vec3 color;
	
	/*
	float c = texture(DepthMap, vTexCoord).r;
	float s = texture(DepthMap, vec2(TouchScreenPos.x, 1.0 - TouchScreenPos.y)).r;
	float dens = 0.0025;
	
	if(c > s && TouchScreenPos.x != 0.0) {
		fragColor.rgb = bokeh(Diffuse, vTexCoord, vec2(1.0) / vec2(textureSize(Diffuse, 0)), (c - s) * 7.5);
		fragColor.a = 1.0;
	} else {
		fragColor = texture(Diffuse, vTexCoord);
	}*/
	color = texture(Diffuse, vTexCoord).rgb;
	if(isDOF)
	{
		float LinearDepth = 2.0 / ((800.0 - 1.0) + 2.0 - curDepth * (800.0 - 1.0));
		if(LinearDepth > near_plane || LinearDepth < far_plane){
			color = vec3(0.0);
			for(float x = -1.0; x <= 1.0; x += 1.0)
			{
				for(float y = -1.0; y <= 1.0; y += 1.0)
					color += texture(Diffuse, vTexCoord + vec2(x, y) * blur_radius).rgb;
			}
			color /= 9.0;
		}
	}
	
	if(isMotionBlur && !isMaskVehicle(mask))
	{
		// motion blur
		vec4 H = vec4(vTexCoord.x * 2.0 - 1.0, (1.0 - vTexCoord.y) * 2.0 - 1.0,  curDepth, 1.0);

		vec4 rul = invProjMatrix * H; 
		vec4 viewVectors = invViewMatrix[0] * rul.x + invViewMatrix[1] * rul.y + invViewMatrix[2] * rul.z;
		viewVectors /= rul.w;
		viewVectors.xyz += (campos - prevCameraPosition);
	
		vec4 a = PreviousViewMatrix[0] * viewVectors.x + PreviousViewMatrix[1] * viewVectors.y + PreviousViewMatrix[2] * viewVectors.z;
		vec4 b = PreviousProjMatrix[0] * a.x + PreviousProjMatrix[1] * a.y + PreviousProjMatrix[2] * a.z;
		b.rgb /= b.w;
		//b = b * 0.5 + 0.5;

		vec2 velocity = (H.xy - b.xy) / ((1.0-Motion_Blur_Density)*20.0);
	
		if(abs(velocity.x) > 0.00001 || abs(velocity.y) > 0.00001){
			vec3 coloru = color;
			vec2 texCoord = vTexCoord + velocity;
	
			int numSamples = 4;
			int i = 1;
			for (; i < numSamples; i++) {
				if(rayIsOutofScreen(texCoord)) { break; }
				coloru += texture(Diffuse, texCoord).rgb;
				texCoord += velocity;
			}
			color = coloru / float(i);
		}
	}
	
	
	if(isGodRayEnable_menu)
        color.rgb += texture(GodRay, vTexCoord).rgb * godRaysIntentsity;
 
    if(RainValue[0] > 0.0){        
        color = PS_Rain(worldpos, vTexCoord, color, curDepth);
        vec4 raintex = rainFx();
        color.rgb = mix(color, raintex.rgb, raintex.a * RainValue[0]);
    }
	
	vec4 bloom = texture(BloomMap, vTexCoord);
    color.rgb += bloom.rgb;
    
	fragColor = vec4(color, 1.0);
		
}

</frag>