float PS_AO(vec3 worldpos, float curDepth, vec3 normal)
{
	//==================================================================
	float2 coord = vTexCoord;	
	if(curDepth >= 0.999) { return 1.0; }
	
	//==================================================================
    float  d0 = curDepth;  
    float LinDepth = 1.0 * 0.05 / (1.0 + d0 * (0.05 - 1.0));	

    float3 pos = worldpos;	
    float3 n2 = normal;   
	
	float2 uv;
	float ao = 0.0;
	float sr = -2.5;
	float SSAO = 14.0;
    float d = 0.25 * 1.5 / (SSAO * (n2.z + sr));
		
	float2 dir;
	sincos(42.528, dir.x, dir.y);
	dir *= d;

	float radius = LinDepth;	
	float AO_Radius = 1.0 * LinDepth;
	AO_Radius  = 1.0 - AO_Radius;
	AO_Radius = min(AO_Radius, 0.14);
	
    radius = lerp(0.7*AO_Radius, 0.16*AO_Radius, radius);

	for (float dx = 1.0; dx < SSAO; dx += 1.0)	
	{ 	
		uv = coord.xy + (dir.xy * dx / 0.5) * radius;				   		   
		if(uv.x > 1.0 || uv.x < 0.0 || uv.y > 1.0 || uv.y < 0.0)
			break;
		
		float4 nwp = wPos(uv);
		
		float3 occlusion_vector = normalize(nwp.xyz - pos);
		float dist = sqrt(occlusion_vector.x*occlusion_vector.x+occlusion_vector.y*occlusion_vector.y+occlusion_vector.z*occlusion_vector.z);
		occlusion_vector *= 2.;
		
		float AO = saturate(-n2.x*occlusion_vector.x-n2.y*occlusion_vector.y-n2.z*occlusion_vector.z);
			ao += 3.0 * (AO * (1.0 - saturate(dist / 2.0))) * clamp(1.0 - abs(nwp.w-curDepth) * 100.0, 0.0, 1.0);
			
		dir.xy = dir.xy * mat2x2(0.76465, -0.64444, 0.64444, 0.76465);
	}

	return pow(1.0 - pow(ao / SSAO, 1.0)*SSAO_density, 2.0);
}