vec3 spotLight(float3 fragPos, float3 normal) {
	if(!isLightCast)
		return vec3(0.0);
		
	if(SpotLights_num > 0) {
	
		vec3 color = vec3(0.0, 0.0, 0.0);
		float cosrad = cos(radians(1.0));
		
		for(int i = 0; i < SpotLights_num * 4; i += 4)
		{
			vec3 lightToPixel1 = normalize(fragPos - CSpotLights[i] * 2.0);
			float SpotFactor1 = dot(lightToPixel1, CSpotLights[i+1].xyz) * 4.0;
			if(SpotFactor1 > cosrad) {
				float dotDirLight = clamp(normal.x*lightToPixel1.x+normal.y*lightToPixel1.y+normal.z*lightToPixel1.z, 0.0, 1.0);
				float dist1 = pow(distance(fragPos, CSpotLights[i] * 2.0), 2.0);
				float spotIntensity1 = (1.0 - (1.0 - SpotFactor1) / (1.0 - cosrad));
				color += vec3(spotIntensity1 / dist1) * CSpotLights[2] * 0.001 * dotDirLight * CSpotLights[i+2].rgb;
			
			}
			/*
			if(-normal.z > 0.0) {
				vec3 viewDir = normalize(campos * 2.0 - fragPos);
				vec3 reflectDir = -lightToPixel1 + 2.0 * dotDirLight * normal; // reflect function
				
				float dotReflect = -(viewDir.x*reflectDir.x+viewDir.y*reflectDir.y+viewDir.z*reflectDir.z);
				float spec = dotReflect > 0.0 ? exp(log(dotReflect) * ( 64.0 )) : 0.0;
				
				//color += vec3(spec * 1.0) * dotDirLight * SpotFactor1;
			}
			*/
		}
		return clamp(color, 0.0, 1.0);
	}
	return vec3(0.0);
}

vec3 pointLight(float3 fragPos, float3 normal) {
	if(!isPointLight)
		return vec3(0.0);
		
	// Points Light 
	if(CPointLights_num > 0) {
		float specPower = 0.07;
		
		vec3 light = vec3(0.0);
		
		for(int i = 0; i < CPointLights_num * 3; i += 3)
		{
			float lightRadius = CPointLights[i+2].b;
			float distance = length(fragPos - (CPointLights[i] * 2.0)) / lightRadius;
    		float attenuation = 1.0 / (0.5 + (15.0 / lightRadius) * distance + 0.5 * (distance * distance * distance * distance * distance));    
    		
			if(attenuation > 0.0001) {
				vec3 lightDir = normalize(fragPos - (CPointLights[i] * 2.0));
				
				float rawdotDirLight = normal.x*lightDir.x+normal.y*lightDir.y+normal.z*lightDir.z;
				float dotDirLight = clamp(rawdotDirLight, 0.0, 1.0);
				//if(dotDirLight < 0.0 || dotDirLight > 1.0)
					//continue;
				
				// diffuse lighting
				float3 diffuseCol = vec3(dotDirLight * attenuation) * CPointLights[i+1];
				
				/*
				// specular shading
    			vec3 viewDir = normalize(campos * 2.0 - fragPos);
				vec3 reflectDir = -lightDir + 2.0 * dotDirLight * normal; // reflect function
				
				float dotReflect = -(viewDir.x*reflectDir.x+viewDir.y*reflectDir.y+viewDir.z*reflectDir.z);
				float spec = dotReflect > 0.0 ? exp(log(dotReflect) * ( 32.0 )) : 0.0;
				*/
				//light += diffuseCol;
				light.r = max(diffuseCol.r, light.r);
				light.g = max(diffuseCol.g, light.g);
				light.b = max(diffuseCol.b, light.b);
			}
		}
		return light;
	}
	return vec3(0.0);
}

vec3 getLight(float3 color, float3 fragPos, float3 normal, float gBrightness) {
	// Points Light
	vec3 outcol;
	
	vec3 pLight = pointLight(fragPos, normal) * (1.0-gBrightness);
	pLight *= color.rgb*((1.0-gBrightness)+1.0)*2.0*pointLight_Mult;
	
	vec3 spt = spotLight(fragPos, normal)  * (1.0-gBrightness);
	spt *= color.rgb*((1.0-gBrightness)+1.0)*2.0*lightCast_Mult;
	
	vec3 ttl = vec3(max(pLight.r, spt.r), max(pLight.g, spt.g), max(pLight.b, spt.b));
	outcol += ttl;
	return outcol;
}