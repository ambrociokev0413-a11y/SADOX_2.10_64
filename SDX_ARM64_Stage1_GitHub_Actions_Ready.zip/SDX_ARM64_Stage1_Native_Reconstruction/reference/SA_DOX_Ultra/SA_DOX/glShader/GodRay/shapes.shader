<vert>
#version 300 es

layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 TexCoord;
out vec2 vTexCoord;

void main() {
	vTexCoord = TexCoord;
	gl_Position = vec4(Position.xy, 0.0, 1.0);
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform highp sampler2D Diffuse;

uniform vec2 sunPosition;

@bool isGodRayEnable < class = "GodRays", name = "enable", default = true; >
@float exposure < class = "GodRays", name = "Exposure", default = 0.24; >
@float decay < class = "GodRays", name = "Decay", default = 0.974; >
@float density < class = "GodRays", name = "Density", default = 0.97; >
@float weight < class = "GodRays", name = "Weight", default = 0.25; >
@int samples < class = "GodRays", name = "Samples", default = 100; >

in vec2 vTexCoord;

layout (location = 0) out vec4 fragColor;

void main()
{
	if(!isGodRayEnable)
		return;
		
    vec2 deltaTextCoord = vec2( vTexCoord - sunPosition );
    vec2 textCoo = vTexCoord;
    deltaTextCoord *= (1.0 /  float(samples)) * density;
    
    vec3 out_color = vec3(0.0);

	float illuminationDecay = 0.7;
    
	for(int i = 0; i < samples; i++)
    {
             textCoo -= deltaTextCoord;
             out_color += textureLod(Diffuse,  textCoo, 0.0).rgb * illuminationDecay * weight;
             illuminationDecay *= 0.99;
     }
     out_color *= exposure * 0.7;
     fragColor = vec4(out_color, 1.0);
}
</frag>