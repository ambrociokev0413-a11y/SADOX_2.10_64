<vert>
#version 300 es
uniform mat4 ProjMatrix;
uniform mat4 ViewMatrix;
uniform mat4 ObjMatrix;
uniform mat4 VPMatrix;
uniform float TexDiv;
layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 TexCoord;
layout(location = 2) in vec3 Normal;
layout(location = 3) in vec4 GlobalColor;
layout(location = 4) in vec4 BoneWeight;
layout(location = 5) in vec4 BoneIndices;
uniform highp vec4 Bones[222];
out vec2 vTexCoord;

void main() {
	ivec4 BlendIndexArray = ivec4(BoneIndices);
	mat4 BoneToLocal;
	BoneToLocal[0] = Bones[BlendIndexArray.x*3] * BoneWeight.x;
	BoneToLocal[1] = Bones[BlendIndexArray.x*3+1] * BoneWeight.x;
	BoneToLocal[2] = Bones[BlendIndexArray.x*3+2] * BoneWeight.x;
	BoneToLocal[3] = vec4(0.0,0.0,0.0,1.0);
	BoneToLocal[0] += Bones[BlendIndexArray.y*3] * BoneWeight.y;
	BoneToLocal[1] += Bones[BlendIndexArray.y*3+1] * BoneWeight.y;
	BoneToLocal[2] += Bones[BlendIndexArray.y*3+2] * BoneWeight.y;
	BoneToLocal[0] += Bones[BlendIndexArray.z*3] * BoneWeight.z;
	BoneToLocal[1] += Bones[BlendIndexArray.z*3+1] * BoneWeight.z;
	BoneToLocal[2] += Bones[BlendIndexArray.z*3+2] * BoneWeight.z;
	vec4 WorldPos = ObjMatrix * (vec4(Position.xyz,1.0) * BoneToLocal);
    gl_Position = VPMatrix * WorldPos;
    vTexCoord = TexCoord / TexDiv;

}
</vert>

<frag>

#version 300 es
precision highp float;
uniform lowp sampler2D Diffuse;
uniform float isTextureAlpha;

in vec2 vTexCoord;
out vec4 fragColor;

void main()
{
    /*
    vec4 color = texture(Diffuse, vTexCoord);
    fragColor = vec4(0.0, 0.0, 0.0, color.a);
    */
}

</frag>