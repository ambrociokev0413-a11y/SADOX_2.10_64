<vert>
#version 300 es

uniform mat4 ObjMatrix;
uniform mat4 VPMatrix;
uniform float DetailTiling;

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 TexCoord;

out vec2 vTexCoord;

void main() {
	vTexCoord = TexCoord / DetailTiling;
	
	vec4 WorldPos = ObjMatrix * vec4(Position.xyz, 1.0);
	gl_Position = VPMatrix * WorldPos;    
}
</vert>

<frag>
#version 300 es
precision lowp float;
uniform sampler2D Diffuse;
uniform float isTextureAlpha;

in vec2 vTexCoord;

void main()
{
	if(isTextureAlpha > 0.0) {
		if(textureLod(Diffuse, vTexCoord, 0.0).a < 0.2)
			discard;
	}
}
</frag>