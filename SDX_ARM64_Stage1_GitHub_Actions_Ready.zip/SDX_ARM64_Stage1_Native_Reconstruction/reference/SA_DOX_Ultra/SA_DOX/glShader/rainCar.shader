void rainCarEffects(in vec3 worldnormal, inout vec3 normal, inout vec3 color) 
{
	vec3 bl;
	bl.x = saturate(exp(log(abs(worldnormal.x)) * ( 8.0 )));
    bl.y = saturate(exp(log(abs(worldnormal.y)) * ( 8.0 )));
    bl.z = saturate(exp(log(abs(worldnormal.z)) * ( 8.0 )));

    
	bl /= max(dot(bl, vec3(1.0, 1.0, 1.0)), 0.0001);
	
	vec2 uvX = posOri.yz;
	vec2 uvY = posOri.xz;
	vec2 uvZ = posOri.xy;
	
	vec2 uvX2 = posOri.yz;
	vec2 uvY2 = posOri.xz;
	vec2 uvZ2 = posOri.xy; 
	
	vec3 axisSign;
		axisSign.r = worldnormal.r < 0.0 ? -1.0 : 1.0;	
		axisSign.g = worldnormal.g < 0.0 ? -1.0 : 1.0;	
		axisSign.b = worldnormal.b < 0.0 ? -1.0 : 1.0;	

    uvX.x *= axisSign.x;
    uvY.x *= axisSign.y;
    uvZ.x *= -axisSign.z;	
	
	vec3 axisSign2;
		axisSign2.r = worldnormal.r < 0.0 ? 1.0 : -1.0;	
		axisSign2.g = worldnormal.g < 0.0 ? 1.0 : -1.0;	
		axisSign2.b = worldnormal.b < 0.0 ? 1.0 : -1.0;	
	
	uvX2.x *= axisSign2.x;
	uvY2.x *= axisSign2.y;
    uvZ2.x *= -axisSign2.z;		
	
	vec3 N1x = texture(texNormalRain, uvX).rgb;
	vec3 N1y = texture(texNormalRain, uvY2).rgb;
	
	vec3 R1x = texture(texRain, uvX).ggg;
	vec3 R1y = texture(texRain, uvY2).ggg;
	
	float Timer = TimeMS / 1250.0;
	vec2 xx = vec2((Timer / 1000.0) * 20.0 , 12.0 * (Timer / 1000.0) * 20.0);
	vec3 R2x = texture(texRain, uvX + xx).bbb;
	vec3 R2y = texture(texRain, uvY2 + xx).bbb;
	
	vec3 mixRain = R1x * bl.x + R1y * bl.y;
	vec3 mixAlpha = R2x * bl.x + R2y * bl.y;			   
	
	float RainAlpha = RainValue[0];
	float rainA = mix(0.0, mixAlpha.r, mixRain.r);	
	
	vec3 mixNormal = N1x * bl.x + N1y * bl.y;
	
	vec3 v = vec3(0.0);
	float dropVal = 0.0;
	float Tr2 = Timer * 1.4;
	
	vec2 n = texture(SamplerNoise, uvZ * 0.5).rg;  	
	
	if(bl.z > 0.4) 
	{
    	for (float r = 4.0 ; r > 0.0 ; r -= 1.0) 
    	{
        	vec2 x = vec2(2900.0 * r * 0.0075),
         	      p = 6.28 * uvZ.xy * x + (n - 0.5) * 2.0,
         	      s = sin(p);
        
        	vec4 d = texture(SamplerNoise, round(uvZ.xy * x - vec2(0.25)) / x);
       
			float t = (s.x+s.y) * max(0.0, 1.0 - fract(Tr2 * (d.b + 0.1) + d.g) * 2.0);      

   	     if (d.r < (4.0-r)*0.08 && t > 0.01) 
   	     {           
   	         v = normalize(-vec3(cos(p), mix(0.2, 2.0, t-0.5))) * bl.z;
				dropVal = 1.0 * bl.z;            
            	break;
        	}
    	}	
	}
	
	vec3 mixN = mix(normal, mixNormal, RainAlpha * rainA);		
	
	normal.xyz = normalize(mixN + vec3(v.xy * 0.55 * RainAlpha, 0.0));	
	color.rgb *= 1.0-rainA*0.75;
}