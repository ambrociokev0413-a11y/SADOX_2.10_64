vec3 CalcPointLight(vec3 lightPosition, vec3 normal, vec3 fragPos, vec3 viewDir)
{
    // attenuation
    float distance    = length(lightPosition - fragPos) / 1.5;
    float attenuation = 1.0 / (0.5 + 0.2 * distance + 0.5 * (distance * distance));    
	if(attenuation > 0.01) {
		vec3 lightDir = normalize(lightPosition - fragPos);
    	// diffuse shading
    	float diff = max(dot(normal, lightDir), 0.0);
    	// specular shading
    	vec3 reflectDir = reflect(-lightDir, normal);
    	float spec = pow(max(dot(viewDir, reflectDir), 0.0), 0.5);
		return vec3(diff * attenuation); ////(ambient + diffuse + specular);
	} else { return vec3(0.0); }
} 

vec3 diffuseLighting(vec3 lightDirection, vec3 normal, vec3 lightColor, out int stat){
    float diff = max(dot(normal, lightDirection), 0.0);
    vec3 diffuse = diff * lightColor;
    
    if(diff > 0.0)
    {
        stat = 1;
    } else { stat = 0; }
    
    return diffuse;
} 