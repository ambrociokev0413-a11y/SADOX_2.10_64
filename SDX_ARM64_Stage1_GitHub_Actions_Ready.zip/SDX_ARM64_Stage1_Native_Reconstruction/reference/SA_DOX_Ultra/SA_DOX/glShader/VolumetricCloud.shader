void lightingConfig(vec3 viewDirection, vec3 lightDirection, out vec3 lighting, out float shadow)
{
	// lighting
	float3 mixCol = mix(sunColor * ((1.0 - lightDirection.z)+1.0), vec3(0.97), 0.4);
	float cosine = saturate(viewDirection.x*lightDirection.x+viewDirection.y*lightDirection.y+viewDirection.z*lightDirection.z);
	float lightPower = 0.2 * exp(log(cosine) * ( 20.0 )) + 1.0;
	
	float lightnightPower = moonlight_strength * exp(log(cosine) * ( 15.0 )) + 1.0; 	
	lighting = lerp(mixCol * lightPower, vec3(0.24 * lightnightPower), nightValue);
	shadow = lerp(0.7, 0.127, nightValue);
}

float3 PosOnPlane(const in float3 origin, const in float3 direction, const in float h, inout float dis)
{
    dis = (h - origin.z) / direction.z;
    return float3((origin + direction * dis).xy, h);
}

float clampMap(float x, float a, float b, float c, float d)
{
    return clamp((x - b) / (a - b), 0.0, 1.0) * (c - d) + d;
}

float4 cloud_shape(float z, float4 profile, float3 dens_thres)
{
    float soft = clampMap(z, profile.y, profile.x, dens_thres.z, dens_thres.y);
    
    return
        float4(
        smoothstep(profile.z, lerp(profile.y, profile.z, profile.w), z) * smoothstep(profile.x, lerp(profile.y, profile.x, profile.w), z),
        dens_thres.x + soft,
        dens_thres.x - soft,
        soft);
}

float noise_p(float3 p)
{
    float3 fr = floor(p),
       ft = fract(p);
    
    float n = 3.0 * fr.x + 17.0 * fr.y + fr.z,
        v = lerp(fract(sin(n) * 9487.5987), fract(sin(n+1.0) * 9487.5987), ft.z),
        vr = lerp(fract(sin(n+3.0) * 9487.5987), fract(sin(n+4.0) * 9487.5987), ft.z),
        vd = lerp(fract(sin(n+17.0) * 9487.5987), fract(sin(n+18.0) * 9487.5987), ft.z),
        vo = lerp(fract(sin(n+20.0) * 9487.5987), fract(sin(n+21.0) * 9487.5987), ft.z);
    
	return ((v * (1.0 - ft.x) + vr * (ft.x)) * (1.0 - ft.y) +
        (vd * (1.0 - ft.x) + vo * ft.x) * ft.y);
}

//large density for the distribution of clouds.
float density(in float3 pos, const in float3 offsetA, const in float3 offsetB, in float cs)
{
    pos += cloud_shift * pos.z;
    float2
		pA = pos.xy + offsetA.xy,
		pB = pos.xy + offsetB.xy;

	float nsa = textureLod(SamplerWN, (pA * (0.0005/noiseSizeA)), 0.0).r * noise_densA;
	float nsb = textureLod(SamplerWN, (pB * (0.0005/noiseSizeB)), 0.0).r * noise_densB;
    return clamp((nsa + nsb) * cs, 0.0, 1.0);
}

float detial(const in float3 pos, const in float3 offsetC, const in float3 offsetD)
{
    float3
		pC = pos + offsetC,
		pD = pos + offsetD;
    
    float nc = noise_p(pC * (0.1/noiseSizeC));    

    //curvy distortioncloud_shift
    float a = nc * curvy_ang;
    float3 d = float3(cos(a), sin(a), 0.0) * curvy_strength;
    float dens = noise_densC * nc + noise_densD * (1.0 - noise_p((pD + d) * (0.1/noiseSizeD))) + noise_densE * noise_p((pD + d / 2.0) * (0.1/noiseSizeE));
    return dens;
}

float lightMarching(float3 p, float4 profile, float3 dens_thres, const in float3 offsetA, const in float3 offsetB, const in float3 offsetC, float3 lightDirection)
{
    float3
        p1 = p + lightDirection * ShadowStepLength,
        p2 = p + lightDirection * DetailShadowStepLength;
    
    float4
        cs = cloud_shape(p1.z, profile, dens_thres);
        
    float
        dens1 = density(p1, offsetA, offsetB, cs.x),
		dens2 = noise_densC * noise_p((p2+offsetC) * (0.1/noiseSizeC)) * 2.0 * ShadowDetail,
    
    d = (dens1 + dens2) * shadowContrast + shadowExpand - (cs.z - shadowSoftness);
    d /= (cs.w + shadowSoftness) * 2.0;
        
    return 1.0 - clamp(d, 0.0, 1.0) * shadowStrength;
}

float4 VolumetricCloud(const in float3 cam_dir, in float3 p, in float dist, const in float depth, float time, float3 lightDirection)
{
	if(c_cloudCoverageValue == 0.0)
		return vec4(0.0);
	
    float4 d = float4(0.0, 0.0, 0.0, min_sl); //distance, distance factor, gap, the last march step
	 
	p = PosOnPlane(p, cam_dir, clamp(p.z, vb_b, vb_t), d.x);
    d.y = d.x;
        
    if (d.x >= 0.0 && d.x < fade_e)
    {
        float
            fe = 0.01;
        
        float3
			flowA = -time * nA_move,
			flowB = -time * nB_move,
			flowC = -time * nC_move,
			flowD = -time * nD_move,
        
            dens_thres = float3(
                1.0 / lerp(grow_c, grow, c_cloudCoverageValue * volumetricMult),
                soft_top,
                lerp(soft_bot, soft_bot_c, c_cloudCoverageValue * volumetricMult)),
			fx = float3(0.5, 0.0, 1.0); //brightness, density, transparency          

        float4 profile = float4(body_top, body_mid, body_bot, body_thickness);
        
        if (depth >= 1.0)
            dist = fade_e;
        
        for (int i = 0; fx.z > 0.0 && p.z <= vb_t && p.z >= vb_b && i < maxStep && d.x - d.w < dist; i++)
        {
            float3 cs = cloud_shape(p.z, profile, dens_thres).xyz;
            
            float
                dens = (density(p, flowA, flowB, cs.x) + temp2) * (detial(p, flowC, flowD) + temp1) / (1.0 + temp2) / (1.0 + temp1),
                marchStep = clampMap(dens, cs.z, dCut, min_sl, max_sl) * clampMap(d.x, 0.0, 10000.0, 1.0, step_mul), 
			    coverage = smoothstep(cs.z, cs.y, dens) * marchStep / CloudSoftness,
                ds = fx.z + fe;
            
            //fade into near objects
            if (d.x >= dist)
            {
                coverage *= d.z / d.w;
                fx.y += fe * d.z / d.w;
            }
            else
                fx.y += fe;
            
            ds *= coverage / EffectFactor;
			if(ds > 0.0)
				fx.x = lerp(fx.x, lightMarching(p, profile, dens_thres, flowA, flowB, flowC, lightDirection), ds);
            d.y = d.y * (1.0 - ds) + ds * d.x;
            
            fx.y += coverage;
            fx.z = (exp(-fx.y / BeerFactor) - tCut) / (1.0 - tCut);
            
            d.z = dist - d.x;
            
            //marching
            p += cam_dir * marchStep;
            d.x += marchStep;
            d.w = marchStep;
        }
        
        if (fx.y > 0.0)
        {
            // lighting and shadow
            float3 c_bright;
			float c_dark;
			lightingConfig(cam_dir, lightDirection, c_bright, c_dark);
            
            if(isLightning != 0.0)
			{
				float3 lightning = float3(-0.09, 0.94, 0.4);
				float cosinel = saturate(cam_dir.x*lightning.x+cam_dir.y*lightning.y+cam_dir.z*lightning.z);
				c_bright += (1.0 * exp(log(cosinel) * ( 50.0 ))) * vec3(0.5, 0.5, 1.0);
			}
            
			float3 C = lerp(vec3(c_dark), c_bright, smoothstep(0.0, 1.0, (fx.x - 0.5) * CloudContrast + 0.5));
           
            float rsf = smoothstep(Atomesphere_Distance - Atomesphere_Smoothness, Atomesphere_Distance + Atomesphere_Smoothness, d.y);
            C += mix(Atomesphere, skyColorUP, 0.5) / 100.0 * rsf;

		    //fading
            fx.y = 1.0 - exp(-fx.y / alpha_curve);
            fx.y *= smoothstep(fade_e, fade_s, d.y);
            return float4(C, exp(log(fx.y) * ( 2.0 )));
        }
    }
    return float4(0.0, 0.0, 0.0, 0.0);
}