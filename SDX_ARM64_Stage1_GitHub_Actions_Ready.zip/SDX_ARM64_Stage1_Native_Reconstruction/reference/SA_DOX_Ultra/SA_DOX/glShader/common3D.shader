<vert>
#version 300 es
// mat
uniform mat4 ProjMatrix;
uniform mat4 ViewMatrix;
uniform mat4 ObjMatrix;
uniform mat4 VPMatrix;

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 TexCoord;
layout(location = 3) in vec4 GlobalColor;
layout(location = 6) in vec4 Color2;

out vec2 vTexCoord;
out vec3 fragPos;
out vec4 col;

void main() {
    vec4 WorldPos = ObjMatrix * vec4(Position.xyz,1.0);
	
	col = GlobalColor;
	
	gl_Position = VPMatrix * WorldPos;
	fragPos = gl_Position.xyz;
	
	vTexCoord = TexCoord;
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform highp sampler2D Diffuse;

uniform float AlphaModulate;
uniform float EnvMapCoefficient;

in vec3 fragPos;
in vec2 vTexCoord;
in vec4 col;

sampler2D SamplerNormal = texture_load { texture = "bloodNormal.png"; } 

layout (location = 0) out vec4 fragColor;
layout (location = 1) out vec4 gNormal;
layout (location = 2) out vec4 gColor;

uniform vec4 MaterialEmissive;
uniform vec4 MaterialAmbient;
uniform vec4 MaterialDiffuse;
uniform vec3 sunColor;
uniform vec3 sunDirection;
uniform float isTextureAvailable;

void main(){
	vec4 color = vec4(1.0);
	vec4 normal = vec4(0.0);
	vec4 componenC = vec4(0.0);
	
	if(isTextureAvailable == 1.0)
		color = texture(Diffuse, vTexCoord);
	
	color *= col;
	
	
	if(EnvMapCoefficient > 0.0){
		if(color.a <= 0.0 || max(color.r, max(color.g, color.b)) <= 0.0)
			discard;
		
		normal = vec4(mix(vec2(0.0), texture(SamplerNormal, vTexCoord / 4.0).xy, 0.4), 1.0, color.a);
	
		float diff = max(normal.x*sunDirection.x+normal.y*sunDirection.y+normal.z*sunDirection.z, 0.0);
		color.rgb += clamp(diff * sunColor * color.rgb * 1.5, 0.0, 1.0);
		
		// MASK
		componenC = vec4(0.8 + EnvMapCoefficient*0.2*0.1, 0.0, 0.0, 1.0);
	}
	
	fragColor = color;
	gNormal = vec4(normal.xyz * 0.5 + 0.5, normal.a);
	gColor = componenC;
}
</frag>