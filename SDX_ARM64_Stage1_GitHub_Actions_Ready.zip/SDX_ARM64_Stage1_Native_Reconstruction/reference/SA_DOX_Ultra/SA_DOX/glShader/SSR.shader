vec3 SSR(vec3 position, vec3 reflection, float curdepth, out bool ssrStat) 
{
	if(!isSSR){
		ssrStat = false;
		return vec3(0.0);
	}
	
	float3 dir = reflection;
	float3 wpos = position;
	float step = 0.002780 * sqrt(2000.0 *  curdepth);	
	float3 p = wpos + (dir * step);

	int s = SSR_MAXSTEP;
	float rcp = 1.0 / float(s) / 0.15;
	
	int n = 9;
	float2 uv = float2(0.0);
	bool a = false;		
	int l = 0;
	int i = 0;	
	float4 fff;
	for(; i < s; i++)		
	{		
		uv = sPos(p);
		if((uv.x > 1.0 || uv.y > 1.0 || uv.x < 0.0 || uv.y < 0.0)) { 
			ssrStat = false;
			return vec3(0.0, 0.0, 0.0);
		}

		vec4 dst = wPos(uv.xy);
		if(dst.w>0.0){
			fff = dst;
			dst.xyz -= p.xyz;
			float dstq = sqrt(dst.x * dst.x + dst.y * dst.y + dst.z * dst.z);

			if((step*0.8) > dstq && dstq < 1000.0)
			{
				l++;
				if(l >= n) break;			
			
				p -= dir * (step / 1.44);			
				step *= rcp;
				i = 0;
			}
		}
		p += dir * step / 1.34;
		step *= 1.44;
	}

	if(l >= n) {
		ssrStat = true;
		return pow(mix(textureLod(Diffuse, uv.xy, 0.0).rgb, c_fogColor, GetVolumetricFog(fff.xyz, fff.w)), vec3(2.0));    
	}

	ssrStat = false;
	return vec3(0.0, 0.0, 0.0);
}

float2 ComputeRipple(float2 uv, float CurrentTime, float Weight)
{
	float2 a0 = texture(SamplerAlpha, uv).rg * 1.4;	
	float3 rp3 = vec3(0.0);
	
	if(a0.r > 0.0){
		float3 rp = texture(SamplerPuddles, uv).rgb * 1.4;	
    	rp.yz = rp.yz * 2.0 - 1.0;	
		rp3 = lerp(rp3, rp, a0.r);
	}
		   	  
	float DropFrac = fract(a0.r+CurrentTime);
	float TimeFrac = DropFrac - 1.0 + rp3.x;
	float DropFactor = saturate(0.20 + Weight * 0.80 - DropFrac);
	float FF = DropFactor*rp3.x * sin(clamp(TimeFrac * 12.0, 0.0, 5.0) * PI);
	  
	return rp3.yz*FF*RainValue[0]*a0.g;
}

float3 CR(float3 n, float3 uv)
{
	float Timer = TimeMS / 1000.0;
    float Tr = Timer;   
    float4 TimeMul = float4(0.6, 0.7, 0.8, 1.0); 
    float4 TimeAdd = float4(0.22, 0.44, 0.66, 0.9);
    float4 Times = (Tr * TimeMul + TimeAdd) * 2.4;
	Times = fract(Times);
    
	float2 Ripple0 = ComputeRipple(uv.xy * 0.32 + float2(0.3, -0.42),  Times.w, 1.0),
    Ripple1 = ComputeRipple(uv.xy * 0.20 + float2(0.35, 0.1),  Times.x, 1.0);
    n = normalize(float3(n.xy + Ripple0, n.z));
    n = normalize(float3(n.xy + Ripple1, n.z));	
	return n;
}

vec4 SDX_SSR(vec3 position, out vec3 puddleLevel, float myMask, float SSR_Value, inout vec3 normal, float curdepth){
	bool ssrStat;
	vec2 UV = vTexCoord;
	vec4 outCol = vec4(0.0, 0.0, 0.0, 0.0);
	puddleLevel = vec3(0.0);
	float Puddle = 0.0;

	vec3 viewDirection = normalize(position.xyz);

	if(isMaskBuilding(myMask)) {
		if(-normal.z >= 0.99)
		{
			// Noise FBM
			Puddle = texture(NoisePuddle, vec2(position.xy + campos.xy * 2.0) * vec2(0.012) * vec2(0.5) + vec2(0.85)).r;
			Puddle = min(lerp(0.0, 1.45, saturate(Puddle)), 1.35);
			
			// untuk tingkat kemiringan 
			float sss = exp(log(smoothstep(0.98, 1.0, -normal.z)) * ( 1.5 ));
			Puddle *= sss;
		}	

		float m = SSR_Value * min(RainValue[2], 0.4);
		SSR_Value *= Puddle;
		
		if(SSR_Value < m) 
			SSR_Value = m;

		if(Puddle >= 1.0)
			Puddle *= RainValue[1];

		if(Puddle > 0.0){
			// mix normal map & normal
			normal.xy = mix(normal.xy, vec2(0.0, 0.0), min(1.0, Puddle));

			// waves
			float tx = (TimeMS / 20000.0) * 0.7 * 0.7;	
			float2 rf = textureLod(SamplerRelief, (position.xy + campos.xy * 2.0) * 0.1 * float2(0.8, 1.0) + vec2(tx), 0.0).rg;

        	normal.xy = mix(normal.xy, -rf, 0.02);
		}

		// rain puddle
		if(RainValue[0] > 0.0) 
			normal = lerp(normal, CR(normal, position+campos*2.0), max(Puddle, 0.25));
		
		// fresnel
		SSR_Value *= 1.0 -  (viewDirection.x*normal.x+viewDirection.y*normal.y+viewDirection.z*normal.z);
		
		SSR_Value *= 1.0 - exp(log(curdepth) * ( 70.0 ));
		
		SSR_Value = min(SSR_Value, 0.9);
		
		// out puddle level
		puddleLevel.r = Puddle;
		puddleLevel.g = SSR_Value;
	}

	vec3 reflectionDirection = reflect(viewDirection,  normal.xyz);
	outCol = vec4(SSR(position.xyz, reflectionDirection, curdepth, ssrStat), saturate(SSR_Value));

	if(ssrStat == false) {
		if(reflectionDirection.z > -0.02 || isMaskBuilding(myMask)) {
			if(reflectionDirection.z <= 0.0 && isMaskBuilding(myMask))
			{
				outCol.a *= Puddle;
			}

			// sky
			outCol.rgb = GetAtmosphericScattering(reflectionDirection, sunDirection, 1.0, 1.0, 1.0, 1.0); 			
			
			// smooth line
			outCol.rgb *= smoothstep(-0.02, 0.0, reflectionDirection.z);
			
		} else { outCol = vec4(0.0, 0.0, 0.0, SSR_Value); }      
	}
	//outCol.rgb = pow(outCol.rgb, vec3(2.0));
	return outCol;
}