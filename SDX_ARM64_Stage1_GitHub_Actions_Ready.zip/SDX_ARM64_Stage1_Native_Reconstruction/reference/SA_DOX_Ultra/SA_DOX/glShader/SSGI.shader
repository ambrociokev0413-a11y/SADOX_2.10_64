float2 mod_dither3(float2 u) 
{
	float noiseX = mod(u.x + u.y + mod(208. + u.x * 3.58, 13. + mod(u.y * 22.9, 9.)), 7.) * .143;
	float noiseY = mod(u.y + u.x + mod(203. + u.y * 3.18, 12. + mod(u.x * 27.4, 8.)), 6.) * .139;
	return float2(noiseX, noiseY) * 2.0 - 1.0;
}

float2 dither(float2 coord, float seed, float2 size) 
{
	float noiseX = ((fract(1.0 - (coord.x + seed * 1.0) * (size.x / 2.0)) * 0.25) + (fract((coord.y + seed * 2.0) * (size.y / 2.0)) * 0.75)) * 2.0 - 1.0;
	float noiseY = ((fract(1.0 - (coord.x + seed * 3.0) * (size.x / 2.0)) * 0.75) + (fract((coord.y + seed * 4.0) * (size.y / 2.0)) * 0.25)) * 2.0 - 1.0;
	return float2(noiseX, noiseY);
}

float lenSq(float3 v) 
{
	return pow(v.x, 2.0) + pow(v.y, 2.0) + pow(v.z, 2.0);
}

float3 lightSample(sampler2D color_tex, sampler2D depth_tex, float2 coord, float2 lightcoord, float3 normal, float3 position, float n, float2 texsize)
{
	float2 random = float2(1.0, 1.0);
	float _NoiseAmount = 2.0;
	int _Noise = 0;

	if (_Noise > 0)
	{
		random = (mod_dither3((coord * texsize) + float2(n * 82.294, n * 127.721))) * 0.01 * _NoiseAmount;
	}
	else 
	{
		random = dither(coord, 1.0, texsize) * 0.1 * _NoiseAmount;
	}
	
	lightcoord *= float2(0.7, 0.7);

	//light absolute data
	float3 lightcolor = texture(Diffuse, ((lightcoord))).rgb;
    float3 lightnormal = getViewNormal(fract(lightcoord)).xyz;
	float3 lightposition = getViewPos(fract(lightcoord));	
	
	//light variable data
	float3 lightpath = lightposition - position;
	float3 lightdir = normalize(lightpath);

	//falloff calculations
	float cosemit = clamp(dot(lightdir, -lightnormal), 0.0, 1.0); //emit only in one direction
	float coscatch = clamp(dot(lightdir, normal) * 0.5 + 0.5, 0.0, 1.0); //recieve light from one direction
	float distfall = pow(lenSq(lightpath), 0.1) + 1.0;        //fall off with distance

	return (lightcolor * cosemit * coscatch / distfall) * (length(lightposition) / 20.0);
}

vec4 PS_SSGI(float curDepth) {
	float3 direct = texture(Diffuse, vTexCoord).rgb;
	float3 indirect = float3(0.0,0.0,0.0);
	float PI = 3.14159;
	float2 texSize = canvasData.xy;

	float3 position = getViewPos(vTexCoord).xyz;	
	float3 normal = getViewNormal(vTexCoord).xyz;
	
	int _SamplesCount = 8;
	
	float dlong = PI * (3.0 - sqrt(5.0));
	float dz = 1.0 / float(_SamplesCount);
	float l = 0.0;
	float z = 1.0 - dz / 2.0;

	for (int i = 0; i < _SamplesCount; i++)
	{
		float r = sqrt(1.0 - z);

		float xpoint = (cos(l) * r) * 0.5 + 0.5;
		float ypoint = (sin(l) * r) * 0.5 + 0.5;

		z = z - dz;
		l = l + dlong;

		indirect += lightSample(Diffuse, DepthMap, vTexCoord, float2(xpoint, ypoint), normal, position, float(i), texSize);
	}
	return vec4(indirect / float(_SamplesCount) * 8.0, 1.0);
}