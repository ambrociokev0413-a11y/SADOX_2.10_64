<vert>
#version 300 es
uniform mat4 ObjMatrix;
uniform mat4 ShadowVPMatrix1;
uniform mat4 ShadowVPMatrix2;
uniform mat4 ShadowVPMatrix3;
uniform mat4 VPMatrix;
uniform lowp vec3 AmbientLightColor;
uniform lowp vec4 MaterialEmissive;
uniform lowp vec4 MaterialAmbient;
uniform lowp vec4 MaterialDiffuse;
uniform float DetailTiling;
uniform float bonesNum;

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 TexCoord;
layout(location = 2) in vec3 Normal;
layout(location = 3) in vec4 GlobalColor;
layout(location = 4) in vec4 BoneWeight;
layout(location = 5) in vec4 BoneIndices;
uniform highp vec4 Bones[222];
uniform vec3 CameraPosition;
out vec2 Out_Tex0;
out vec4 Out_Color;
out vec3 wNormal;
out vec3 shadowProjCoords1;
out vec3 shadowProjCoords2;
out vec3 shadowProjCoords3;
out vec3 campos;

#define ONEBONES 1.0
#define TWOBONES 2.0
#define THREEBONES 3.0
#define FOURBONES 4.0


void main() {
	campos = CameraPosition;
	ivec4 BlendIndexArray = ivec4(BoneIndices);
	mat4 BoneToLocal;
	
	int boneSize = int(bonesNum)*3;
	
		BoneToLocal[0] = Bones[BlendIndexArray.x*3] * BoneWeight.x;
		BoneToLocal[1] = Bones[BlendIndexArray.x*3+1] * BoneWeight.x;
		BoneToLocal[2] = Bones[BlendIndexArray.x*3+2] * BoneWeight.x;
		
		
			BoneToLocal[0] += Bones[BlendIndexArray.y*3] * BoneWeight.y;
			BoneToLocal[1] += Bones[BlendIndexArray.y*3+1] * BoneWeight.y;
			BoneToLocal[2] += Bones[BlendIndexArray.y*3+2] * BoneWeight.y;
		
			
				BoneToLocal[0] += Bones[BlendIndexArray.z*3] * BoneWeight.z;
				BoneToLocal[1] += Bones[BlendIndexArray.z*3+1] * BoneWeight.z;
				BoneToLocal[2] += Bones[BlendIndexArray.z*3+2] * BoneWeight.z;
		
				
					//BoneToLocal[0] += Bones[BlendIndexArray.w*3] * BoneWeight.w;
					//BoneToLocal[1] += Bones[BlendIndexArray.w*3+1] * BoneWeight.w;
					//BoneToLocal[2] += Bones[BlendIndexArray.w*3+2] * BoneWeight.w;
			
		BoneToLocal[3] = vec4(0.0,0.0,0.0,1.0);
	
	
	
	vec4 WorldPos = ObjMatrix * (vec4(Position.xyz,1.0) * BoneToLocal);
    wNormal = transpose(inverse(mat3(ObjMatrix))) * (Normal * mat3(BoneToLocal));
    gl_Position = VPMatrix * WorldPos;
	
	
    vec4 lightViewPosition = ShadowVPMatrix1  * WorldPos;
    vec4 lightViewPosition2 = ShadowVPMatrix2 * WorldPos;
    vec4 lightViewPosition3 = ShadowVPMatrix3 * WorldPos;
    
    shadowProjCoords1 = lightViewPosition.xyz / lightViewPosition.w;    
    // transform to [0,1] range
    shadowProjCoords1 = shadowProjCoords1 * 0.5 + 0.5;
    shadowProjCoords2 = lightViewPosition2.xyz / lightViewPosition2.w;    
    // transform to [0,1] range
    shadowProjCoords2 = shadowProjCoords2 * 0.5 + 0.5;
    shadowProjCoords3 = lightViewPosition3.xyz / lightViewPosition3.w;    
    // transform to [0,1] range
    shadowProjCoords3 = shadowProjCoords3 * 0.5 + 0.5;
    
    
	Out_Tex0 = TexCoord / DetailTiling;
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform highp sampler2D Diffuse,
									shadowMap1,
									shadowMap2,
									shadowMap3;
									
#include "sampler.dx";

in vec2 Out_Tex0;
uniform vec3 lightPosition;
uniform vec3 sunColor;
uniform float ShadowIntensity;
uniform float GameTime;
uniform vec3 sunDirection;
uniform float isTextureAlpha;
uniform float isTextureAvailable;
uniform float nightValue;
uniform vec3 AmbientLightColor;

in vec4 Out_Color;
in vec3 wNormal;
in vec3 shadowProjCoords1;
in vec3 shadowProjCoords2;
in vec3 shadowProjCoords3;
in vec3 campos;

layout (location = 0) out vec4 fragColor;
layout (location = 1) out vec4 gNormal;
layout (location = 2) out vec4 gColor;

float timeStep(float t1, float t2){
	float tout = (1.0 / (t2 - t1)) * (GameTime - t1);
	return tout >= 1.0 ? 1.0 : tout <= 0.0 ? 0.0 : tout;
}

#include "../realtimeShadow.shader";
#include "../function.shader";

void main(){
	vec4 color = vec4(1.0);
	float fshadow;
	
	if(isTextureAvailable == 1.0){
		color = texture(Diffuse, Out_Tex0, -0.5);
		if(isTextureAlpha > 0.0)
			if(color.a < 0.1)
  	      	discard;
	}
	
	vec3 cpy_color = color.rgb;
	
	vec3 normal = normalize(wNormal);
	
	
	vec3 SunDirection = lerp(sunDirection, float3(-0.09, -0.94, 0.31), nightValue);
	vec3 suncol = lerp(sunColor, vec3(0.17, 0.2, 0.2)*2.0, nightValue);
	
	float diff = clamp(normal.x*SunDirection.x+normal.y*SunDirection.y+normal.z*SunDirection.z, 0.0, 1.0);
	color.rgb = color.rgb * (suncol+AmbientLightColor*0.1) * (1.2*AmbientLightColor + vec3(diff));
	
	float shadowArea = diff != 0.0 ? 1.0 : 0.0;
	
	if(diff > 0.0 && ShadowIntensity > 0.05){
		fshadow = generateRealtimeShadow(sunDirection, normal) * ShadowIntensity * diff;
		color.rgb *= (1.0 - fshadow);
		shadowArea *= (1.0 - fshadow);
	}
	
	// color
	fragColor = color;

	// normal
	gNormal.xyz = normalize(wNormal.xyz) * 0.5 + 0.5;
	gNormal.w = 1.0;

	// component
	vec3 vvc = color.rgb - cpy_color;
	float bright = max(vvc.r, max(vvc.g, vvc.b));
	
	gColor = vec4(0.2, 1.0, clamp(bright * 7.0, 0.0, 1.0), 1.0);
}
</frag>