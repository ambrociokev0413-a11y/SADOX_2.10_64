<vert>
#version 300 es
precision highp float;
// mat
uniform mat4 VPMatrix; uniform mat4 ObjMatrix; uniform mat3 NormalMatrix;
uniform mat4 ShadowVPMatrix1; uniform mat4 ShadowVPMatrix2; uniform mat4 ShadowVPMatrix3;


//vec uniform
//uniform lowp vec4 MaterialEmissive;
//uniform lowp vec4 MaterialAmbient;
//uniform lowp vec4 MaterialDiffuse;
uniform vec3 CameraPosition;
uniform lowp float ColorInterp;
uniform float DetailTiling;
uniform float isTextureMatrix;
uniform float isTextureAlpha;
uniform float TimeMS;
uniform vec3 objectComponent;

#include "sampler.dx";

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 TexCoord;
layout(location = 2) in vec3 Normal;
layout(location = 3) in vec4 GlobalColor;
layout(location = 6) in vec4 Color2;

//out
out vec2 Out_Tex0;
out vec4 Out_Color;
out vec3 fragPos;
out vec3 campos;
out vec3 out_Normal;
out vec3 shadowProjCoords1;
out vec3 shadowProjCoords2;
out vec3 shadowProjCoords3;
out float _isTextureAlpha;
out float isMetallic;

void main() 
{
	vec4 WorldPos = ObjMatrix * vec4(Position,1.0);
 
   if(isTextureMatrix == 1.0)
        Out_Tex0 = (NormalMatrix * vec3(TexCoord.xy / DetailTiling, 0.5)).xy;
	else
		Out_Tex0 = TexCoord.xy / DetailTiling;
	
	// wind animation
	if(isTextureAlpha != 0.0 && objectComponent.x == 1.0) {
		float ns = texture(SamplerGradient, (Position.z + Out_Tex0 + (vec2(TimeMS/1000.0, TimeMS/1000.0*0.2) * 0.3) ) / 5.0).r * 1.0;
		ns = smoothstep(0.2, 1.0, ns);
	
		vec2 bumpc = WorldPos.xy + (TimeMS/1000.0 / 70.0);
		float bump = texture(SamplerBump, bumpc).r;
		bump = bump*bump;
		float c = clamp(abs(Position.z), 0.0, 1.0);
		c = c*c;
		
		bump = bump * ns;
		bump *= 0.7;
	
		WorldPos.xyz += vec3(bump, bump, 0.0);
	}
	

	gl_Position = VPMatrix * WorldPos;
    
	vec4 lightViewPosition = ShadowVPMatrix1 * WorldPos;
	vec4 lightViewPosition2 = ShadowVPMatrix2 * WorldPos;
	vec4 lightViewPosition3 = ShadowVPMatrix3 * WorldPos;
    
    
	shadowProjCoords1 = lightViewPosition.xyz / lightViewPosition.w;    
	// transform to [0,1] range
	shadowProjCoords1.xyz = shadowProjCoords1.xyz * 0.5 + 0.5;
    
	shadowProjCoords2 = lightViewPosition2.xyz / lightViewPosition2.w;    
	// transform to [0,1] range
	shadowProjCoords2.xyz = shadowProjCoords2.xyz * 0.5 + 0.5;
    
	shadowProjCoords3 = lightViewPosition3.xyz / lightViewPosition3.w;    
	// transform to [0,1] range
	shadowProjCoords3.xyz = shadowProjCoords3.xyz * 0.5 + 0.5;
    
    
	fragPos = WorldPos.xyz;
	campos = CameraPosition.xyz;
	out_Normal = normalize(Normal.xyz * transpose(mat3(ObjMatrix)));
	_isTextureAlpha = isTextureAlpha;
   
	lowp vec4 InterpColor = mix(GlobalColor, Color2, ColorInterp);
	
	vec3 Out_LightingColor;
	Out_LightingColor = InterpColor.rgb; //MaterialAmbient.xyz + MaterialEmissive.xyz;
	Out_Color = vec4(Out_LightingColor, 1.0);//vec4(Out_LightingColor * MaterialDiffuse.xyz, MaterialAmbient.w * InterpColor.w);
	Out_Color = clamp(Out_Color, 0.0, 1.0);
	
	isMetallic = objectComponent.x == 3.0 ? 1.0 : 0.0;
}
</vert>

<frag>
#version 300 es
precision highp float;

uniform highp sampler2D Diffuse,
						shadowMap1,
						shadowMap2,
						shadowMap3;

uniform int reflectionStat;

uniform float AlphaModulate,
						isTextureAvailable,
						EnvMapCoefficient,
						ShadowIntensity,
						nightValue,
						GameTime;

uniform vec3 sunColor,
						sunDirection,
						AmbientLightColor,
						skyColorUP,
						skyColorHor;

in float _isTextureAlpha,
			isMetallic;
in vec2 Out_Tex0;
in vec3 shadowProjCoords1,
			shadowProjCoords2, 
			shadowProjCoords3,
			fragPos,
			campos,
			out_Normal;
in vec4 Out_Color;

layout (location = 0) out vec4 fragColor;
layout (location = 1) out vec4 gNormal;
layout (location = 2) out vec4 gColor;

#include "../realtimeShadow.shader";
#include "../function.shader";

// normal map setting
#define OFFSET_X 1.0
#define OFFSET_Y 1.0
#define DEPTH	 5.5

float generateHeight(const float x, const float y, in vec2 fragCoord, const vec2 texSize)
{
	vec3 texdiff = texture(Diffuse, (fragCoord.xy * texSize + vec2(x, y)) / texSize).xyz;
	return texdiff.x*0.2126+texdiff.y*0.7152+texdiff.z*0.0722;
}

vec3 normalmap(in vec2 fragCoord)
{
	vec2 texSize = vec2(textureSize(Diffuse, 0));
	float R = generateHeight( OFFSET_X, 0.0, fragCoord, texSize);
	float L = generateHeight(-OFFSET_X, 0.0, fragCoord, texSize);
	float D = generateHeight(0.0, OFFSET_Y, fragCoord, texSize);
	float U = generateHeight(0.0, -OFFSET_Y, fragCoord, texSize);
				 
	float X = (L-R) * .5;
	float Y = (U-D) * .5;
	return normalize(vec3(X, Y, 1. / DEPTH));
}

vec3 mixNormalMap(vec3 normal)
{
	// z
	if(normal.z > 0.5 || -normal.z > 0.5)
	{
		vec3 normalmp = normalmap(Out_Tex0);
		normal = vec3(mix(normal.xy, normalmp.xy+normal.xy, 0.7), normal.z);
	}
	return normal;
}

float timeStep(float t1, float t2){
	float tout = (1.0 / (t2 - t1)) * (GameTime - t1);
	return tout >= 1.0 ? 1.0 : tout <= 0.0 ? 0.0 : tout;
}

void main()
{
    float reflection = 0.0, 
		fshadow = 0.0;
		
	vec4 color = vec4(1.0);
	vec3 normal = out_Normal.xyz;
		
	if(isTextureAvailable == 1.0){
    	color = texture(Diffuse, Out_Tex0);
		if(_isTextureAlpha > 0.0)
			if(color.a < 0.2)
				discard;
				
		normal  = mixNormalMap(out_Normal.xyz);
	}
	
	vec3 cpy_color = color.rgb;
	

	vec3 SunDirection = lerp(sunDirection, float3(-0.09, -0.94, 0.31), nightValue);
	vec3 suncol = lerp(sunColor, vec3(0.17, 0.2, 0.2)*2.0, nightValue);
        
	float diff = clamp(out_Normal.x*SunDirection.x+out_Normal.y*SunDirection.y+out_Normal.z*SunDirection.z, 0.0, 1.0);
	color.rgb = color.rgb * (suncol+AmbientLightColor*0.1) * (AmbientLightColor + vec3(diff));
	color.rgb = mix(color.rgb,  color.rgb+exp(log(Out_Color.rgb*1.2) * ( 4.0 ))*color.rgb, nightValue);
	
	float shadowArea = diff != 0.0 ? 1.0 : 0.0;

	if(diff > 0.0 && ShadowIntensity > 0.05){
		fshadow = 1.0 - generateRealtimeShadow(sunDirection, normal) * ShadowIntensity * diff;
		shadowArea *= fshadow;
		color.rgb *= fshadow;
	}

	// puddle stat
	if(EnvMapCoefficient > 0.0)
		reflection = 1.0;

	// color component
	vec3 vvc = color.rgb - cpy_color;
	float bright = max(vvc.r, max(vvc.g, vvc.b));
	
	gColor = vec4(0.0+reflection*0.1, shadowArea, clamp(bright * 7.0, 0.0, 1.0), 1.0);
	
	// normal
	gNormal = vec4(normal.xyz * 0.5 + 0.5, 1.0);

	// color
	fragColor = color;
}
</frag>