<vert>
#version 300 es

uniform mat4 ObjMatrix;
uniform mat4 VPMatrix;
uniform mat4 ShadowVPMatrix1; uniform mat4 ShadowVPMatrix2; uniform mat4 ShadowVPMatrix3;

uniform lowp vec4 MaterialEmissive;
uniform lowp vec4 MaterialAmbient;
uniform lowp vec4 MaterialDiffuse;
uniform float DetailTiling;
layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 TexCoord;
layout(location = 2) in vec3 Normal;
layout(location = 3) in vec4 GlobalColor;
uniform vec3 CameraPosition;
out vec2 Out_Tex0;
out vec4 Out_Color;
out vec3 wNormal;
out vec3 fragPos;
out vec3 normalOri;
out vec3 posOri;

out vec3 shadowProjCoords1;
out vec3 shadowProjCoords2;
out vec3 shadowProjCoords3;

out vec3 campos;

void main() {
	vec3 wnor = normalize(Normal.xyz * transpose(mat3(ObjMatrix)));
	vec4 WorldPos = ObjMatrix * vec4(Position,1.0);
	gl_Position = VPMatrix * WorldPos;
	
	// shadow view position
	vec4 lightViewPosition = ShadowVPMatrix1  * WorldPos;
    vec4 lightViewPosition2 = ShadowVPMatrix2 * WorldPos;
    vec4 lightViewPosition3 = ShadowVPMatrix3 * WorldPos;
	
	// transform 3d -> 2d
	shadowProjCoords1 = lightViewPosition.xyz / lightViewPosition.w;    
    // transform to [0,1] range
    shadowProjCoords1 = shadowProjCoords1 * 0.5 + 0.5;
 
   shadowProjCoords2 = lightViewPosition2.xyz / lightViewPosition2.w;    
    // transform to [0,1] range
    shadowProjCoords2 = shadowProjCoords2 * 0.5 + 0.5;
 
   shadowProjCoords3 = lightViewPosition3.xyz / lightViewPosition3.w;    
    // transform to [0,1] range
    shadowProjCoords3 = shadowProjCoords3 * 0.5 + 0.5;
    
	
	fragPos = WorldPos.xyz;
	posOri = Position;
	wNormal = wnor;
	normalOri = Normal;
	campos = CameraPosition;
	
	
	
    
    Out_Tex0 = TexCoord.xy / DetailTiling;
  
	Out_Color = vec4((2.0 * MaterialAmbient.xyz + vec3(1.0)) * MaterialDiffuse.xyz, (MaterialAmbient.w * GlobalColor.w));
    //Out_Color = clamp(Out_Color, 0.0, 1.0);
    
    
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform sampler2D Diffuse;

uniform highp sampler2D shadowMap1,
											shadowMap2,
											shadowMap3;

#include "sampler.dx";

uniform float TimeMS;
uniform float GameTime;

in vec3 posOri;
in vec2 Out_Tex0;
uniform float AlphaModulate;
uniform float EnvMapCoefficient;
uniform vec3 sunColor;
uniform float ShadowIntensity;
uniform vec4 RainValue;
uniform vec3 sunDirection;
uniform vec3 AmbientLightColor;
uniform float isTextureAlpha;
uniform float isTextureAvailable;
uniform float nightValue;

layout (location = 0) out vec4 fragColor;
layout (location = 1) out vec4 gNormal;
layout (location = 2) out vec4 gColor;

in vec3 campos;
in vec4 Out_Color;
in vec3 wNormal;
in vec3 fragPos;
in vec3 normalOri;
in vec3 shadowProjCoords1;
in vec3 shadowProjCoords2;
in vec3 shadowProjCoords3;

vec3 NormalBlend(vec3 n1, vec3 n2)
{   
	return normalize(vec3(n1.xy + n2.xy, n1.z));
}

#include "../function.shader";
#include "../realtimeShadow.shader";
#include "../lighting.shader";
#include "../rainCar.shader";

float timeStep(float t1, float t2){
	float tout = (1.0 / (t2 - t1)) * (GameTime - t1);
	return tout >= 1.0 ? 1.0 : tout <= 0.0 ? 0.0 : tout;
}

void main()
{   
    vec4 color = Out_Color;
    vec3 normal = wNormal.xyz;               
	float fshadow;
	
	if(isTextureAvailable == 1.0){
		color *= texture(Diffuse, Out_Tex0.xy);   
		if(isTextureAlpha > 0.0)
			if(color.a < 0.1)
  	      	discard;
	}
	
	vec3 cpy_color = color.rgb;
	
	if(RainValue[0] > 0.0)
		rainCarEffects(-normalOri, normal, color.rgb);
		
	vec3 SunDirection = lerp(sunDirection, float3(-0.09, -0.94, 0.31), nightValue);
	vec3 suncol = lerp(sunColor, vec3(0.17, 0.2, 0.2)*2.0, nightValue);
	
	float diff = clamp(normal.x*SunDirection.x+normal.y*SunDirection.y+normal.z*SunDirection.z, 0.0, 1.0);
	color.rgb = color.rgb * (suncol+AmbientLightColor*0.1) * (1.2*AmbientLightColor + vec3(diff));
	
	float shadowArea = diff != 0.0 ? 1.0 : 0.0;

	if(diff > 0.0 && ShadowIntensity > 0.05){
		fshadow = generateRealtimeShadow(sunDirection, normal) * ShadowIntensity * diff;
		color.rgb *= (1.0 - fshadow);
		shadowArea *= (1.0 - fshadow);
	}
	       
	// out color
	fragColor = color;
	//fragColor.a *= AlphaModulate;
	
	// out normal
	gNormal = vec4(normal * 0.5 + 0.5, 1.0);

	// out component
	vec3 vvc = color.rgb - cpy_color;
	float bright = max(vvc.r, max(vvc.g, vvc.b));
	
	gColor = vec4(0.4+(EnvMapCoefficient > 0.0 ? 1.0 : 0.0)*0.1, shadowArea, clamp(bright * 7.0, 0.0, 1.0), 1.0);
}

</frag>  