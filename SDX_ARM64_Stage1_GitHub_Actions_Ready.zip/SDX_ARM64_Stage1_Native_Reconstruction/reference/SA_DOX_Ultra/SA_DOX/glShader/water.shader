<vert>
#version 300 es


uniform mat4 ObjMatrix;
uniform mat4 VPMatrix;
uniform mat4 ShadowVPMatrix1;
uniform mat4 ShadowVPMatrix2;
uniform mat4 ShadowVPMatrix3;

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 TexCoord;
layout(location = 2) in vec3 Normal;

out vec2 Out_Tex0;
out vec3 fragPos;
out vec4 clipspace;
out vec3 shadowProjCoords1;
out vec3 shadowProjCoords2;
out vec3 shadowProjCoords3;
out vec3 normal; 

void main() {
    vec4 WorldPos = ObjMatrix * vec4(Position, 1.0);
	
	gl_Position = VPMatrix * WorldPos;
	fragPos = gl_Position.xyz;
	
	
	normal = normalize(vec3(0.0, 0.0, 1.0) * transpose(mat3(ObjMatrix)));
	
	clipspace = gl_Position;
	
    vec4 lightViewPosition = ShadowVPMatrix1  * WorldPos;
    vec4 lightViewPosition2 = ShadowVPMatrix2 * WorldPos;
    vec4 lightViewPosition3 = ShadowVPMatrix3 * WorldPos;
    
	shadowProjCoords1 = lightViewPosition.xyz / lightViewPosition.w;    
    // transform to [0,1] range
    shadowProjCoords1 = shadowProjCoords1 * 0.5 + 0.5;
    shadowProjCoords2 = lightViewPosition2.xyz / lightViewPosition2.w;    
    // transform to [0,1] range
    shadowProjCoords2 = shadowProjCoords2 * 0.5 + 0.5;
    shadowProjCoords3 = lightViewPosition3.xyz / lightViewPosition3.w;    
    // transform to [0,1] range
    shadowProjCoords3 = shadowProjCoords3 * 0.5 + 0.5;

	Out_Tex0 = TexCoord;    
}
</vert>

<frag>
#version 300 es
precision highp float;
uniform highp sampler2D Diffuse,
								DepthMap,
								shadowMap1,
								shadowMap2,
								shadowMap3;

uniform vec3 sunDirection;
uniform vec3 sunColor;

layout (location = 0) out vec4 fragColor;
layout (location = 1) out vec4 gNormal;
layout (location = 2) out vec4 gColor;

uniform float ShadowIntensity;
in vec3 shadowProjCoords1;
in vec3 shadowProjCoords2;
in vec3 shadowProjCoords3;

in vec2 Out_Tex0;
in vec3 fragPos;
in vec4 clipspace;
in vec3 normal; 

#include "realtimeShadow.shader";

void main() {
	gNormal.xyz = normal * 0.5 + 0.5;
	gNormal.w = 1.0;

	float fshadow = 0.0;
	if(ShadowIntensity > 0.05)
		fshadow = 1.0 - generateRealtimeShadow(sunDirection, normal) * ShadowIntensity;
	fshadow = fshadow == 0.0 ? 1.0 : fshadow;
	
	vec2 tx = (clipspace.xy / clipspace.w) * 0.5 + 0.5;
	float curDepth = texture(DepthMap, tx).r;


	float near = 0.1;
	float far = 1000.0;
	float floorDistance = 2.0 * near * far / (far + near - (2.0 * curDepth - 1.0) * (far -near));
	float waterDistance = 2.0 * near * far / (far + near - (2.0 * gl_FragCoord.z - 1.0) * (far -near));

	fragColor = vec4(0.0, 0.0, 0.0, 1.0);
	
    gColor = vec4(0.6, fshadow, clamp((floorDistance - waterDistance) / 1.0, 0.0, 1.0), 1.0);
}

</frag>