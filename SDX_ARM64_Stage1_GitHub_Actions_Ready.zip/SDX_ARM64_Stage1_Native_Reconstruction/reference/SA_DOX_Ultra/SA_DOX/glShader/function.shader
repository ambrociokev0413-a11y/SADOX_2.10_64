//constant
#define float2 vec2
#define float3 vec3
#define float4 vec4
#define lerp mix


float fastExp(float x) {
    float x2 = x * x;
    return 1.0 + x + 0.5 * x2 + 0.16666667 * x2 * x;
}

float hash( float x ) {
        return fract(sin(x) * 43758.5453123);
}

float fastLog2(float x) {
    int ix = floatBitsToInt(x);
    float exp = float((ix >> 23) & 0xFF) - 127.0;
    float mantissa = float((ix & 0x7FFFFF) | 0x800000) / float(0x800000);
    return exp + (mantissa - 1.0);
}

float fastLog(float x) {
    return fastLog2(x) * 0.69314718; // Convert log2(x) to log(x)
}

float2 fastLog(float2 x) {
    return float2(fastLog2(x.x), fastLog2(x.y)) * 0.69314718; // Convert log2(x) to log(x)
}

float3 fastLog(float3 x) {
    return float3(fastLog2(x.x), fastLog2(x.y), fastLog2(x.z)) * 0.69314718; // Convert log2(x) to log(x)
}

//saturate
float saturate (float v) { 
	return v >= 1.0 ? 1.0 : v <= 0.0 ? 0.0 : v;
}

vec2 saturate (vec2 v) { 
	if(v.x > 1.0) { v.x = 1.0; } else { if(v.x < 0.0) { v.x = 0.0; } }
	if(v.y > 1.0) { v.y = 1.0; } else { if(v.y < 0.0) { v.y = 0.0; } }
	return v; 
}
	
vec3 saturate (vec3 v) { 
	if(v.x > 1.0) { v.x = 1.0; } else { if(v.x < 0.0) { v.x = 0.0; } }
	if(v.y > 1.0) { v.y = 1.0; } else { if(v.y < 0.0) { v.y = 0.0; } }
	if(v.z > 1.0) { v.z = 1.0; } else { if(v.z < 0.0) { v.z = 0.0; } }
	return v; 
}
	
vec4 saturate (vec4 v) { 
	if(v.x > 1.0) { v.x = 1.0; } else { if(v.x < 0.0) { v.x = 0.0; } }
	if(v.y > 1.0) { v.y = 1.0; } else { if(v.y < 0.0) { v.y = 0.0; } }
	if(v.z > 1.0) { v.z = 1.0; } else { if(v.z < 0.0) { v.z = 0.0; } }
	if(v.w > 1.0) { v.w = 1.0; } else { if(v.w < 0.0) { v.w = 0.0; } }
	return v; 
}

//sin - cos
void sincos(float a, out float s, out float c) {
	s = sin(a);
	c = cos(a);
}

void sincos(vec2 a, out vec2 s, out vec2 c) {
	s[0] = sin(a[0]);
	c[0] = cos(a[0]);
	s[1] = sin(a[1]);
	c[1] = cos(a[1]);
}

void sincos(vec3 a, out vec3 s, out vec3 c) {
	s[0] = sin(a[0]);
	c[0] = cos(a[0]);
	s[1] = sin(a[1]);
	c[1] = cos(a[1]);
	s[2] = sin(a[2]);
	c[2] = cos(a[2]);
}