// god ray configuration
float godRay_Config() {
	// godRay Density config
	float T0 = timeStep(0.0, 4.0),
		T4 = timeStep(4.0, 5.0),
		T5 = timeStep(5.0, 6.0),
		T6 = timeStep(6.0, 7.0),
		T8 = timeStep(8.0, 11.0),
		TD = timeStep(11.0, 16.0),
		T16 = timeStep(16.0, 17.0),
		T18 = timeStep(18.0, 19.0),
		T19 = timeStep(19.0, 20.0),
		T20 = timeStep(20.0, 21.0),  
		T21 = timeStep(21.0, 22.0),
		T22 = timeStep(22.0, 23.0),
		T23 = timeStep(23.0, 24.0);  
		
	float outValue = mix(0.0, 0.0, T0); //0
		outValue = mix(outValue, 0.0, T4); //4
		outValue = mix(outValue, 0.6, T5); //5
		outValue = mix(outValue, 0.8, T6); //6
		outValue = mix(outValue, 0.45, T8); //8 - 11
		outValue = mix(outValue, 0.25, TD); //DAY
		outValue = mix(outValue, 0.7, T16); //16
		outValue = mix(outValue, 0.8, T18); //18
		outValue = mix(outValue, 0.0, T19); //19
		outValue = mix(outValue, 0.0, T20); //20
		outValue = mix(outValue, 0.0, T21); //21
		outValue = mix(outValue, 0.0, T22); //22
		outValue = mix(outValue, 0.0, T23); //23
	return outValue;
}

// Cloud Configuration
float cloudCoverageConfig()
{ 
	float4 wx = weatherValue;
    float sc = 0.47,
           sn = 0.47;
  
    if (wx.x==4.0) sc = 0.6;
    if (wx.y==4.0) sn = 0.6;
    if (wx.x==8.0 || wx.x==16.0) sc = 0.7;
    if (wx.y==8.0 || wx.y==16.0) sn = 0.7;
    
	if (wx.x==0.0 || wx.x==2.0 || wx.x==6.0 || wx.x==9.0 || wx.x==11.0 || wx.x==13.0 || wx.x==17.0 || wx.x==18.0) sc = 0.0;
    if (wx.y==0.0 || wx.y==2.0 || wx.y==6.0 || wx.y==9.0 || wx.y==11.0 || wx.y==13.0 || wx.y==17.0 || wx.y==18.0) sn = 0.0;	
    
	float cov = lerp(sc, sn, wx.z);
    return cov;
}

/*	FOG CONFIG	*/
void fogConfig(out float3 fogColor, out float fogDistance){
	// distance
	float4 wx = weatherValue;
    float CovC = 0.7;
    float CovN = 0.7;
    if (wx.x==8.0) CovC = 0.4;
	if (wx.x==9.0) CovC = 0.097;
	if (wx.x==16.0) CovC = 0.4;
	if (wx.y==8.0) CovN = 0.4;
	if (wx.y==9.0) CovN = 0.097;
	if (wx.y==16.0) CovN = 0.4;
 
	fogDistance = lerp(CovC, CovN, wx.z);
	
	// color
    float mx1 = 0.25;
    float mx2 = 0.25;
    
    if (wx.x==8.0 || wx.x==9.0 || wx.x==16.0)
		mx1 = 0.5;
	if (wx.y==8.0 || wx.y==9.0 || wx.y==16.0)
		mx2 = 0.5;
	
	float mxcInterpolate = lerp(mx1, mx2, wx.z);
	fogColor = lerp(float3(0.85), skyColorHor, mxcInterpolate) * mix(sunColor, vec3(1.0), 0.4);
}