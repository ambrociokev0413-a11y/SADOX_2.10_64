vec4 getWater(vec3 worldpos, inout vec3 normal, float curdepth, float waterDepth, float SSR_Value, float shadow, out vec3 brightColor) {
	vec4 color;
	vec2 uv = vTexCoord;
	vec3 viewDirection = normalize(worldpos);

	if(waterDepth > 0.5)
		waterDepth *= 1.0-exp(log(1.0-curdepth) * ( 1.5 ));

	float3 SunDirection = lerp(sunDirection, moonPos, nightValue);        
	float3 suncol = lerp(sunColor, vec3(0.5), nightValue);


	float fade = clamp(1.0 - exp(log(curdepth) * ( 32.0 )), 0.0, 1.0);

	// waves
	float tx = (TimeMS / 50000.0);
	float2 bf = texture(SamplerRelief, (worldpos.xy + campos.xy * 2.0) * 0.005 * float2(0.8, 1.0) + vec2(tx)).yx * 0.02;
	
	float4 rf = texture(SamplerRelief, (worldpos.xy + campos.xy * 2.0) * -0.005 * float2(0.8, 1.0) + vec2(tx) + bf.xy);
    normal.xy = mix(normal.xy, rf.xy * viewDirection.xy, 1.0 * fade);
	normal.xyz = -normalize(-normal.xyz);
	// create refraction
	vec3 refractColor;
	if(curdepth > textureLod(DepthMap, mix(vTexCoord, rf.xy, 0.05 * min(waterDepth * 27.0, 1.0)), 0.0).r)
		refractColor = texture(RefractionMap, vTexCoord).rgb;
	else
		refractColor = texture(RefractionMap, mix(vTexCoord, rf.xy, 0.05 * min(waterDepth * 27.0, 1.0))).rgb;
	color.rgb = refractColor;
	
	// fresnel effect
	float fresnel = dot(viewDirection, vec3(0.0, 0.0, -1.0)) * 0.5;
		
	// mix color of water
	color.rgb = mix(color.rgb, vec3(0.0, 0.35, 0.25), (1.0 - fresnel) * (clamp((waterDepth * 1.2), 0.0, 1.0)));
		
	// Water -- Screen Space Reflection
	vec3 reflectionDirection = reflect(viewDirection,  normalize(normal.xyz));
	bool ssrStat;
	vec4 outCol = vec4(SSR(worldpos, reflectionDirection, curdepth, ssrStat), (1.0 - fresnel) * 0.85) * (clamp((waterDepth * 1.2), 0.0, 1.0));

	if(ssrStat == false || max(outCol.r, max(outCol.g, max(outCol.b, 0.0))) <= 0.01) {
		
		// sky
		outCol.rgb = GetAtmosphericScattering(reflectionDirection, sunDirection, 1.0, 1.0, 1.0, 1.0);

		/*
		float dist = distance(float3(0.0, 0.0, 0.0), worldpos.xyz);
		float3 lightDirection = lerp(sunDirection, moonPos, nightValue);
		vec4 cloud = CheapVolumetricCloud(reflectionDirection.xyz, campos, dist, 1.0, ((TimeMS / 1000.0) * speed * 1500.0) + 4000.0, lightDirection);
		outCol.rgb = mix(outCol.rgb, cloud.rgb, cloud.a * 0.4);
		*/
		
		//blooming
		float cosine = clamp(dot(reflectionDirection, sunDirection),0.0,1.0);
		brightColor += 0.2*vec3(sunColor)*exp(log(cosine) * ( 2000.0 ));
	}
	color.rgb = mix(color.rgb, outCol.rgb, outCol.a);
	
	// color corection
	color.rgb = exp(log(color.rgb) * ( 0.5 ));
	color.rgb = exp(log(color.rgb) * ( 2.5 )) * Water_Brightness;

	// water foam
	float foamval = clamp(exp(log(1.0-exp(log(waterDepth) * ( 0.2 ))) * ( 2.0 )) * 2.0, 0.0, 1.0);
	 if(foamval > 0.0) {  
		float foam = texture(SamplerWake, (worldpos.xy + campos.xy * 2.0) * 0.02 * float2(0.8, 1.0) + vec2(sin(TimeMS / 2500.0) * 0.2) +vec2(rf.xy * 0.0092)).r;
		color.rgb = mix(color.rgb, vec3(1.0), foamval*clamp(foam*2.0, 0.0, 1.0));
	}
	
	// water lighting
	vec3 lightDir = normalize((worldpos + campos)-(SunDirection*1000.0 + campos));
	vec3 halfwayDir = normalize(lightDir + viewDirection);

	// Specular lighting (Blinn-Phong)
	if(shadow == 1.0){
		vec3 nwl = clamp(exp(log(dot(normal, halfwayDir)) * ( 64.0 )) * suncol * clamp(1.0 - SunDirection.z, 0.0, 1.0) * 1.2 * (5.0*foamval+1.0), 0.0, 1.0);
		if(7.0*foamval > 0.1)
			brightColor += nwl;
		color.rgb += nwl;
	} else {
		color.rgb += clamp(exp(log(dot(normal, halfwayDir)) * ( 64.0 )) * suncol * clamp((1.0 - SunDirection.z), 0.0, 1.0) * 0.2, 0.0, 1.0); // Shininess factor
	}
	
	// diffuse lighting
	//float diff = max(-normal.x*SunDirection.x+-normal.y*SunDirection.y+-normal.z*SunDirection.z, 0.0) * 0.5;
	//color.rgb += (diff * suncol * color.rgb) * waterDepth * 0.7;
	return color;
}