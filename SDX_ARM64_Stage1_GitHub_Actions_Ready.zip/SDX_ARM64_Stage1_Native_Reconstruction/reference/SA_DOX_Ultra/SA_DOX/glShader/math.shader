void sincos(float a, out float s, out float c) {
	s = sin(a);
	c = cos(a);
}

void sincos(vec2 a, out vec2 s, out vec2 c) {
	s[0] = sin(a[0]);
	c[0] = cos(a[0]);
	s[1] = sin(a[1]);
	c[1] = cos(a[1]);
}

void sincos(vec3 a, out vec3 s, out vec3 c) {
		s[0] = sin(a[0]);
		c[0] = cos(a[0]);
		s[1] = sin(a[1]);
		c[1] = cos(a[1]);
		s[2] = sin(a[2]);
		c[2] = cos(a[2]);
}