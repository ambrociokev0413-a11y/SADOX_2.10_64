<vert>
#version 300 es

layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 TexCoord;

out vec2 vTexCoord;
out vec2 pos;

void main() {
	vTexCoord = TexCoord;
	gl_Position = vec4(Position, 0.0, 1.0);
	pos = Position;
}
</vert>

<frag>
#version 300 es
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform highp sampler2D Diffuse;
@bool enableFXAA <  class = "main", name = "FXAA", default = false; >

in vec2 vTexCoord;
layout (location = 0) out vec4 fragColor;
in vec2 pos;

vec3 fxaa(vec2 p)
{
	float FXAA_SPAN_MAX   = 8.0;
    float FXAA_REDUCE_MUL = 1.0 / 8.0;
    float FXAA_REDUCE_MIN = 1.0 / 128.0;

	vec2 RES = vec2(textureSize(Diffuse, 0));

    // 1st stage - Find edge
    vec3 rgbNW = texture(Diffuse, p + (vec2(-1.,-1.) / RES)).rgb;
    vec3 rgbNE = texture(Diffuse, p + (vec2( 1.,-1.) / RES)).rgb;
    vec3 rgbSW = texture(Diffuse, p + (vec2(-1., 1.) / RES)).rgb;
    vec3 rgbSE = texture(Diffuse, p + (vec2( 1., 1.) / RES)).rgb;
    vec3 rgbM  = texture(Diffuse, p).rgb;

    vec3 luma = vec3(0.299, 0.587, 0.114);

    float lumaNW = dot(rgbNW, luma);
    float lumaNE = dot(rgbNE, luma);
    float lumaSW = dot(rgbSW, luma);
    float lumaSE = dot(rgbSE, luma);
    float lumaM  = dot(rgbM,  luma);

    vec2 dir;
    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));
    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));
    
    float lumaSum   = lumaNW + lumaNE + lumaSW + lumaSE;
    float dirReduce = max(lumaSum * (0.25 * FXAA_REDUCE_MUL), FXAA_REDUCE_MIN);
    float rcpDirMin = 1. / (min(abs(dir.x), abs(dir.y)) + dirReduce);

    dir = min(vec2(FXAA_SPAN_MAX), max(vec2(-FXAA_SPAN_MAX), dir * rcpDirMin)) / RES;

    // 2nd stage - Blur
    vec3 rgbA = .5 * (texture(Diffuse, p + dir * (1./3. - .5)).rgb +
        			  texture(Diffuse, p + dir * (2./3. - .5)).rgb);
    vec3 rgbB = rgbA * .5 + .25 * (
        			  texture(Diffuse, p + dir * (0./3. - .5)).rgb +
        			  texture(Diffuse, p + dir * (3./3. - .5)).rgb);
    
    float lumaB = dot(rgbB, luma);
    
    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));
    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));

    return ((lumaB < lumaMin) || (lumaB > lumaMax)) ? rgbA : rgbB;
}

void main()
{
	if(enableFXAA)
		fragColor = vec4(fxaa(vTexCoord), 1.0);
	else
		fragColor = texture(Diffuse, vTexCoord);
}
</frag>