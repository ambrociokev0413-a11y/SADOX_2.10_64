#define zenithDensity(x) 0.7 / exp(log(max(x - 0.1, 0.35e-2)) * ( 0.75 ))

float moon( vec3 rd ) {
	float a = dot( rd, normalize(moonPos) );
	float mv = clamp(exp(log(a) * ( 2048.0 )) * 1.1 * 1.5, 0.0, 1.0);
  
	/*      
	if(mv > 0.01){
		float2 uv = rd.xy * 0.5 + 0.5;
		float2 p = (uv) / (0.007 * 2.0);
		return mv+texture(SamplerWN, p).r*mv;      
	}     
	*/
		
	return mv;
}

float Stars(float2 coord)
{	
	float2 uv = coord.xy;
	float2 p = (uv) / (0.1 * 2.0);
	float3 smp = texture(SamplerNoise, p).rgb;
	
	float fstars = smoothstep(0.9, 1.0, smp.z);
	if(fstars > 0.0)
		fstars *= smp.r * smp.g;
		
	return fstars;
}

float3 getSkyAbsorption(float3 x, float y)
{	
	return exp2(x * -y);
}

float3 jodieReinhardTonemap(float3 c)
{
    float3 tc = c / (c + 1.0);
    return lerp(c / ((c.x*0.2126+c.y*0.7152+c.z*0.0722) + 1.0), tc, tc);
}

float3 GetAtmosphericScattering(float3 wpos, float3 SunDirectionR, float depth, float SunA, float SkyNight, float Clight)
{   
   float x1 = timeStep(0.0, 4.0);
   float x2 = timeStep(4.0, 5.0);
   float x3 = timeStep(5.0, 6.0);
   float x4 = timeStep(6.0, 7.0);
   float xE = timeStep(8.0, 11.0);
   float x5 = timeStep(16.0, 17.0);
   float x6 = timeStep(18.0, 19.0);
   float x7 = timeStep(19.0, 20.0);
   float xG = timeStep(20.0, 21.0);  
   float xZ = timeStep(21.0, 22.0);
   float x8 = timeStep(22.0, 23.0);
   float x9 = timeStep(23.0, 24.0);  

	// Base Sky Color	  
   float sky = exp(log(saturate(0.95 - wpos.z)) * ( 5.0 ));
   float sky1 = exp(log(saturate(0.15 - wpos.z)) * ( 0.5 ));
   float sky2 = exp(log(1.05 - wpos.z) * ( 40.0 ));
	
   float3 SkyColorTop = skyColorUP;
   float3 SkyColorBot = skyColorHor;   
   
	float3 absorption = exp2(SkyColorTop * -sky2);
	float sk = min(wpos.z * 1.1, 1.0);
	
	//=============================================================
	// Исправляем неправильную работу SunDirection
	//=============================================================

   float3 vec0 = SunDirectionR;
   float3 mn0 = float3(0.0, 0.0, -1.0);
   
   float3 sv = SunDirectionR;	
		  
   float _vec3 = max(sv.z + 0.1, 0.0);   

   float vec6 = lerp(0.4, 0.4, x1);
         vec6 = lerp(vec6, 0.4, x2);
         vec6 = lerp(vec6, 0.4, x3);
         vec6 = lerp(vec6, 0.4, x4);
         vec6 = lerp(vec6, 0.4, xE);
         vec6 = lerp(vec6, 0.5, x5);
         vec6 = lerp(vec6, 0.8, x6);
         vec6 = lerp(vec6, 0.9, x7);
         vec6 = lerp(vec6, 0.9, xG);	
         vec6 = lerp(vec6, 1.0, xZ);			  
         vec6 = lerp(vec6, 1.0, x8);    
         vec6 = lerp(vec6, 1.0, x9);  
		 
	float3 sunAbsorption = exp2(SkyColorTop * -zenithDensity(sv.z + vec6));
	float3 sAbs = sunAbsorption * 0.5 + 0.5 * length(sunAbsorption);  

	float cosine = saturate(wpos.x*SunDirectionR.x+wpos.y*SunDirectionR.y+wpos.z*SunDirectionR.z);

    // sun
   float3 att = lerp(float3(0.0), float3(0.0), x1);
          att = lerp(att, float3(1.0, 0.9, 0.5)*3.0, x2);
          att = lerp(att, float3(1, 0.949, 0.51)*4.7, x3);
          att = lerp(att, float3(1, 0.949, 0.51)*2.2, x4);
          att = lerp(att, float3(1.0, 1.0, 1.0)*0.6, xE);
          att = lerp(att, float3(1.0, 1.0, 1.0)*0.6, x5);
          att = lerp(att, float3(1, 0.949, 0.51)*3.0, x6);	 
          att = lerp(att, float3(1.0, 0.9, 0.5)*0.8, x7);
		  att = lerp(att, float3(1.0, 0.9, 0.5)*0.6, xG);
		  att = lerp(att, float3(1.0, 0.9, 0.5)*0.4, xZ);
          att = lerp(att, float3(0.0), x8);
          att = lerp(att, float3(0.0), x9);	

	float suns = exp(4000.0 * log(cosine));
	
	float3 Sun = vec3(sunColor) * suns * absorption;
	float3 Ray = vec3(sunColor) * ( cosine*cosine ) * att;
	
	float3 SkyColor = lerp(SkyColorTop, SkyColorBot, sky) * lerp(sky, 1.0, 0.4);
	    SkyColor = lerp(SkyColor * absorption, SkyColor, _vec3); 
		SkyColor *= 12.0;			   
	    SkyColor *= sAbs;
	
	// night
	float3 fnight = lerp(float3(0.50, 0.70, 1.0) * 0.2, float3(0.50, 0.70, 1.0) * 0.30, exp(log(sky) * ( 0.85 )));
	SkyColor = exp(log(jodieReinhardTonemap(lerp(SkyColor, fnight, nightValue) + Ray * 0.75 * sAbs)) * ( 1.1 )) * 1.1;

	//moon & stars
	float ta = lerp(0.0, 1.0, nightValue);
        	
	if(ta > 0.0) {
		float moonval = moon(wpos.xyz)*ta;
		SkyColor.rgb = mix(SkyColor.rgb, vec3(1.0), moonval);
		if(moonval < 1.0){
    		float stars = Stars(wpos.xy * 0.5 + 0.5) * 4.48;
    		stars*= step(0.3, stars);
			stars*= smoothstep(0.15, 0.4, wpos.z);
			SkyColor.rgb += stars * clamp(ta * 5.0, 0.0, 1.0);
		}
    }
	return clamp(SkyColor + Sun, 0.0, 1.0);
}