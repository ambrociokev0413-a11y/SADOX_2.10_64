~~__________SA_DOX__________~~
~~~~~~______ 2.0 ______~~~~~~
|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|


<vert>
	#version 300 es
	
	layout(location = 0) in vec2 Position;
	layout(location = 1) in vec2 TexCoord;
	
	// uniform load
	uniform vec3 CameraPosition;
	uniform float GameTime;
	uniform vec4 weatherValue;
	uniform vec3 sunColor;
	uniform vec3 skyColorHor;
	
	// main out
	out vec3 campos;
	out vec2 vTexCoord;
	out vec2 vpos;
	
	// out value
	out float _GameTime;
	out vec4 _weatherValue;
	out vec3 _sunColor;
	out vec3 _skyColorHor;
	
	// configuration
	out float c_godRayValue;
	out float c_cloudCoverageValue;
	out float c_fogDistance;
	out vec3 c_fogColor;
	
	#include "function.shader";
	float timeStep(float t1, float t2){ float tout = (1.0 / (t2 - t1)) * (GameTime - t1); return tout >= 1.0 ? 1.0 : tout <= 0.0 ? 0.0 : tout; }
	
	#include "config/config1.shader";
	
	
	void main() {    
		gl_Position = vec4(Position, 0.0, 1.0);
		
		campos = CameraPosition;
		vpos = Position;
		vTexCoord = Position * 0.5 + 0.5;
		
		// out common value
		_GameTime = GameTime;
		_weatherValue = weatherValue;
		_sunColor = sunColor;
		_skyColorHor = skyColorHor;
		
		// out configuration value
		c_godRayValue = godRay_Config();
		c_cloudCoverageValue = cloudCoverageConfig();
		fogConfig(c_fogColor, c_fogDistance);
	}
</vert>

~~__________SA_DOX__________~~
~~~~~~______ 2.0 ______~~~~~~
|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|

<frag>
	#version 300 es
	precision highp float;
	
	uniform highp sampler2D Diffuse,
												DepthMap,
												NormalMap,
												componentMap,
												RefractionMap;
	
	sampler2D SamplerNoise = texture_load { texture = "enbnoise.png"; } 
	sampler2D SamplerRelief = texture_load { texture = "PuddlesRelief.png"; } 
	sampler2D SamplerAlpha = texture_load { texture = "RipplesAlpha.png"; } 
	sampler2D SamplerPuddles = texture_load { texture = "Ripples.png"; } 
	sampler2D NoisePuddle = texture_load { texture = "NoisePd.png"; } 
	sampler2D SamplerWake = texture_load { texture = "WaterFoam.png"; } 
	sampler2D SamplerWN = texture_load { texture = "worleyNoise.png"; } 
	
	uniform int CPointLights_num;
	#define LimitLights 31
	uniform vec3 CPointLights[LimitLights * 3]; //position, color, radius
	
	uniform int SpotLights_num;
	#define LimitSpotLights 20
	uniform vec3 CSpotLights[LimitSpotLights * 4]; //position, direction, color, radius

	uniform mat4 PreviousProjMatrix; uniform mat4 PreviousViewMatrix;
	uniform mat4 ProjMatrix; uniform mat4 ViewMatrix; 
	uniform mat4 invProjMatrix; uniform mat4 invViewMatrix; 
	uniform mat4 invVPMatrix; uniform mat4 VPMatrix;
	
	uniform vec3 skyColorUP;
	uniform int weatherStat; uniform vec4 RainValue; uniform float TimeMS;
	uniform vec2 canvasData; uniform vec3 boundsMin; uniform vec3 boundsMax;
	uniform vec3 sunDirection;
	uniform vec3 lightPosition;
	uniform vec3 windDirection;
	uniform vec3 FogDistances;
	uniform float nightValue;
	uniform float isLightning;
	uniform float cloudFrequency; uniform float cloudThickness; uniform float cloudAltitude; uniform float cloudSpeed;
	uniform int isMirroring;
	
	// cloud setting
	@bool enableCloud <  class = "volumetricCloud", name = "enable", default = true; >
	@int maxStep < class = "volumetricCloud", name = "maxStep", default = 64; >
	@float vb_t < class = "volumetricCloud", name = "VolumeBox_Top", default = 550.0; >
	@float vb_b < class = "volumetricCloud", name = "VolumeBox_bottom", default = 400.0; >
	@float min_sl < class = "volumetricCloud", name = "MinStepLength", default = 6.0; >
	@float max_sl < class = "volumetricCloud", name = "MaxStepLength", default = 125.0; >
	@float step_mul < class = "volumetricCloud", name = "StepLengthMultiplyer", default = 8.0; >
	@float dCut < class = "volumetricCloud", name = "DensityCut", default = 0.05; >
	@float tCut < class = "volumetricCloud", name = "TransparencyCut", default = 0.2; >
	@float body_top < class = "volumetricCloud", name = "BodyTop", default = 800.0; >
	@float body_mid < class = "volumetricCloud", name = "BodyMiddle", default = 450.0; >
	@float body_bot < class = "volumetricCloud", name = "BodyBottom", default = 300.0; >
	@float body_thickness < class = "volumetricCloud", name = "BodyThickness", default = 0.05; >
	@float grow < class = "volumetricCloud", name = "DensityIncrease", default = 0.62; >
	@float grow_c < class = "volumetricCloud", name = "DensityIncrease_cloudy", default = 0.55; >
	@float soft_top < class = "volumetricCloud", name = "DensitySoftnessTop", default = 0.9; >
	@float soft_bot < class = "volumetricCloud", name = "DensitySoftnessBottom", default = 1.2; >
	@float soft_bot_c < class = "volumetricCloud", name = "DensitySoftnessBottom_cloudy", default = 1.55; >
	@float noise_densA < class = "volumetricCloud", name = "ChunkDensityA", default = 0.55; >
	@float noise_densB < class = "volumetricCloud", name = "ChunkDensityB", default = 0.5; >
	@float noise_densC < class = "volumetricCloud", name = "ChunkDensityC", default = 0.43; >
	@float noise_densD < class = "volumetricCloud", name = "ChunkDensityD", default = 0.2; >
	@float noise_densE < class = "volumetricCloud", name = "ChunkDensityE", default = 0.1; >
	@float noiseSizeA < class = "volumetricCloud", name = "ChunkSizeA", default = 15.0; >
	@float noiseSizeB < class = "volumetricCloud", name = "ChunkSizeB", default = 3.0; >
	@float noiseSizeC < class = "volumetricCloud", name = "ChunkSizeC", default = 3.5; >
	@float noiseSizeD < class = "volumetricCloud", name = "ChunkSizeD", default = 1.5; >
	@float noiseSizeE < class = "volumetricCloud", name = "ChunkSizeE", default = 0.75; >
	@float temp1 < class = "volumetricCloud", name = "temp1", default = 1.0; >
	@float temp2 < class = "volumetricCloud", name = "temp2", default = 0.2; >
	@float curvy_ang < class = "volumetricCloud", name = "curvy_ang", default = 2.5; >
	@float curvy_strength < class = "volumetricCloud", name = "curvy_strength", default = 5.0; >
	@float BeerFactor < class = "volumetricCloud", name = "BeerFactor", default = 2.35; >
	@float EffectFactor < class = "volumetricCloud", name = "EffectFactor", default = 1.0; >
	@float CloudSoftness < class = "volumetricCloud", name = "CloudSoftness", default = 0.05; >
	@float moonlight_strength < class = "volumetricCloud", name = "moonlight_Strength", default = 4.2; >
	@float CloudContrast < class = "volumetricCloud", name = "CloudContrast", default = 1.0; >
	@float cloudBrightnessMultiply < class = "volumetricCloud", name = "CloudBrightnessMultiply", default = 1.0; >
	@float ShadowStepLength < class = "volumetricCloud", name = "ShadowStepLength", default = 80.0; >
	@float DetailShadowStepLength < class = "volumetricCloud", name = "DetailShadowStepLength", default = 60.0; >
	@float ShadowDetail < class = "volumetricCloud", name = "DetailShadowStrength", default = 0.01; >
	@float shadowExpand < class = "volumetricCloud", name = "ShadowExpand", default = -0.22; >
	@float shadowStrength < class = "volumetricCloud", name = "ShadowStrength", default = 12.0; >
	@float shadowContrast < class = "volumetricCloud", name = "ShadowContrast", default = 0.9; >
	@float shadowSoftness < class = "volumetricCloud", name = "ShadowSoftness", default = 0.2; >
	@float Atomesphere_Distance < class = "volumetricCloud", name = "AtomesphereDistance", default = 2000.0; >
	@float Atomesphere_Smoothness < class = "volumetricCloud", name = "AtomesphereSmoothness", default = 6000.0; >
	@float speed < class = "volumetricCloud", name = "cloudSpeed", default = 0.0025; >
	@float alpha_curve < class = "volumetricCloud", name = "AlphaCurve", default = 0.27; >
	@float fade_s < class = "volumetricCloud", name = "FadeStart", default = 2000.0; >
	@float fade_e < class = "volumetricCloud", name = "FadeEnd", default = 10000.0; >
	@float volumetricMult < class = "volumetricCloud", name = "volumetricMult", default = 1.0; >
	
	vec3 cloud_shift = vec3(-0.5, 0.0, 0.0);
	vec3 Atomesphere = vec3(-5.92, -5.32, 3.81);

	vec3 nA_move = vec3(1.0, -3.0, 0.0);
	vec3 nB_move = vec3(2.8, -2.0, 0.0);
	vec3 nC_move = vec3(-3.2, 0.0, 0.3);
	vec3 nD_move = vec3(3.5, 1.0, 0.5);
	
	// main
	@bool isSSR <  class = "main", name = "SSR", default = false; >
	@bool isSSAO <  class = "main", name = "SSAO", default = false; >
	@float SSAO_density < class = "main", name = "SSAO_density", default = 1.0; >
	@int SSR_MAXSTEP < class = "main", name = "SSR_MaxStep", default = 32; >
	@float Water_Brightness < class = "Water_Brightness", name = "Water_Brightness", default = 1.0; >
	
	
	// godrays
	@bool isGodRayEnable_menu < class = "GodRays", name = "enable", default = true; >
	
	//lighting
	@bool isLightCast <  class = "lighting", name = "Light_Cast", default = false; >
	@bool isPointLight <  class = "lighting", name = "Point_Light", default = false; >
	@float lightCast_Mult < class = "lighting", name = "LightCast_Mult", default = 1.0; >
	@float pointLight_Mult < class = "lighting", name = "PointLight_Mult", default = 1.0; >
	@float SpecularLight_Mult < class = "lighting", name = "Specular_Light", default = 1.0; >
	
	in vec2 vTexCoord;
	in vec3 campos;
	in vec2 vpos;
	in float _GameTime;
	in vec4 _weatherValue;
	in vec3 _sunColor;
	in vec3 _skyColorHor;
	
	// in for configuration
	in float c_godRayValue;
	in float c_cloudCoverageValue;
	in float c_fogDistance;
	in vec3 c_fogColor;
	
	layout (location = 0) out vec4 fragColor;
	layout (location = 1) out vec4 out_godRay;
	layout (location = 2) out vec4 out_BrightSpec;
	
	///
	#define GameTime _GameTime
	#define weatherValue _weatherValue
	#define sunColor _sunColor
	#define skyColorHor _skyColorHor
	////
	
	#define PI 3.14159265359
	#define moonPos float3(-0.09, -0.94, 0.31)
	
	#include "function.shader";

	// func masking
	bool isMaskBuilding(float mask) { 
		if(mask >= 0.0 && mask < 0.2) return true; else return false;
	}

	bool isMaskPed(float mask) { 
		if(mask >= 0.2-0.01 && mask < 0.4) return true; else return false;
	}

	bool isMaskVehicle(float mask) { 
		if(mask >= 0.4-0.01 && mask < 0.6) return true; else return false;
	}

	bool isMaskWater(float mask) { 
		if(mask >= 0.6-0.01 && mask < 0.8) return true; else return false;
	}
	
	bool isMaskEffect(float mask) { 
		if(mask >= 0.8-0.01 && mask < 1.0) return true; else return false;
	}
	
	float getMaskCoefficient(float mask){
		
		float coeff = 0.0;
		
		if(isMaskBuilding(mask))
			coeff = mask * 10.0;
		else
			if(isMaskPed(mask))
				coeff = (mask-0.2) * 10.0;
			else
				if(isMaskVehicle(mask))
					coeff = (mask-0.4) * 10.0;
				else
					if(isMaskWater(mask))
						coeff = (mask-0.6) * 10.0;
					else
						if(isMaskEffect(mask))
							coeff = (mask-0.8) * 10.0;
							
		return clamp(coeff, 0.0, 1.0);
	}
	
	
	float timeStep(float t1, float t2){
		float tout = (1.0 / (t2 - t1)) * (GameTime - t1);
		return tout >= 1.0 ? 1.0 : tout <= 0.0 ? 0.0 : tout;
	}

float GetVolumetricFog(float3 wpos, float curDepth)
{
	float3 worldpos = wpos+campos; 
	float3 view = normalize(wpos.xyz);
	
	float3 w1 = normalize(worldpos.xyz-float3(campos.xy, 0.0));
	
	float p2 = length(wpos.xyz);  
	float dp = -1.0/exp(length(0.0-p2)/250.0);  
	float depth = lerp(1.0, exp(log(curDepth) * 20.0*c_fogDistance), dp); 		 
	float f0 = exp(log(depth) * -10.0); 
	
	float3 vec1 = normalize(float3(0.0, 0.0, 1.0));	  
	float fog = saturate(1.0 - dot(vec1, w1));
	fog = exp(log(fog) * (7.0 * (c_fogDistance * 1.5)));
	float ttl = fog*f0;
	
	if(curDepth<1.0)
		ttl = max(ttl, clamp((p2 - FogDistances.x) * FogDistances.z, 0.0, 0.9) * clamp(c_fogDistance+0.4, 0.0, 1.0));
	if(view.z<0.0)
		ttl = max(ttl, clamp((p2 - FogDistances.x) * FogDistances.z*clamp(-view.z* 10.0, 0.0, 1.0), 0.0, 1.0)* clamp(c_fogDistance+0.4, 0.0, 1.0));
	return ttl;
}
	
	#include "posFunction.shader";
	#include "atmosphericScattering.shader";
	#include "SSAO.shader";
	#include "VolumetricCloud.shader";
	#include "Clouds2D.shader";
	#include "SSR.shader";
	#include "waterPostProcessing.shader";
	#include "lightingPostProcessing.shader";
	

float3 shadowBlur(vec3 viewDirection, vec3 normal){
	float rad = clamp(viewDirection.x*normal.x+viewDirection.y*normal.y+viewDirection.z*normal.z, 0.0, 1.0);
	
	float curcol = textureLod(componentMap, vTexCoord, 0.0).g;
	float radius = 0.007;
	if(curcol > 0.0 && curcol < 1.0){
		float res = 0.0;
		int i;
		
		//x
		float x;
		x = 0.0;
		for(i = 0; i < 4; i++){
			if(textureLod(componentMap, vTexCoord + vec2(float(i) * radius, 0.0) * rad, 0.0).g == 1.0)
			{
				x += ((1.0-curcol) / float(i+1));
				break;
			}
		}
		res += x;
		
		//-x
		x = 0.0;
		for(i = 0; i < 4; i++){
			if(textureLod(componentMap, vTexCoord - vec2(float(i) * radius, 0.0) * rad, 0.0).g == 1.0)
			{
				x += ((1.0-curcol) / float(i+1));
				break;
			}
		}
		res += x;
		
		//y
		x = 0.0;
		for(i = 0; i < 4; i++){
			if(textureLod(componentMap, vTexCoord + vec2(0.0, float(i) * radius) * rad, 0.0).g == 1.0)
			{
				x += ((1.0-curcol) / float(i+1));
				break;
			}
		}
		res += x;
		
		//-y
		x = 0.0;
		for(i = 0; i < 4; i++){
			if(textureLod(componentMap, vTexCoord - vec2(0.0, float(i) * radius) * rad, 0.0).g == 1.0)
			{
				x += ((1.0-curcol) / float(i+1));
				break;
			}
		}
		res += x;

		return vec3(min(res, 1.0 - curcol));
	}
	
	return vec3(0.0);
}


	void main()
	{
		vec3 brightColor = vec3(0.0),
			godRaySun = vec3(0.0),
			colorComponent,
			normal,
	    	ssr_puddleLevel;
		
		vec4 v_SSR = vec4(0.0, 0.0, 0.0, 0.0),
			cloud = vec4(0.0, 0.0, 0.0, 0.0),
			cloud2D = vec4(0.0, 0.0, 0.0, 0.0),
			color;
		
		float curDepth = textureLod(DepthMap, vTexCoord, 0.0).r;
		
		// check for mirroring
		if(isMirroring != 0 && curDepth >= 1.0){
			fragColor = textureLod(Diffuse, vTexCoord, 0.0);
			out_godRay = vec4(0.0);
			out_BrightSpec = vec4(0.0);
			return;
		}
		
		vec3 worldpos = GWP(vTexCoord, curDepth).xyz,
	    	viewDirection = normalize(worldpos),
			fragPos = vec3(worldpos + campos * 2.0);
		
		if(curDepth < 1.0)
		{
			color = vec4(textureLod(Diffuse, vTexCoord, 0.0).rgb, 1.0);
			colorComponent = textureLod(componentMap, vTexCoord, 0.0).rgb;
			normal = -(textureLod(NormalMap, vTexCoord, 0.0).rgb  * 2.0 - 1.0);
		}

		float myMask = colorComponent.r,
			shadow = colorComponent.g,
			gBrightness = colorComponent.b,
			SSR_Value = getMaskCoefficient(myMask);
		
		       
		//color.rgb *= 1.0 + shadowBlur(viewDirection.xyz, normal.xyz);

		// volumetric clouds
		if(enableCloud){
			float dist = distance(float3(0.0, 0.0, 0.0), worldpos.xyz);
		 
			float3 lightDirection = lerp(sunDirection, moonPos, nightValue);
			cloud = VolumetricCloud(viewDirection.xyz, campos, dist, curDepth, ((TimeMS / 1000.0) * speed * 1500.0) + 4000.0, lightDirection);
		}
		
		// atmospheric scattering
		if(curDepth >= 1.0 && cloud.a < 1.0 && cloud2D.a < 1.0)
			color.rgb = GetAtmosphericScattering(viewDirection, sunDirection, 1.0, 1.0, 1.0, 1.0);
		 
		// SSR Value Building 
		if(RainValue[1] > 0.0 && isMaskBuilding(myMask) && -normal.z > 0.75)
			SSR_Value = RainValue[1];
		
		// SSR Value Vehicle
		if(SSR_Value > 0.0 && isMaskVehicle(myMask)) {
			float fresnel = viewDirection.x*normal.x+viewDirection.y*normal.y+viewDirection.z*normal.z;
			SSR_Value = clamp(1.0 - (fresnel * 1.4 + 0.1), 0.2, 0.5);
			//color.rgb *= vec3(1.0-pow(1.0 - clamp(fresnel * 1.8 + 0.2, 0.5, 1.0), 2.0));
		}

		// Screen Space Reflection
		if(curDepth < 1.0 && SSR_Value > 0.0 && !isMaskWater(myMask)) {
			v_SSR = SDX_SSR(worldpos, ssr_puddleLevel, myMask, SSR_Value, normal, curDepth);
			color.rgb = mix(color.rgb, v_SSR.rgb, min(v_SSR.a, 1.0));
		}
		
		// Generate SSAO
		bool isAO = false;
		if(max(sunColor.r, max(sunColor.g, sunColor.b)) <= 0.07)
			isAO = true;
		else
			if(shadow == 0.0 || shadow < 1.0)
				isAO = true;
	
		if(isSSAO && isAO == true && !isMaskVehicle(myMask) && !isMaskPed(myMask) && curDepth < 1.0 && ssr_puddleLevel.r < 1.0 && !isMaskWater(myMask))
		{
			float sa = saturate(PS_AO(worldpos, curDepth, normal));
			if(shadow != 0.0)
				sa = clamp(pow(sa*(shadow+1.0), 1.5), 0.0, 1.0);
			color.rgb *= sa;
		}
		
		// water
		if(isMaskWater(myMask))
			color.rgb = getWater(worldpos.xyz, normal, curDepth, colorComponent.b, SSR_Value, shadow, brightColor).rgb * clamp(shadow * 1.5, 0.0, 1.0);
		
		// specular lighting (with puddle)
		if(isMaskBuilding(myMask) && max(sunColor.r, max(sunColor.g, sunColor.b)) > 0.1 && shadow == 1.0 ) {
			vec3 direction = normalize(reflect(viewDirection,  normal.xyz));
			float sun_direction = saturate(direction.x*sunDirection.x+direction.y*sunDirection.y+direction.z*sunDirection.z);

    		float lmult = 1.0;

			// surfaces between completely watery and not
    		if(ssr_puddleLevel.r > 0.0 && ssr_puddleLevel.r < 1.0)
    			lmult = max(lmult, 3.0 * ssr_puddleLevel.g);

			lmult *= SpecularLight_Mult;
			// if puddle is not really watery
    		if(ssr_puddleLevel.r < 1.0)
			{
				float spec = exp(log(sun_direction) * 24.0);
					
				float3 CCL = (sunColor * spec) * lmult;
				color.rgb += CCL * pow(abs(normal.z), 8.0);
					
				if(ssr_puddleLevel.r > 0.0)
					brightColor += 0.9* CCL * pow(abs(normal.z), 8.0);
					
    		} else {
				// if surface completely watery
				if(ssr_puddleLevel.r >= 1.0)
    			{
    				direction = normalize(reflect(viewDirection,  normal));
					sun_direction = saturate(direction.x*sunDirection.x+direction.y*sunDirection.y+direction.z*sunDirection.z);
		 	   		
					float sunb = sun_direction*sun_direction;
					sunb = sunb >= 0.999 ? sunb : 0.0;
						
    				//color.rgb += 7.0 * sunColor * sunb;
    				brightColor += 7.0 * sunColor * sunb;
    			}
			}
		}
		
		// blood lighting
		if(isMaskEffect(myMask)){
			vec3 directionbb = normalize(reflect(viewDirection,  normal.xyz));
			float sun_directionbb = saturate(directionbb.x*sunDirection.x+directionbb.y*sunDirection.y+directionbb.z*sunDirection.z);
			float specs = exp(log(sun_directionbb) * 64.0);
			color.rgb += sunColor * specs * getMaskCoefficient(myMask) * 0.7;
		}
		
		// vehicle sun bright
		if(SSR_Value > 0.0 && shadow == 1.0 && isMaskVehicle(myMask) && max(sunColor.r, max(sunColor.g, sunColor.b)) > 0.1) {
			vec3 directionv = normalize(reflect(viewDirection,  normal.xyz));
			float sun_directionv = saturate(directionv.x*sunDirection.x+directionv.y*sunDirection.y+directionv.z*sunDirection.z);
		 	
			brightColor += 7.0*vec3(sunColor)* exp(700.0 * log(sun_directionv));
			color.rgb += vec3(sunColor)* exp(log(sun_directionv) * ( 1000.0 ));
		}
		
		// lighting
		float3 lightcount = vec3(0.0);
		if(curDepth < 1.0)
			lightcount = getLight(color.rgb, fragPos, normal, gBrightness)*clamp(1.0-ssr_puddleLevel.r, 0.0, 1.0);
		color.rgb += lightcount;
		
		// volumetric fog
		color.rgb = mix(color.rgb, c_fogColor+lightcount, GetVolumetricFog(worldpos.xyz, curDepth));    
		
		color.xyz = lerp(color.rgb, cloud.rgb, cloud.a);
		
		// god ray out color
		if(isGodRayEnable_menu && curDepth >= 1.0 && cloud.a < 1.0)
		{
			float sun_direction = viewDirection.x*sunDirection.x+viewDirection.y*sunDirection.y+viewDirection.z*sunDirection.z;
	 	   float cosine = clamp(sun_direction, 0.0, 1.0);
        
			vec3 gdc = sunColor * exp(log(cosine) * ((1.0 - c_godRayValue) * 100.0));
		
        	float gd = ( 1.0 - min(1.0, cloud.a))  * c_godRayValue;
			godRaySun = gdc * gd * 0.9;
		}
		
		// final color
		fragColor = vec4(pow(color.rgb, vec3(1.55)), 1.0);
		
		// bright color
		out_BrightSpec = vec4(mix(brightColor, pow(fragColor.rgb, vec3(200.0))*0.01, nightValue), 1.0);
		
		// god ray sun
		out_godRay = vec4(godRaySun, 1.0);
	}
</frag>