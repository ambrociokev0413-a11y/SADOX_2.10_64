# AML Plugin SDK

A Plugin SDK for an easier mods creation for everyone!

If your code is very performance heavy, you might want to use your own stuff. Otherwise, feel free to use it!

Supported games:
- GTA: SA v2.00
- GTA: SA v2.10 (64-bit)

# How to use me?
It's an empty project. Simply open it in VS Code (preferred way) and start doing everything right there!

# Requirements
- Android NDK, C++17 or newer

I personally recommend using Visual Studio Code (VS Code) with PowerShell for better developing experience. If you're on Android, you're free to use different stuff, such as **AIDE - Android IDE**. You can also use AndroidIDE by **itsaky** if you know how to get it. Nothing limits your freedom!

# Additional information
The project for GTA-games is trying to utilise names that are found in DK22Pac/plugin-sdk for compatibility and better user experience. Check out the PC version!

# Mods using PSDK (source code available, there is more mods now!)
- https://github.com/AndroidModLoader/GTASA_OnlineRadio
- https://github.com/TecoReacviteGaming/GTASA_CLEOVisualObject
- https://github.com/AndroidModLoader/GTASA_PedFuncs
- https://github.com/odeviceblack/aml-bikeflipfix
- and many more..!
