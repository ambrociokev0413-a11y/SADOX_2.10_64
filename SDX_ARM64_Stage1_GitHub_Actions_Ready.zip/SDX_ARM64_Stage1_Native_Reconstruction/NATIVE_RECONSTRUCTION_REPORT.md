# SDX ARM64 Stage 1 — Native Reconstruction Report

## Status

**Stage 1 source package created; no replacement `.so` has been built or runtime-tested yet.** This is the native dependency-binding and reverse-engineering stage. It is deliberately a diagnostic plugin and must not be installed in place of the original SDX library as a graphics replacement.

## 1. Original native entry points

The original `libSDX.so` is ELF32 / ARM / EABI5, Android API 21, and has a 20,336-byte file size. Its relevant native symbols include:

| Symbol | ELF address | Size | Finding |
|---|---:|---:|---|
| `OnModLoad` | `0x191C` | 616 bytes | Checks the loaded game binary fingerprint and seeds 32-bit globals / addresses. |
| `_Z9onSDXLoadv` | `0x1B90` | 9,384 bytes | Main native bootstrap for script resources and game integration. |
| `ARMHook::getLibraryAddress` | `0x422C` | 172 bytes | Parses `/proc/<pid>/maps` to discover a library mapping; returns a 32-bit address. |
| `ARMHook::getSymbolAddress` | `0x432C` | 38 bytes | Opens a library and resolves a symbol; stores/returns the result through 32-bit address types. |
| `ARMHook::unprotect` | `0x4352` | 42 bytes | Memory protection helper. |
| `ARMHook::putFunction` | `0x437C` | 64 bytes | ARM32/Thumb patch helper. |
| `ARMHook::writeMemory` | `0x43BC` | 108 bytes | Memory writer using 32-bit addresses and ARM cache/protection helpers. |
| `ARMHook::makeNOP` | `0x4428` | 84 bytes | ARM32/Thumb NOP patch helper. |

The symbol table also exposes 4-byte globals for `g_libGTASA`, `gameVersion`, script buffers, opcode/script pointers, and initialization state. These layouts cannot be carried to 64-bit unchanged.

## 2. Game version detection in old `OnModLoad`

The ARM32 code reads a 32-bit marker at `libGTASA base + 0x39ABBC`, then compares it with these values:

| Marker | Internal gameVersion value | Version branch |
|---:|---:|---|
| `0xAF00B580` | `108` (`0x6C`) | GTA SA 1.08 |
| `0x447D4D5E` | `200` (`0xC8`) | GTA SA 2.00 |
| `0xD10B4282` | `210` (`0xD2`) | GTA SA 2.10 |

These are findings from the ARM32 machine code, not validated AArch64 fingerprints. The marker offset and patch addresses belong to the 32-bit executable. Stage 1 does not read or reuse them.

## 3. Main bootstrap flow inferred from `onSDXLoad`

The 9,384-byte function is a large native initializer. Disassembly indicates this order at a high level:

1. Check a one-shot initialization flag and clear it on completion.
2. Zero several script/runtime work buffers (observed loop lengths include `0x400`, `0x186A0`, `0x3FFFC`, and `0x320`).
3. Resolve game file-manager and script-runtime dependencies from mangled names.
4. Open and process `SA_DOX/data/script/~~CScripts~~Initialise.x`, `SA_DOX/data/script/~~CScripts~~Main.x`, and `SA_DOX/data/script/include/function.bin`.
5. Allocate and initialize runtime tables/buffers.
6. Invoke the original ARM32 patch helper repeatedly to connect script/native routines and alter game code/data.
7. Finish initialization and reset the one-shot state flag.

The function's direct PLT calls include 73 calls to `ARMHook::putFunction`, 8 calls to `malloc`, 3 calls to `__aeabi_memclr`, 1 call to `__aeabi_memcpy8`, and 6 calls to `memset`. It also makes indirect calls through resolved function pointers. This confirms that the original native layer is not just a script loader; it mutates executable state.

## 4. Resource/script evidence

The supplied SA_DOX Ultra preset contains the direct native bootstrap files:

- `SA_DOX/data/script/~~CScripts~~Initialise.x`
- `SA_DOX/data/script/~~CScripts~~Main.x`
- `SA_DOX/data/script/include/function.bin`

It also contains rendering scripts, shader sources, textures, `timecyc.dat`, `obj.dat`, and `colorcycle.dat`.

The readable `~~CScripts~~Initialise.txt` is valuable behavioral source, but is not a complete rebuildable source tree. It includes missing `../SAAdox.h`, `../OpenGL.h`, and `../menu.h`. It references several files absent from the supplied preset, including `arm64.bin`, `ARMLabel.bin`, `string.hash`, `~~CProcess~~Entity.x`, `~~CProcess~~Object.x`, `~~CProcess~~Ped.x`, `~~CProcess~~Vehicle.x`, and `~~CSprites~~Loadfromfile.x`. It also uses the `SAAdox/` path spelling in several literals, while the provided folder is named `SA_DOX/`. These gaps must be reconciled before attempting to rebuild the custom script package.

## 5. AArch64 dependencies available in the supplied game binary

The target `libGTASA.so` is ELF64 / AArch64 and contains the 16 key names referenced by the original SDX native library. They are recorded in `reports/target_2.10_arm64_native_symbols.csv` and used by `jni/main.cpp` for symbol-only resolution.

Important API families include:

- `CFileMgr::OpenFile` and `CFileMgr::SetDirMyDocuments`
- `OS_FileRead`, `OS_FileClose`, and `OS_FileSize`
- `CRunningScript::CollectParameters`, `StoreParameters`, and `GetPointerToScriptVariable`
- NVIDIA / rendering helpers such as `NVHHDDSLoad`, `nv_load_program`, and `_rwCameraValRender`

AML's `GetSym(gameBase, mangledName)` is used rather than reusing an ARM32 offset. The Stage 1 code records typed AArch64 function-pointer aliases for key script/file APIs, but resolves them only; it deliberately does not call them until timing, handle ownership, and script VM semantics are validated on-device.

## 6. Critical ABI incompatibilities

The old native library stores pointers in 32-bit global objects and uses `unsigned int` for address arguments. That is incompatible with an AArch64 process. The ARM32 `ARMHook` code also performs Thumb-oriented function patching, uses 32-bit memory write destinations, and calls ARM-specific cache/protection helpers.

Therefore, the port must replace (not wrap) this layer with:

- `uintptr_t` / `size_t` for all addresses and lengths;
- AArch64 instruction-aware hook/trampoline implementation, preferably AML's AArch64 hook interface where supported;
- symbol-based resolution for exported functions;
- explicit per-build validation for any remaining data offsets;
- instruction-cache synchronization supported on Android AArch64;
- a new AArch64-native script binding path or proof that the existing compiled `.x` VM bytecode is architecture-neutral.

No legacy Thumb opcodes or ARM32 patch addresses are enabled in Stage 1.

## 7. PSDK handling

The included PSDK exposes 64-bit `FILESTREAM` as `uintptr_t` and declares the relevant script/file methods by mangled symbol name. Some PSDK data accessors use a pointer slot / PLT-style address expression rather than the exported object's own ELF virtual address. Do not treat those two address forms as interchangeable. Every PSDK hard-coded value must be validated against the exact game build before it is used.

## 8. Stage 1 source behavior

`jni/main.cpp` now:

- enforces AArch64 at compile time;
- checks AML and the requested GTA SA package;
- obtains the loaded `libGTASA.so` base and mapped length from AML;
- resolves all 16 native names required by original SDX;
- compares runtime symbol offsets with the supplied sample library's ELF virtual addresses;
- binds typed pointers for core file and script APIs, without invoking them;
- checks the three direct SDX bootstrap payload files under AML data roots;
- performs no code patching or game-memory writes.

This is a safer native foundation, not the final replacement plugin.

## 9. Build and runtime validation

The build target is `arm64-v8a`, module name `SDX_ARM64_STAGE1`, Android API 24, C++17. The current work environment did not have Android NDK / `ndk-build`, so no binary was produced here. Build with an installed NDK using `tools/build_arm64.sh` and verify output with `tools/verify_arm64_output.sh`.

On-device validation must confirm AML loads the module and report:

- game package identifier;
- game library base and length;
- number of resolved original SDX symbols;
- number of exact ELF offset matches against this supplied sample;
- native API completeness;
- detected direct payload files.

Only after those logs are captured should Stage 2 enable a minimal, reversible AArch64 hook for one verified function. Do not enable the entire render patch set at once.

## 10. Source provenance and preservation

The original ARM32 `libSDX.so` remains byte-for-byte in `reference/original-libSDX-arm32.so`. SA_DOX Ultra resources and AML/PSDK source references are retained from the user uploads. The user's GTA SA `libGTASA.so` binary is not redistributed in this package.
