# SDX ARM64 Reconstruction — Stage 0 Audit

## Outcome

This package is a **diagnostic ARM64 AML plugin source project and porting audit**, not a completed SDX feature port. It is intentionally named `SDX_ARM64_AUDIT` and must not be used as a replacement for the original `libSDX.so`. No ARM32 patches are executed.

## Confirmed inputs

- Original `libSDX.so`: ELF32, ARM/EABI5, Android API 21, 20,336 bytes. SHA-256: `a8fa352011c8ec4a21985ec0d006da1e5943048a96705126c6e1cf5f094d8f13`.
- Supplied GTA SA library: `lib/arm64-v8a/libGTASA.so`, ELF64 AArch64, 54,731,968 bytes. SHA-256: `92b3714534742cf8e31eba35dbfd5e83871ecb5b936f5519d9b6ef3562234f9e`.
- Target application identifier embedded in original plugin: `com.rockstargames.gtasa`.
- Original plugin exports include `OnModPreLoad`, `OnModLoad`, `OnModUnLoad`, `JNI_OnLoad`, `JNI_OnUnload`, and `_Z9onSDXLoadv`.
- Original plugin dynamically references SA game functions by mangled symbol names and loads `libGTASA.so`; the matching 2.10 AArch64 game library exports those same names.
- SA_DOX Ultra preset assets are included under `reference/SA_DOX_Ultra/SA_DOX/`. This includes shaders, textures, timecyc/colorcycle/object data, script binaries, `Initialise.txt`, `function.bin`, and `ScriptCommands.hash`.
- The PSDK source archive contains AArch64-capable `aml-psdk` headers and a `sautils_2_10_x64.cpp` integration reference; both are preserved in the project. That older source also includes two custom headers (`AArch64_ModHelper/ARMv8_ASMHelper.h` and `GTASA_STRUCTS_210.h`) that were not included in the supplied archives, so it is a reference rather than a standalone build unit.

## Target-game symbol matches

The user-supplied AArch64 `libGTASA.so` exposes all 16 symbols listed in `reports/GTASA_2.10_ARM64_symbol_map.csv`. Particularly important script/file-manager exports include `CRunningScript::StoreParameters`, `CRunningScript::CollectParameters`, `CRunningScript::GetPointerToScriptVariable`, `OS_FileRead`, `OS_FileClose`, `OS_FileSize`, and `CFileMgr::OpenFile`.

The numeric addresses in that CSV and in `jni/main.cpp` are ELF virtual addresses from this exact sample binary, not universal offsets. The bootstrap resolves by symbol name and merely compares the observed offset; it never writes to those locations.

## Why Stage 0 does not yet restore SDX effects

`SA_DOX/ data/script/~~CScripts~~Initialise.txt` contains 453 `ARM.memprotect2` operations and 125 `longPatch` references. Many carry ARM32/Thumb instruction values or addresses. The precompiled `.x` scripts and `function.bin` are present, but compiled scripts are not equivalent to native C++ source and the existing patch instructions are not valid AArch64 instructions. They must be individually mapped and ported; blindly applying them would risk crashing the game.

The original native library has a 9,384-byte `onSDXLoad` routine and its source is not present. This stage recovers AML bootstrap behavior and verifies target game symbols but does not yet reproduce every native operation performed by that routine.

## Missing build tooling in this environment

No Android NDK installation or `ndk-build` executable was available in the build environment, so **no `.so` has been compiled here**. The project is prepared for Android NDK r23+ / r27-style `ndk-build`, targeting only `arm64-v8a` and Android API 24.

## Next engineering stages

1. Compile and load-test the diagnostic AML module on device; capture AML logs and verify all expected symbols resolve.
2. Reconstruct the original `onSDXLoad` native behavior from the ARM32 disassembly and script interfaces.
3. Convert the 2.10 script patch inventory to verified AArch64 symbol/signature-based hooks. Do not carry across ARM32 addresses or opcodes.
4. Determine whether the `.x` script files are portable through the existing script VM or require a new AArch64 script package/compiler.
5. Rebuild feature-by-feature, starting from file/script bootstrap, then RenderWare/OpenGL hooks and shader/resource loading.
6. Runtime test boot, resume, save loading, graphics initialization, and normal gameplay before enabling further patches.

## Safety and preservation

The original library is copied byte-for-byte to `reference/original-libSDX-arm32.so`. The supplied GTA SA `libGTASA.so` is not redistributed in this project. No original input file is modified.
