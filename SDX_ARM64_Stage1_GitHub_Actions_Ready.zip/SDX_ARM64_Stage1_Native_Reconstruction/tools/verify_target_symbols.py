#!/usr/bin/env python3
"""Check that the supplied target libGTASA.so exposes SDX's native dependencies."""
import argparse
import csv
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("libgtasa", type=Path, help="path to arm64-v8a/libGTASA.so")
    parser.add_argument(
        "--map",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "reports/target_2.10_arm64_native_symbols.csv",
    )
    args = parser.parse_args()
    if not args.libgtasa.is_file() or not args.map.is_file():
        print("input file not found", file=sys.stderr)
        return 2

    result = subprocess.run(["readelf", "-Ws", str(args.libgtasa)], capture_output=True, text=True)
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        return 2

    present = set()
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) >= 8:
            present.add(fields[7])

    with args.map.open(newline="", encoding="utf-8") as handle:
        names = [row["mangled_symbol"] for row in csv.DictReader(handle)]

    missing = [name for name in names if name not in present]
    print(f"Resolved names: {len(names) - len(missing)}/{len(names)}")
    if missing:
        for name in missing:
            print(f"MISSING {name}")
        return 1
    print("All required original SDX game symbols are present.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
