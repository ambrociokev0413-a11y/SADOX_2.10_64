#!/usr/bin/env bash
set -euo pipefail
SO="${1:-out/libs/arm64-v8a/libSDX_ARM64_STAGE1.so}"
if [[ ! -f "$SO" ]]; then echo "Missing output: $SO" >&2; exit 2; fi
file "$SO"
readelf -h "$SO" | grep -E 'Class:|Machine:'
readelf -Ws "$SO" | grep -E '__GetModInfo|OnModLoad|OnModPreLoad'
