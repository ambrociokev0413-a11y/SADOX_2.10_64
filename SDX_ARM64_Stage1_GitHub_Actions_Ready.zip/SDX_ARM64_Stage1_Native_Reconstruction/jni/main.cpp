#include <mod/amlmod.h>
#include <mod/logger.h>

#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>

#if !defined(__aarch64__)
#error "SDX Stage 1 is ARM64-only. Build with APP_ABI=arm64-v8a."
#endif

static_assert(sizeof(void*) == 8, "AArch64 pointer width is required");
static_assert(sizeof(uintptr_t) == 8, "uintptr_t must be 64-bit");

MYMOD(net.sdx.arm64.stage1, SDX_ARM64_Stage1_Native_Reconstruction, 0.2.0, Community_Reconstruction)
NEEDGAME(com.rockstargames.gtasa);

namespace
{
    // These are ELF virtual addresses from the exact libGTASA.so supplied by
    // the user (SHA-256 is recorded in reports/). They are validation values,
    // not patch locations. Resolve every runtime address through AML by name.
    struct SymbolProbe
    {
        const char* name;
        uint64_t expectedElfVaddr;
        const char* purpose;
    };

    static constexpr SymbolProbe kOriginalSdxSymbols[] =
    {
        {"_ZN8CFileMgr12fileDataAreaE", 0x00BC11C8ULL, "CFileMgr file data area object"},
        {"_ZN14CRunningScript15StoreParametersEs", 0x003F22D0ULL, "script parameter writer"},
        {"_Z11OS_FileReadPvS_i", 0x0031C190ULL, "OS file read"},
        {"_ZN14CRunningScript17CollectParametersEs", 0x003F1FCCULL, "script parameter reader"},
        {"_Z12OS_FileClosePv", 0x0031C04CULL, "OS file close"},
        {"_Z11OS_FileSizePv", 0x0031C680ULL, "OS file size"},
        {"_Z11NVLogEnable11ENVLogLevelh", 0x0032F070ULL, "NV logging control"},
        {"_Z18MoveColModelMemoryR9CColModelb", 0x004D6790ULL, "collision model memory move"},
        {"_Z11NVHHDDSLoadPKci", 0x0032B308ULL, "DDS texture loader"},
        {"_ZN8CProfile10InitialiseEv", 0x004F2594ULL, "profile initialization"},
        {"_Z11NvQuatNLerpPfPKfS1_f", 0x00331488ULL, "quaternion interpolation"},
        {"_ZN14CRunningScript26GetPointerToScriptVariableEh", 0x003F2654ULL, "script variable pointer"},
        {"_ZN8CFileMgr17SetDirMyDocumentsEv", 0x004D29BCULL, "set documents directory"},
        {"_Z18_rwCameraValRenderP8RwCamera", 0x0026E458ULL, "RenderWare camera validation"},
        {"_Z15nv_load_programPKcS0_", 0x0033170CULL, "NV program loader"},
        {"_ZN8CFileMgr8OpenFileEPKcS1_", 0x004D2B74ULL, "CFileMgr file open"},
    };

    // Typed declarations document the intended AArch64 ABI for the most
    // important native dependencies. Stage 1 resolves but does not call them:
    // script/file semantics and call timing still need device-level validation.
    using CFileMgrOpenFileFn = uintptr_t (*)(const char*, const char*);
    using CFileMgrSetDirMyDocumentsFn = void (*)();
    using OSFileReadFn = int (*)(void*, void*, int);
    using OSFileCloseFn = int (*)(void*);
    using OSFileSizeFn = int (*)(void*);
    using ScriptParamsFn = void (*)(void*, int16_t);
    using ScriptVarPointerFn = void* (*)(void*, uint8_t);

    struct NativeApi
    {
        uintptr_t fileDataArea = 0;
        CFileMgrOpenFileFn openFile = nullptr;
        CFileMgrSetDirMyDocumentsFn setDirMyDocuments = nullptr;
        OSFileReadFn fileRead = nullptr;
        OSFileCloseFn fileClose = nullptr;
        OSFileSizeFn fileSize = nullptr;
        ScriptParamsFn storeParameters = nullptr;
        ScriptParamsFn collectParameters = nullptr;
        ScriptVarPointerFn getPointerToScriptVariable = nullptr;
        uintptr_t nvDdsLoad = 0;
        uintptr_t nvLoadProgram = 0;
        uintptr_t renderWareCameraCheck = 0;
    };

    static NativeApi g_api;
    static bool g_stage1Loaded = false;

    static uintptr_t Resolve(const uintptr_t gameBase, const char* symbol)
    {
        if (!aml || !gameBase || !symbol || !*symbol)
            return 0;
        return aml->GetSym(gameBase, symbol);
    }

    static bool CheckPayloadFile(const char* root, const char* relativePath)
    {
        if (!root || !*root || !relativePath)
            return false;

        char fullPath[1024] = {};
        const size_t rootLen = std::strlen(root);
        const bool hasSlash = rootLen > 0 && (root[rootLen - 1] == '/' || root[rootLen - 1] == '\\');
        const int written = std::snprintf(fullPath, sizeof(fullPath), "%s%s%s",
            root, hasSlash ? "" : "/", relativePath);
        if (written <= 0 || static_cast<size_t>(written) >= sizeof(fullPath))
            return false;

        FILE* file = std::fopen(fullPath, "rb");
        if (!file)
            return false;
        std::fclose(file);
        return true;
    }

    static void AuditPayload()
    {
        static constexpr const char* kRequired[] =
        {
            "SA_DOX/data/script/~~CScripts~~Initialise.x",
            "SA_DOX/data/script/~~CScripts~~Main.x",
            "SA_DOX/data/script/include/function.bin",
        };

        const char* roots[2] = { aml->GetAndroidDataPath(), aml->GetDataPath() };
        unsigned found = 0;
        unsigned checkedRoots = 0;
        for (const char* root : roots)
        {
            if (!root || !*root)
                continue;
            ++checkedRoots;
            for (const char* rel : kRequired)
            {
                if (CheckPayloadFile(root, rel))
                    ++found;
            }
        }

        if (checkedRoots == 0)
        {
            logger->Info("Payload check skipped: AML did not expose data roots");
        }
        else if (found == 0)
        {
            logger->Info("SA_DOX payload not found under AML data roots; this is a diagnostic only");
        }
        else
        {
            logger->Info("SA_DOX direct payload files detected: %u/%u across %u roots",
                found, static_cast<unsigned>(sizeof(kRequired) / sizeof(kRequired[0])) * checkedRoots,
                checkedRoots);
        }
    }

    static void BindNativeApi(const uintptr_t gameBase)
    {
        g_api.fileDataArea = Resolve(gameBase, "_ZN8CFileMgr12fileDataAreaE");
        g_api.openFile = reinterpret_cast<CFileMgrOpenFileFn>(Resolve(gameBase, "_ZN8CFileMgr8OpenFileEPKcS1_"));
        g_api.setDirMyDocuments = reinterpret_cast<CFileMgrSetDirMyDocumentsFn>(Resolve(gameBase, "_ZN8CFileMgr17SetDirMyDocumentsEv"));
        g_api.fileRead = reinterpret_cast<OSFileReadFn>(Resolve(gameBase, "_Z11OS_FileReadPvS_i"));
        g_api.fileClose = reinterpret_cast<OSFileCloseFn>(Resolve(gameBase, "_Z12OS_FileClosePv"));
        g_api.fileSize = reinterpret_cast<OSFileSizeFn>(Resolve(gameBase, "_Z11OS_FileSizePv"));
        g_api.storeParameters = reinterpret_cast<ScriptParamsFn>(Resolve(gameBase, "_ZN14CRunningScript15StoreParametersEs"));
        g_api.collectParameters = reinterpret_cast<ScriptParamsFn>(Resolve(gameBase, "_ZN14CRunningScript17CollectParametersEs"));
        g_api.getPointerToScriptVariable = reinterpret_cast<ScriptVarPointerFn>(Resolve(gameBase, "_ZN14CRunningScript26GetPointerToScriptVariableEh"));
        g_api.nvDdsLoad = Resolve(gameBase, "_Z11NVHHDDSLoadPKci");
        g_api.nvLoadProgram = Resolve(gameBase, "_Z15nv_load_programPKcS0_");
        g_api.renderWareCameraCheck = Resolve(gameBase, "_Z18_rwCameraValRenderP8RwCamera");

        const bool scriptApiReady = g_api.storeParameters && g_api.collectParameters &&
            g_api.getPointerToScriptVariable;
        const bool fileApiReady = g_api.openFile && g_api.fileRead && g_api.fileClose && g_api.fileSize;
        logger->Info("Native API readiness: script=%s file=%s render=%s",
            scriptApiReady ? "resolved" : "incomplete",
            fileApiReady ? "resolved" : "incomplete",
            (g_api.nvDdsLoad && g_api.nvLoadProgram && g_api.renderWareCameraCheck) ? "resolved" : "incomplete");
    }

    static void AuditOriginalSymbols(const uintptr_t gameBase)
    {
        unsigned found = 0;
        unsigned exactOffset = 0;
        for (const SymbolProbe& probe : kOriginalSdxSymbols)
        {
            const uintptr_t address = Resolve(gameBase, probe.name);
            if (!address)
            {
                logger->Error("Required original symbol missing: %s (%s)", probe.name, probe.purpose);
                continue;
            }

            ++found;
            const uint64_t offset = static_cast<uint64_t>(address - gameBase);
            if (offset == probe.expectedElfVaddr)
            {
                ++exactOffset;
                logger->Info("Symbol OK +0x%llX: %s",
                    static_cast<unsigned long long>(offset), probe.purpose);
            }
            else
            {
                logger->Info("Symbol present but build offset differs: %s runtime=+0x%llX sample=+0x%llX",
                    probe.name,
                    static_cast<unsigned long long>(offset),
                    static_cast<unsigned long long>(probe.expectedElfVaddr));
            }
        }

        logger->Info("Original SDX dependency audit: %u/%u symbols resolved; %u exact sample offsets",
            found, static_cast<unsigned>(sizeof(kOriginalSdxSymbols) / sizeof(kOriginalSdxSymbols[0])),
            exactOffset);
    }
}

ON_MOD_PRELOAD()
{
    if (logger)
    {
        logger->SetTag("SDX_ARM64_STAGE1");
        logger->Info("Stage 1 native reconstruction preload reached");
    }
}

ON_MOD_LOAD()
{
    if (logger)
        logger->SetTag("SDX_ARM64_STAGE1");

    if (!aml || !logger)
    {
        if (logger) logger->Error("AML interface unavailable; no native work started");
        return;
    }

    if (g_stage1Loaded)
    {
        logger->Info("Stage 1 initialization already audited; skipping duplicate pass");
        return;
    }
    const char* currentGame = aml->GetCurrentGame();
    logger->Info("AML game identifier: %s", currentGame ? currentGame : "<null>");
    const uintptr_t gameBase = aml->GetLib("libGTASA.so");
    const uintptr_t gameLength = aml->GetLibLength("libGTASA.so");
    if (!gameBase || !gameLength)
    {
        logger->Error("libGTASA.so is not available yet; no hooks or writes attempted");
        return;
    }

    g_stage1Loaded = true;
    logger->Info("AArch64 game library base=%p length=0x%llX pointer-size=%u",
        reinterpret_cast<void*>(gameBase),
        static_cast<unsigned long long>(gameLength),
        static_cast<unsigned>(sizeof(void*)));

    AuditOriginalSymbols(gameBase);
    BindNativeApi(gameBase);
    AuditPayload();

    // Explicit Stage 1 boundary: all original function pointers are bound for
    // audit only. No legacy offsets, Thumb opcodes, code patches, trampoline
    // writes, or script VM mutation are enabled in this build.
    logger->Info("Stage 1 audit complete. ARM32 patch engine remains disabled until each hook is ported and verified for AArch64.");
}

ON_MOD_UNLOAD()
{
    if (logger)
        logger->Info("SDX ARM64 Stage 1 diagnostic module unloading");
}
