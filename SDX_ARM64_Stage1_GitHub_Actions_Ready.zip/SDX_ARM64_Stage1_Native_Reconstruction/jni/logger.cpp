#include <mod/logger.h>
#include <android/log.h>

#include <cstdarg>
#include <cstdio>
#include <cstring>

static Logger g_sdxLogger;
Logger* logger = &g_sdxLogger;

Logger::Logger()
{
    std::strncpy(m_szTag, "SDX_ARM64_AUDIT", sizeof(m_szTag) - 1);
    m_szTag[sizeof(m_szTag) - 1] = '\0';
    m_bEnabled = true;
    m_fnLogCallback = nullptr;
    m_fnNewTagCallback = nullptr;
    m_fnToggledCallback = nullptr;
}

void Logger::ToggleOutput(bool enabled)
{
    if (m_bEnabled == enabled) return;
    m_bEnabled = enabled;
    if (m_fnToggledCallback) m_fnToggledCallback(enabled);
}

void Logger::SetTag(const char* tag)
{
    if (!tag) return;
    if (m_fnNewTagCallback) m_fnNewTagCallback(m_szTag, tag);
    std::strncpy(m_szTag, tag, sizeof(m_szTag) - 1);
    m_szTag[sizeof(m_szTag) - 1] = '\0';
}

void Logger::PrintV(eLogPrio prio, const char* message, va_list args)
{
#ifndef NOLOGGING
    if (!m_bEnabled || !message) return;
    char buffer[TMPBUF_SIZE];
    std::vsnprintf(buffer, sizeof(buffer), message, args);
    if (m_fnLogCallback) m_fnLogCallback(prio, buffer);
    __android_log_write(static_cast<android_LogPriority>(prio), m_szTag, buffer);
#else
    (void)prio; (void)message; (void)args;
#endif
}

void Logger::Print(eLogPrio prio, const char* message, ...)
{
    va_list args; va_start(args, message); PrintV(prio, message, args); va_end(args);
}

void Logger::PrintTagV(eLogPrio prio, const char* tag, const char* message, va_list args)
{
    (void)tag;
    PrintV(prio, message, args);
}

void Logger::PrintTag(eLogPrio prio, const char* tag, const char* message, ...)
{
    (void)tag;
    va_list args; va_start(args, message); PrintV(prio, message, args); va_end(args);
}

void Logger::InfoV(const char* message, va_list args) { PrintV(LogP_Info, message, args); }
void Logger::ErrorV(const char* message, va_list args) { PrintV(LogP_Error, message, args); }

void Logger::Info(const char* message, ...)
{
    va_list args; va_start(args, message); InfoV(message, args); va_end(args);
}

void Logger::Error(const char* message, ...)
{
    va_list args; va_start(args, message); ErrorV(message, args); va_end(args);
}

void Logger::If(bool condition, const char* message, ...)
{
    if (!condition) return;
    va_list args; va_start(args, message); PrintV(LogP_Info, message, args); va_end(args);
}

void Logger::IfV(bool condition, const char* message, va_list args)
{
    if (condition) PrintV(LogP_Info, message, args);
}
