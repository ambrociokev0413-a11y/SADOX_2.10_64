#ifndef __AML_PSDK_SAPED_H
#define __AML_PSDK_SAPED_H

#include "Physical.h"
#include "Weapon.h"
#include "../enum/PedEnums.h"
#include "../audio/AEAudioEntity.h"

struct CPed;
struct CPedIntelligence;
struct CPlayerData;
struct AnimBlendFrameData;
struct CAnimBlendAssociation;
struct RwFrame;
struct CAccident;
struct CPedStat;
struct CObject;
struct CFire;
struct CCoverPoint;
struct CEntryExit;
struct CVehicle;
struct CWanted;
struct CTaskSimpleHoldEntity;

DECL_CLASS(CAccident)
    // Member functions
    DECL_THISCALL_SIMPLE(IsFree, _ZNK9CAccident6IsFreeEv, bool);

    // Member values
    CPed* m_pInjuredPed;
    bool m_bBeingDealtWith;
    bool m_bHealed;
DECL_CLASS_END()
CHECKSIZE(CAccident, 0x8, 0x10);

DECL_CLASS(CAccidentManager)
    enum { MAX_NUM_ACCIDENTS = 16 };

    // Construct/Deconstruct functions
    DECL_CTORCALL(CAccidentManager, _ZN16CAccidentManagerC2Ev);
    DECL_DTORCALL(CAccidentManager, _ZN16CAccidentManagerD2Ev);

    // Member functions
    DECL_THISCALL_HEAD(ReportAccident, _ZN16CAccidentManager14ReportAccidentEP4CPed, void, CPed* ped)
    DECL_THISCALL_TAIL(ReportAccident, ped)
    DECL_THISCALL_SIMPLE(ComputeNoOfFreeAccidents, _ZNK16CAccidentManager24ComputeNoOfFreeAccidentsEv, i32);
    DECL_THISCALL_HEAD(GetNearestFreeAccident, _ZN16CAccidentManager22GetNearestFreeAccidentERK7CVectorb, CAccident*, CVector const& pos, bool ignoreHeadless)
    DECL_THISCALL_TAIL(GetNearestFreeAccident, pos, ignoreHeadless)
    DECL_THISCALL_HEAD(GetNearestFreeAccidentExceptThisOne, _ZN16CAccidentManager35GetNearestFreeAccidentExceptThisOneERK7CVectorP9CAccidentb, CAccident*, CVector const& pos, CAccident* exceptThisOne, bool ignoreHeadless)
    DECL_THISCALL_TAIL(GetNearestFreeAccidentExceptThisOne, pos, exceptThisOne, ignoreHeadless)

    // Member values
    CAccident m_accidents[MAX_NUM_ACCIDENTS];
DECL_CLASS_END()
CHECKSIZE(CAccidentManager, 0x80, 0x100);

DECL_FASTCALL_SIMPLE_GLO(GetAccidentManager, _Z18GetAccidentManagerv, CAccidentManager*);

DECL_CLASS(CCoverPoint)
    enum
    {
        COVUSE_LOWCOVER = 0,
        COVUSE_WALLTOLEFT = 1,
        COVUSE_WALLTORIGHT = 2,
    };


    // Member functions
    DECL_THISCALL_SIMPLE(CanAccomodateAnotherPed, _ZN11CCoverPoint23CanAccomodateAnotherPedEv, bool);
    DECL_THISCALL_HEAD(ReserveCoverPointForPed, _ZN11CCoverPoint23ReserveCoverPointForPedEP4CPed, void, CPed* pPed)
    DECL_THISCALL_TAIL(ReserveCoverPointForPed, pPed)
    DECL_THISCALL_HEAD(ReleaseCoverPointForPed, _ZN11CCoverPoint23ReleaseCoverPointForPedEP4CPed, void, CPed* pPed)
    DECL_THISCALL_TAIL(ReleaseCoverPointForPed, pPed)

    // Member values
    i8 m_Type;
    i8 m_Usage;
    u8 m_CoverDirection;
    CVector m_Coors;
    CEntity* m_pEntity;
    CPed* m_pPedsUsingThisCover[2];
DECL_CLASS_END()
CHECKSIZE(CCoverPoint, 0x1C, 0x28);

DECL_CLASS(CPedAcquaintance)
    // Member functions
    DECL_THISCALL_HEAD(SetAcquaintances, _ZN13CAcquaintance16SetAcquaintancesEij, void, i32 arg1, u32 arg2)
    DECL_THISCALL_TAIL(SetAcquaintances, arg1, arg2)
    DECL_THISCALL_HEAD(GetAcquaintances, _ZNK13CAcquaintance16GetAcquaintancesEi, u32, i32 arg1)
    DECL_THISCALL_TAIL(GetAcquaintances, arg1)
    DECL_THISCALL_HEAD(SetAsAcquaintance, _ZN13CAcquaintance17SetAsAcquaintanceEij, void, i32 arg1, u32 arg2)
    DECL_THISCALL_TAIL(SetAsAcquaintance, arg1, arg2)
    DECL_THISCALL_HEAD(ClearAsAcquaintance, _ZN13CAcquaintance19ClearAsAcquaintanceEij, void, i32 arg1, u32 arg2)
    DECL_THISCALL_TAIL(ClearAsAcquaintance, arg1, arg2)
    DECL_THISCALL_HEAD(ClearAcquaintances, _ZN13CAcquaintance18ClearAcquaintancesEi, void, i32 arg1)
    DECL_THISCALL_TAIL(ClearAcquaintances, arg1)

    unsigned int m_nRespect;
    unsigned int m_nLike;
    unsigned int m_nIgnore;
    unsigned int m_nDislike;
    unsigned int m_nHate;
DECL_CLASS_END()

struct LimbOrientation
{
    float m_fYaw;
    float m_fPitch;
};

struct LimbMovementInfo 
{
    float maxYaw, minYaw;
    float yawD;
    float maxPitch, minPitch;
    float pitchD;
};

DECL_CLASS(CPedIK)
    CPed *m_pPed;
    LimbOrientation m_TorsoOrien;
    float m_fSlopePitch;
    float m_fSlopePitchLimitMult;
    float m_fSlopeRoll;
    float m_fBodyRoll;
    union
    {
        unsigned int m_nFlags;
        struct
        {
            unsigned int bGunReachedTarget : 1;
            unsigned int bTorsoUsed : 1;
            unsigned int bUseArm : 1;
            unsigned int bSlopePitch : 1;
        };
    };

    // Construct functions
    DECL_CTORCALL_ARG_HEAD(CPedIK, _ZN6CPedIKC2EP4CPed, CPed *pPed)
    DECL_CTORCALL_ARG_TAIL(pPed)

    // Functions
    DECL_FASTCALL_SIMPLE(GetWorldMatrix, _ZN6CPedIK14GetWorldMatrixEP7RwFrameP11RwMatrixTag, RwMatrix*, RwFrame* pFrame, RwMatrix* pMatrix);

    DECL_THISCALL_SIMPLE(PitchForSlope, _ZN6CPedIK13PitchForSlopeEv, void);

    DECL_THISCALL_HEAD(ExtractYawAndPitchWorld, _ZN6CPedIK23ExtractYawAndPitchWorldEP11RwMatrixTagRfS2_, void, RwMatrix* pMatrix, float& yaw, float& pitch)
    DECL_THISCALL_TAIL(ExtractYawAndPitchWorld, pMatrix, yaw, pitch)

    DECL_THISCALL_HEAD(MoveLimb1, _ZN6CPedIK8MoveLimbER15LimbOrientationffR16LimbMovementInfo, MoveLimbResult, LimbOrientation& limb, float yaw, float pitch, LimbMovementInfo& limbInfo)
    DECL_THISCALL_TAIL(MoveLimb1, limb, yaw, pitch, limbInfo)

    DECL_THISCALL_HEAD(MoveLimb2, _ZN6CPedIK8MoveLimbER15LimbOrientationffR16LimbMovementInfof, MoveLimbResult, LimbOrientation& limb, float yaw, float pitch, LimbMovementInfo& limbInfo, float fBlendAmount)
    DECL_THISCALL_TAIL(MoveLimb2, limb, yaw, pitch, limbInfo, fBlendAmount)

    DECL_THISCALL_HEAD(PointGunAtPosition, _ZN6CPedIK18PointGunAtPositionERK7CVectorf, bool, const CVector& pos, float fBlendAmount)
    DECL_THISCALL_TAIL(PointGunAtPosition, pos, fBlendAmount)

    DECL_THISCALL_HEAD(PointGunInDirection, _ZN6CPedIK19PointGunInDirectionEffbf, bool, float yaw, float pitch, bool bRollPitch, float fBlendAmount)
    DECL_THISCALL_TAIL(PointGunInDirection, yaw, pitch, bRollPitch, fBlendAmount)

    DECL_THISCALL_HEAD(RotateTorso, _ZN6CPedIK11RotateTorsoEP18AnimBlendFrameDataR15LimbOrientationb, void, AnimBlendFrameData* pFrameData, LimbOrientation& torso, bool bCancelRoll)
    DECL_THISCALL_TAIL(RotateTorso, pFrameData, torso, bCancelRoll)

    DECL_THISCALL_HEAD(RotateTorsoForArm, _ZN6CPedIK17RotateTorsoForArmERK7CVector, void, const CVector& vecTarget)
    DECL_THISCALL_TAIL(RotateTorsoForArm, vecTarget)

    // Helper functions
    inline i32 MoveLimb(LimbOrientation& limb, float yaw, float pitch, LimbMovementInfo& limbInfo)
    {
        return MoveLimb1(limb, yaw, pitch, limbInfo);
    }
    inline i32 MoveLimb(LimbOrientation& limb, float yaw, float pitch, LimbMovementInfo& limbInfo, float fBlendAmount)
    {
        return MoveLimb2(limb, yaw, pitch, limbInfo, fBlendAmount);
    }

    // STATIC values
    DECL_OBJECT_PLT(LimbMovementInfo, ms_torsoInfo, BYBIT(0x676BC0, 0x84B7C8));
    DECL_OBJECT_PLT(CVector, XaxisIK, BYBIT(0x6761A8, 0x84A3B0));
    DECL_OBJECT_PLT(CVector, YaxisIK, BYBIT(0x678B48, 0x84F6B8));
    DECL_OBJECT_PLT(CVector, ZaxisIK, BYBIT(0x6771C4, 0x84C3C0));

    DECL_OBJECT_ADDR(LimbMovementInfo, ms_headInfo, BYBIT(0x6AF878, 0x88C1B4));
    DECL_OBJECT_ADDR(LimbMovementInfo, ms_headRestoreInfo, BYBIT(0x6AF890, 0x88C1CC));
    DECL_OBJECT_ADDR(LimbMovementInfo, ms_upperArmInfo, BYBIT(0x6AF8C0, 0x88C1FC));
    DECL_OBJECT_ADDR(LimbMovementInfo, ms_lowerArmInfo, BYBIT(0x6AF8D8, 0x88C214));
DECL_CLASS_END()
CHECKSIZE(CPedIK, 0x20, 0x28);

#define ms_torsoInfo ms_torsoInfo()
#define ms_headInfo ms_headInfo()
#define ms_headRestoreInfo ms_headRestoreInfo()
#define ms_upperArmInfo ms_upperArmInfo()
#define ms_lowerArmInfo ms_lowerArmInfo()
#define XaxisIK XaxisIK()
#define YaxisIK YaxisIK()
#define ZaxisIK ZaxisIK()

DECL_CLASS_BASED(CPed, CPhysical)
    // Construct/Deconstruct functions
    DECL_CTORCALL_ARG_HEAD(CPed, _ZN4CPedC2Ej, u32 pedType)
    DECL_CTORCALL_ARG_TAIL(pedType)
    DECL_DTORCALL_VIRTUAL(CPed, _ZN4CPedD2Ev, _ZN4CPed, _ZTV4CPed);
    DECL_NEWCALL(CPed, BYBIT(_ZN4CPednwEj, _ZN4CPednwEm) );
    DECL_DLCALL(CPed, _ZN4CPeddlEPv);

    // Virtual functions
    DECL_VIRTUALCALL_HEAD(CPed, SetMoveAnim, _ZTV4CPed, 24, void)
    DECL_VIRTUALCALL_TAIL()
    DECL_VIRTUALCALL_HEAD(CPed, Save, _ZTV4CPed, 25, bool)
    DECL_VIRTUALCALL_TAIL()
    DECL_VIRTUALCALL_HEAD(CPed, Load, _ZTV4CPed, 26, bool)
    DECL_VIRTUALCALL_TAIL()

    // STATIC values
    DECL_VALUE_PLT_U16(m_sGunFlashBlendStart, BYBIT(0x6782BC, 0x84E590));

    // Member functions
    DECL_THISCALL_SIMPLE(PedIsInvolvedInConversation, _ZN4CPed27PedIsInvolvedInConversationEv, bool);
    DECL_THISCALL_SIMPLE(PedCanPickUpPickUp, _ZN4CPed18PedCanPickUpPickUpEv, bool);
    DECL_THISCALL_SIMPLE(CreateDeadPedMoney, _ZN4CPed18CreateDeadPedMoneyEv, void);
    DECL_THISCALL_SIMPLE(CreateDeadPedWeaponPickups, _ZN4CPed26CreateDeadPedWeaponPickupsEv, void);
    DECL_THISCALL_SIMPLE(IsPlayer, _ZNK4CPed8IsPlayerEv, bool);
    DECL_THISCALL_SIMPLE(ReleaseCoverPoint, _ZN4CPed17ReleaseCoverPointEv, void);
    DECL_THISCALL_SIMPLE(ClearWeapons, _ZN4CPed12ClearWeaponsEv, void);
    DECL_THISCALL_SIMPLE(UpdateStatLeavingVehicle, _ZN4CPed24UpdateStatLeavingVehicleEv, void);
    DECL_FASTCALL_SIMPLE(Initialise, _ZN4CPed10InitialiseEv, void);
    DECL_THISCALL_SIMPLE(SetPedDefaultDecisionMaker, _ZN4CPed26SetPedDefaultDecisionMakerEv, void);
    DECL_THISCALL_SIMPLE(CanUseTorsoWhenLooking, _ZN4CPed22CanUseTorsoWhenLookingEv, bool);
    DECL_FASTCALL_SIMPLE(Update, _ZN4CPed6UpdateEv, void);
    DECL_THISCALL_SIMPLE(PositionAnyPedOutOfCollision, _ZN4CPed28PositionAnyPedOutOfCollisionEv, bool);
    DECL_THISCALL_SIMPLE(ClearAimFlag, _ZN4CPed12ClearAimFlagEv, void);
    DECL_THISCALL_SIMPLE(ClearLookFlag, _ZN4CPed13ClearLookFlagEv, void);
    DECL_THISCALL_SIMPLE(StopNonPartialAnims, _ZN4CPed19StopNonPartialAnimsEv, void);
    DECL_THISCALL_SIMPLE(RestartNonPartialAnims, _ZN4CPed22RestartNonPartialAnimsEv, void);
    DECL_THISCALL_SIMPLE(ClearLook, _ZN4CPed9ClearLookEv, void);
    DECL_THISCALL_SIMPLE(GetWeaponSkill, _ZN4CPed14GetWeaponSkillEv, i8);
    DECL_THISCALL_SIMPLE(CanWeRunAndFireWithWeapon, _ZN4CPed25CanWeRunAndFireWithWeaponEv, bool);
    DECL_THISCALL_SIMPLE(CalculateNewVelocity, _ZN4CPed20CalculateNewVelocityEv, void);
    DECL_THISCALL_SIMPLE(IsPedInControl, _ZN4CPed14IsPedInControlEv, bool);
    DECL_THISCALL_SIMPLE(UpdatePosition, _ZN4CPed14UpdatePositionEv, void);
    DECL_THISCALL_SIMPLE(CalculateNewOrientation, _ZN4CPed23CalculateNewOrientationEv, void);
    DECL_THISCALL_SIMPLE(ClearAll, _ZN4CPed8ClearAllEv, void);
    DECL_THISCALL_SIMPLE(ProcessBuoyancy, _ZN4CPed15ProcessBuoyancyEv, void);
    DECL_THISCALL_SIMPLE(RequestDelayedWeapon, _ZN4CPed20RequestDelayedWeaponEv, void);
    DECL_THISCALL_SIMPLE(PlayFootSteps, _ZN4CPed13PlayFootStepsEv, void);
    DECL_THISCALL_SIMPLE(IsAlive, _ZNK4CPed7IsAliveEv, bool);
    DECL_THISCALL_SIMPLE(IsPedShootable, _ZN4CPed14IsPedShootableEv, bool);
    DECL_THISCALL_SIMPLE(UseGroundColModel, _ZN4CPed17UseGroundColModelEv, bool);
    DECL_THISCALL_SIMPLE(CanSetPedState, _ZN4CPed14CanSetPedStateEv, bool);
    DECL_THISCALL_SIMPLE(CanBeArrested, _ZN4CPed13CanBeArrestedEv, bool);
    DECL_THISCALL_SIMPLE(CanStrafeOrMouseControl, _ZN4CPed23CanStrafeOrMouseControlEv, bool);
    DECL_THISCALL_SIMPLE(CanBeDeleted, _ZN4CPed12CanBeDeletedEv, u8);
    DECL_THISCALL_SIMPLE(CanBeDeletedEvenInVehicle, _ZN4CPed25CanBeDeletedEvenInVehicleEv, u8);
    DECL_THISCALL_SIMPLE(RemoveGogglesModel, _ZN4CPed18RemoveGogglesModelEv, void);
    DECL_THISCALL_SIMPLE(PutOnGoggles, _ZN4CPed12PutOnGogglesEv, void);
    DECL_THISCALL_SIMPLE(TakeOffGoggles, _ZN4CPed14TakeOffGogglesEv, void);
    DECL_THISCALL_SIMPLE(ReplaceWeaponWhenExitingVehicle, _ZN4CPed31ReplaceWeaponWhenExitingVehicleEv, void);
    DECL_THISCALL_SIMPLE(RemoveWeaponForScriptedCutscene, _ZN4CPed31RemoveWeaponForScriptedCutsceneEv, void);
    DECL_THISCALL_SIMPLE(ReplaceWeaponForScriptedCutscene, _ZN4CPed32ReplaceWeaponForScriptedCutsceneEv, void);
    DECL_THISCALL_SIMPLE(ResetGunFlashAlpha, _ZN4CPed18ResetGunFlashAlphaEv, void);
    DECL_THISCALL_SIMPLE(GetBikeRidingSkill, _ZN4CPed18GetBikeRidingSkillEv, float);
    DECL_THISCALL_SIMPLE(PreRenderAfterTest, _ZN4CPed18PreRenderAfterTestEv, void);
    DECL_THISCALL_SIMPLE(SetIdle, _ZN4CPed7SetIdleEv, void);
    DECL_THISCALL_SIMPLE(Look, _ZN4CPed4LookEv, void);
    DECL_THISCALL_SIMPLE(TurnBody, _ZN4CPed8TurnBodyEv, bool);
    DECL_THISCALL_SIMPLE(IsPointerValid, _ZN4CPed14IsPointerValidEv, bool);
    DECL_THISCALL_SIMPLE(SetPedPositionInCar, _ZN4CPed19SetPedPositionInCarEv, void);
    DECL_THISCALL_SIMPLE(RestoreHeadingRate, _ZN4CPed18RestoreHeadingRateEv, void);
    DECL_THISCALL_SIMPLE(SetRadioStation, _ZN4CPed15SetRadioStationEv, void);
    DECL_THISCALL_SIMPLE(PositionAttachedPed, _ZN4CPed19PositionAttachedPedEv, void);
    DECL_THISCALL_SIMPLE(DettachPedFromEntity, _ZN4CPed20DettachPedFromEntityEv, void);
    DECL_THISCALL_SIMPLE(Dress, _ZN4CPed5DressEv, void);
    DECL_THISCALL_SIMPLE(UpdateStatEnteringVehicle, _ZN4CPed25UpdateStatEnteringVehicleEv, void);
    DECL_THISCALL_SIMPLE(GetHoldingTask, _ZN4CPed14GetHoldingTaskEv, CTaskSimpleHoldEntity*);
    DECL_THISCALL_SIMPLE(GetEntityThatThisPedIsHolding, _ZN4CPed29GetEntityThatThisPedIsHoldingEv, CEntity*);
    DECL_THISCALL_SIMPLE(CanThrowEntityThatThisPedIsHolding, _ZN4CPed34CanThrowEntityThatThisPedIsHoldingEv, u8);
    DECL_THISCALL_SIMPLE(GiveWeaponAtStartOfFight, _ZN4CPed24GiveWeaponAtStartOfFightEv, void);
    DECL_THISCALL_SIMPLE(GiveWeaponWhenJoiningGang, _ZN4CPed25GiveWeaponWhenJoiningGangEv, void);
    DECL_THISCALL_SIMPLE(IsPlayingHandSignal, _ZN4CPed19IsPlayingHandSignalEv, u8);
    DECL_THISCALL_SIMPLE(StopPlayingHandSignal, _ZN4CPed21StopPlayingHandSignalEv, void);
    DECL_THISCALL_SIMPLE(GetWalkAnimSpeed, _ZN4CPed16GetWalkAnimSpeedEv, float);
    DECL_THISCALL_SIMPLE(UseFreeAimMagnetize, _ZN4CPed19UseFreeAimMagnetizeEv, bool);
    DECL_THISCALL_SIMPLE(GetPedStateString, _ZN4CPed17GetPedStateStringEv, const char*);
    DECL_THISCALL_SIMPLE(GetPedTalking, _ZN4CPed13GetPedTalkingEv, u8);
    DECL_THISCALL_SIMPLE(EnablePedSpeech, _ZN4CPed15EnablePedSpeechEv, void);
    DECL_THISCALL_SIMPLE(EnablePedSpeechForScriptSpeech, _ZN4CPed30EnablePedSpeechForScriptSpeechEv, void);
    DECL_THISCALL_SIMPLE(CanPedHoldConversation, _ZN4CPed22CanPedHoldConversationEv, u8);
    DECL_THISCALL_SIMPLE(DeadPedMakesTyresBloody, _ZN4CPed23DeadPedMakesTyresBloodyEv, void);

    

    DECL_THISCALL_HEAD(SetCharCreatedBy, _ZN4CPed16SetCharCreatedByEh, void, u8 const createdBy)
    DECL_THISCALL_TAIL(SetCharCreatedBy, createdBy)

    DECL_THISCALL_HEAD(DisablePedSpeech, _ZN4CPed16DisablePedSpeechEs, void, i16 stopCurrentSpeech)
    DECL_THISCALL_TAIL(DisablePedSpeech, stopCurrentSpeech)

    DECL_THISCALL_HEAD(DisablePedSpeechForScriptSpeech, _ZN4CPed31DisablePedSpeechForScriptSpeechEs, void, i16 stopCurrentSpeech)
    DECL_THISCALL_TAIL(DisablePedSpeechForScriptSpeech, stopCurrentSpeech)

    DECL_THISCALL_HEAD(SayScript, _ZN4CPed9SayScriptEihhh, void, i32 audioEvent, u8 overrideSilence, u8 forceAudible, u8 frontEnd)
    DECL_THISCALL_TAIL(SayScript, audioEvent, overrideSilence, forceAudible, frontEnd)

    DECL_THISCALL_HEAD(Say, _ZN4CPed3SayEtjfhhh, i16, u16 audioEvent, u32 delay, float probability, u8 overrideSilence, u8 forceAudible, u8 frontEnd)
    DECL_THISCALL_TAIL(Say, audioEvent, delay, probability, overrideSilence, forceAudible, frontEnd)

    DECL_THISCALL_HEAD(SetPedStats, _ZN4CPed11SetPedStatsE9ePedStats, void, ePedStats pedStats)
    DECL_THISCALL_TAIL(SetPedStats, pedStats)

    DECL_THISCALL_HEAD(WorkOutHeadingForMovingFirstPerson, _ZN4CPed34WorkOutHeadingForMovingFirstPersonEf, float, float heading)
    DECL_THISCALL_TAIL(WorkOutHeadingForMovingFirstPerson, heading)

    DECL_THISCALL_HEAD(OurPedCanSeeThisEntity, _ZN4CPed22OurPedCanSeeThisEntityEP7CEntityb, bool, CEntity* pEntity, bool isSpotted)
    DECL_THISCALL_TAIL(OurPedCanSeeThisEntity, pEntity, isSpotted)

    DECL_THISCALL_HEAD(SortPeds, _ZN4CPed8SortPedsEPPS_ii, void, CPed** ppPeds, i32 start, i32 end)
    DECL_THISCALL_TAIL(SortPeds, ppPeds, start, end)

    DECL_THISCALL_HEAD(GetLocalDirection, _ZN4CPed17GetLocalDirectionERK9CVector2D, i32, CVector2D const& offset)
    DECL_THISCALL_TAIL(GetLocalDirection, offset)

    DECL_THISCALL_HEAD(DoFootLanded, _ZN4CPed12DoFootLandedEbh, void, bool leftFoot, u8 playSound)
    DECL_THISCALL_TAIL(DoFootLanded, leftFoot, playSound)

    DECL_THISCALL_HEAD(SetWeaponLockOnTarget, _ZN4CPed21SetWeaponLockOnTargetEP7CEntity, void, CEntity* pEntity)
    DECL_THISCALL_TAIL(SetWeaponLockOnTarget, pEntity)

    DECL_THISCALL_HEAD(GetHeadAndFootPositions, _ZN4CPed23GetHeadAndFootPositionsER7CVectorS1_b, void, CVector& headPos, CVector& footPos, bool isTransformed)
    DECL_THISCALL_TAIL(GetHeadAndFootPositions, headPos, footPos, isTransformed)

    DECL_THISCALL_HEAD(AddWeaponModel, _ZN4CPed14AddWeaponModelEi, void, i32 modelId)
    DECL_THISCALL_TAIL(AddWeaponModel, modelId)

    DECL_THISCALL_HEAD(RemoveWeaponModel, _ZN4CPed17RemoveWeaponModelEi, void, i32 modelId)
    DECL_THISCALL_TAIL(RemoveWeaponModel, modelId)

    DECL_THISCALL_HEAD(AddGogglesModel, _ZN4CPed15AddGogglesModelEiPb, void, i32 modelId, bool* pGogglesState)
    DECL_THISCALL_TAIL(AddGogglesModel, modelId, pGogglesState)

    DECL_THISCALL_NAMED_HEAD(SetCurrentWeapon1, SetCurrentWeapon, _ZN4CPed16SetCurrentWeaponEi, void, i32 weapon)
    DECL_THISCALL_TAIL(SetCurrentWeapon1, weapon)

    DECL_THISCALL_NAMED_HEAD(SetCurrentWeapon2, SetCurrentWeapon, _ZN4CPed16SetCurrentWeaponE11eWeaponType, void, eWeaponType weapon)
    DECL_THISCALL_TAIL(SetCurrentWeapon2, weapon)

    DECL_THISCALL_HEAD(GiveWeapon, _ZN4CPed10GiveWeaponE11eWeaponTypejb, i32, eWeaponType weaponType, u32 ammo, bool makeCurrent)
    DECL_THISCALL_TAIL(GiveWeapon, weaponType, ammo, makeCurrent)

    DECL_THISCALL_HEAD(GiveDelayedWeapon, _ZN4CPed17GiveDelayedWeaponE11eWeaponTypej, void, eWeaponType weaponType, u32 ammo)
    DECL_THISCALL_TAIL(GiveDelayedWeapon, weaponType, ammo)

    DECL_THISCALL_HEAD(GetWeaponSlot, _ZN4CPed13GetWeaponSlotE11eWeaponType, i32, eWeaponType weaponType)
    DECL_THISCALL_TAIL(GetWeaponSlot, weaponType)

    DECL_THISCALL_HEAD(GrantAmmo, _ZN4CPed9GrantAmmoE11eWeaponTypej, void, eWeaponType weaponType, u32 ammo)
    DECL_THISCALL_TAIL(GrantAmmo, weaponType, ammo)

    DECL_THISCALL_HEAD(SetAmmo, _ZN4CPed7SetAmmoE11eWeaponTypej, void, eWeaponType weaponType, u32 ammo)
    DECL_THISCALL_TAIL(SetAmmo, weaponType, ammo)

    DECL_THISCALL_HEAD(ClearWeapon, _ZN4CPed11ClearWeaponE11eWeaponType, void, eWeaponType weaponType)
    DECL_THISCALL_TAIL(ClearWeapon, weaponType)

    DECL_THISCALL_HEAD(DoWeHaveWeaponAvailable, _ZN4CPed23DoWeHaveWeaponAvailableE11eWeaponType, bool, eWeaponType weaponType)
    DECL_THISCALL_TAIL(DoWeHaveWeaponAvailable, weaponType)

    DECL_THISCALL_HEAD(RemoveWeaponWhenEnteringVehicle, _ZN4CPed31RemoveWeaponWhenEnteringVehicleEi, void, i32 vehicleType)
    DECL_THISCALL_TAIL(RemoveWeaponWhenEnteringVehicle, vehicleType)

    DECL_THISCALL_HEAD(DoGunFlash, _ZN4CPed10DoGunFlashEib, bool, i32 duration, bool leftHand)
    DECL_THISCALL_TAIL(DoGunFlash, duration, leftHand)

    DECL_THISCALL_HEAD(SetGunFlashAlpha, _ZN4CPed16SetGunFlashAlphaEb, void, bool leftHand)
    DECL_THISCALL_TAIL(SetGunFlashAlpha, leftHand)

    DECL_THISCALL_NAMED_HEAD(GetWeaponSkill2, GetWeaponSkill, _ZN4CPed14GetWeaponSkillE11eWeaponType, i8, eWeaponType weaponType)
    DECL_THISCALL_TAIL(GetWeaponSkill2, weaponType)

    DECL_THISCALL_HEAD(SetWeaponSkill, _ZN4CPed14SetWeaponSkillE11eWeaponTypea, void, eWeaponType weaponType, i8 skill)
    DECL_THISCALL_TAIL(SetWeaponSkill, weaponType, skill)

    DECL_THISCALL_HEAD(SetPedState, _ZN4CPed11SetPedStateE9ePedState, void, ePedState const pedState)
    DECL_THISCALL_TAIL(SetPedState, pedState)

    DECL_THISCALL_NAMED_HEAD(SetLook1, SetLook, _ZN4CPed7SetLookEf, void, float target)
    DECL_THISCALL_TAIL(SetLook1, target)

    DECL_THISCALL_NAMED_HEAD(SetLook2, SetLook, _ZN4CPed7SetLookEP7CEntity, void, CEntity* target)
    DECL_THISCALL_TAIL(SetLook2, target)

    DECL_THISCALL_HEAD(SetLookTimer, _ZN4CPed12SetLookTimerEj, void, u32 time)
    DECL_THISCALL_TAIL(SetLookTimer, time)

    DECL_THISCALL_NAMED_HEAD(SetAimFlag1, SetAimFlag, _ZN4CPed10SetAimFlagEf, void, float target)
    DECL_THISCALL_TAIL(SetAimFlag1, target)

    DECL_THISCALL_NAMED_HEAD(SetAimFlag2, SetAimFlag, _ZN4CPed10SetAimFlagEP7CEntity, void, CEntity* target)
    DECL_THISCALL_TAIL(SetAimFlag2, target)

    DECL_THISCALL_NAMED_HEAD(SetLookFlag1, SetLookFlag, _ZN4CPed11SetLookFlagEfbb, void, float target, bool keepTrying, bool ignoreLookTimer)
    DECL_THISCALL_TAIL(SetLookFlag1, target, keepTrying, ignoreLookTimer)

    DECL_THISCALL_NAMED_HEAD(SetLookFlag2, SetLookFlag, _ZN4CPed11SetLookFlagEP7CEntitybb, void, CEntity* target, bool keepTrying, bool ignoreLookTimer)
    DECL_THISCALL_TAIL(SetLookFlag2, target, keepTrying, ignoreLookTimer)

    DECL_THISCALL_HEAD(SetMoveState, _ZN4CPed12SetMoveStateE10eMoveState, void, eMoveState moveState)
    DECL_THISCALL_TAIL(SetMoveState, moveState)

    DECL_THISCALL_HEAD(SetMoveAnimSpeed, _ZN4CPed16SetMoveAnimSpeedEP21CAnimBlendAssociation, void, CAnimBlendAssociation* pAssociation)
    DECL_THISCALL_TAIL(SetMoveAnimSpeed, pAssociation)

    DECL_THISCALL_HEAD(KillPedWithCar, _ZN4CPed14KillPedWithCarEP8CVehiclefb, void, CVehicle* pVehicle, float damageIntensity, bool playDeadAnimation)
    DECL_THISCALL_TAIL(KillPedWithCar, pVehicle, damageIntensity, playDeadAnimation)

    DECL_THISCALL_HEAD(CanSeeEntity, _ZN4CPed12CanSeeEntityEP7CEntityf, bool, CEntity* pEntity, float limitAngle)
    DECL_THISCALL_TAIL(CanSeeEntity, pEntity, limitAngle)

    DECL_THISCALL_HEAD(CreateDeadPedPickupCoors, _ZN4CPed24CreateDeadPedPickupCoorsEPfS0_S0_, void, float* pX, float* pY, float* pZ)
    DECL_THISCALL_TAIL(CreateDeadPedPickupCoors, pX, pY, pZ)

    DECL_THISCALL_HEAD(RemoveBodyPart, _ZN4CPed14RemoveBodyPartEia, void, i32 boneId, i8 direction)
    DECL_THISCALL_TAIL(RemoveBodyPart, boneId, direction)

    DECL_THISCALL_HEAD(SpawnFlyingComponent, _ZN4CPed20SpawnFlyingComponentEia, void, i32 boneId, i8 direction)
    DECL_THISCALL_TAIL(SpawnFlyingComponent, boneId, direction)

    DECL_THISCALL_HEAD(DoesLOSBulletHitPed, _ZN4CPed19DoesLOSBulletHitPedER9CColPoint, u8, CColPoint& colPoint)
    DECL_THISCALL_TAIL(DoesLOSBulletHitPed, colPoint)

    DECL_THISCALL_HEAD(IsPedHeadAbovePos, _ZN4CPed17IsPedHeadAbovePosEf, u8, float height)
    DECL_THISCALL_TAIL(IsPedHeadAbovePos, height)

    DECL_FASTCALL_SIMPLE(RestoreHeadingRateCB, _ZN4CPed20RestoreHeadingRateCBEP21CAnimBlendAssociationPv, void, CAnimBlendAssociation* pAssociation, void* pData);

    DECL_THISCALL_HEAD(MakeTyresMuddySectorList, _ZN4CPed24MakeTyresMuddySectorListER8CPtrList, void, CPtrList& list)
    DECL_THISCALL_TAIL(MakeTyresMuddySectorList, list)

    DECL_THISCALL_HEAD(RemoveWeaponAnims, _ZN4CPed17RemoveWeaponAnimsEif, void, i32 animGroup, float blendDelta)
    DECL_THISCALL_TAIL(RemoveWeaponAnims, animGroup, blendDelta)

    DECL_THISCALL_HEAD(PositionPedOutOfCollision, _ZN4CPed25PositionPedOutOfCollisionEiP8CVehicleb, bool, i32 vehicleDoor, CVehicle* pVehicle, bool findClosestNode)
    DECL_THISCALL_TAIL(PositionPedOutOfCollision, vehicleDoor, pVehicle, findClosestNode)

    DECL_FASTCALL_SIMPLE(FinishJumpCB, _ZN4CPed12FinishJumpCBEP21CAnimBlendAssociationPv, void, CAnimBlendAssociation* pAssociation, void* pData);

    DECL_THISCALL_HEAD(AttachPedToEntity, _ZN4CPed17AttachPedToEntityEP7CEntity7CVectortf11eWeaponType, CEntity*, CEntity* pEntity, CVector offset, u16 position, float angle, eWeaponType weaponType)
    DECL_THISCALL_TAIL(AttachPedToEntity, pEntity, offset, position, angle, weaponType)

    DECL_THISCALL_HEAD(AttachPedToBike, _ZN4CPed15AttachPedToBikeEP7CEntity7CVectortff11eWeaponType, CEntity*, CEntity* pEntity, CVector offset, u16 position, float angle, float verticalLimit, eWeaponType weaponType)
    DECL_THISCALL_TAIL(AttachPedToBike, pEntity, offset, position, angle, verticalLimit, weaponType)

    DECL_THISCALL_HEAD(Undress, _ZN4CPed7UndressEPc, void, char* pModelName)
    DECL_THISCALL_TAIL(Undress, pModelName)

    DECL_THISCALL_HEAD(DropEntityThatThisPedIsHolding, _ZN4CPed30DropEntityThatThisPedIsHoldingEh, void, u8 deleteEntity)
    DECL_THISCALL_TAIL(DropEntityThatThisPedIsHolding, deleteEntity)

    DECL_THISCALL_HEAD(PedIsReadyForConversation, _ZN4CPed25PedIsReadyForConversationEb, bool, bool checkPedState)
    DECL_THISCALL_TAIL(PedIsReadyForConversation, checkPedState)

    DECL_FASTCALL_SIMPLE(ShoulderBoneRotation, _ZN4CPed20ShoulderBoneRotationEP7RpClump, void, RpClump* pClump);

    DECL_THISCALL_HEAD(GetBonePosition, _ZN4CPed15GetBonePositionER5RwV3djb, void, RwV3d& pos, u32 boneId, bool updateSkinBones)
    DECL_THISCALL_TAIL(GetBonePosition, pos, boneId, updateSkinBones)

    DECL_THISCALL_HEAD(GetTransformedBonePosition, _ZN4CPed26GetTransformedBonePositionER5RwV3djb, void, RwV3d& pos, u32 boneId, bool updateSkinBones)
    DECL_THISCALL_TAIL(GetTransformedBonePosition, pos, boneId, updateSkinBones)

    DECL_THISCALL_HEAD(GiveObjectToPedToHold, _ZN4CPed21GiveObjectToPedToHoldEih, CEntity*, i32 modelId, u8 replaceObject)
    DECL_THISCALL_TAIL(GiveObjectToPedToHold, modelId, replaceObject)

    // Helper functions
    inline float GetHealth()
    {
        return m_fHealth;
    }
    inline float GetMaxHealth()
    {
        return m_fMaxHealth;
    }
    inline bool IsMaxHealth()
    {
        return (GetHealth() >= GetMaxHealth());
    }
    inline void SetHealth(float hp)
    {
        m_fHealth = hp;
    }
    inline void AddHealth(float hp)
    {
        SetHealth(GetHealth() + hp);
    }
    inline void SetHealthSafe(float hp)
    {
        if(hp < 0.0f) m_fHealth = 0.0f;
        else if(hp > GetMaxHealth()) m_fHealth = GetMaxHealth();
        else m_fHealth = hp;
    }
    inline void AddHealthSafe(float hp)
    {
        SetHealthSafe(GetHealth() + hp);
    }

    // Member values
    CAEPedAudioEntity           m_pedAudio;
    CAEPedSpeechAudioEntity     m_pedSpeech;
    CAEPedWeaponAudioEntity     m_weaponAudio;
    CPedIntelligence*           m_pIntelligence;
    CPlayerData*                m_pPlayerData;
    unsigned char               m_nCreatedBy; // see ePedCreatedBy
    ePedState                   m_ePedState;
    eMoveState                  m_nMoveState;
    CStoredCollPoly             m_storedCollPoly;
    float                       m_fDistTravelledSinceLastHeightCheck;

    unsigned int bIsStanding : 1; // is ped standing on something
    unsigned int bWasStanding : 1; // was ped standing on something
    unsigned int bIsLooking : 1; // is ped looking at something or in a direction
    unsigned int bIsRestoringLook : 1; // is ped restoring head postion from a look
    unsigned int bIsAimingGun : 1; // is ped aiming gun
    unsigned int bIsRestoringGun : 1; // is ped moving gun back to default posn
    unsigned int bCanPointGunAtTarget : 1; // can ped point gun at target
    unsigned int bIsTalking : 1; // is ped talking(see Chat())

    unsigned int bInVehicle : 1; // is in a vehicle
    unsigned int bIsInTheAir : 1; // is in the air
    unsigned int bIsLanding : 1; // is landing after being in the air
    unsigned int bHitSomethingLastFrame : 1; // has been in a collision last fram
    unsigned int bIsNearCar : 1; // has been in a collision last fram
    unsigned int bRenderPedInCar : 1; // has been in a collision last fram
    unsigned int bUpdateAnimHeading : 1; // update ped heading due to heading change during anim sequence
    unsigned int bRemoveHead : 1; // waiting on AntiSpazTimer to remove head

    unsigned int bFiringWeapon : 1; // is pulling trigger
    unsigned int bHasACamera : 1; // does ped possess a camera to document accidents
    unsigned int bPedIsBleeding : 1; // Ped loses a lot of blood if true
    unsigned int bStopAndShoot : 1; // Ped cannot reach target to attack with fist, need to use gun
    unsigned int bIsPedDieAnimPlaying : 1; // is ped die animation finished so can dead now
    unsigned int bStayInSamePlace : 1; // when set, ped stays put
    unsigned int bKindaStayInSamePlace : 1; // when set, ped doesn't seek out opponent or cover large distances. Will still shuffle and look for cover
    unsigned int bBeingChasedByPolice : 1; // use nodes for routefind

    unsigned int bNotAllowedToDuck : 1; // Is this ped allowed to duck at all?
    unsigned int bCrouchWhenShooting : 1; // duck behind cars etc
    unsigned int bIsDucking : 1; // duck behind cars etc
    unsigned int bGetUpAnimStarted : 1; // don't want to play getup anim if under something
    unsigned int bDoBloodyFootprints : 1; // unsigned int bIsLeader :1;
    unsigned int bDontDragMeOutCar : 1;
    unsigned int bStillOnValidPoly : 1; // set if the polygon the ped is on is still valid for collision
    unsigned int bAllowMedicsToReviveMe : 1;

    unsigned int bResetWalkAnims : 1;
    unsigned int bOnBoat : 1; // flee but only using nodes
    unsigned int bBusJacked : 1; // flee but only using nodes
    unsigned int bFadeOut : 1; // set if you want ped to fade out
    unsigned int bKnockedUpIntoAir : 1; // has ped been knocked up into the air by a car collision
    unsigned int bHitSteepSlope : 1; // has ped collided/is standing on a steep slope (surface type)
    unsigned int bCullExtraFarAway : 1; // special ped only gets culled if it's extra far away (for roadblocks)
    unsigned int bTryingToReachDryLand : 1; // has ped just exited boat and trying to get to dry land

    unsigned int bCollidedWithMyVehicle : 1;
    unsigned int bRichFromMugging : 1; // ped has lots of cash cause they've been mugging people
    unsigned int bChrisCriminal : 1; // Is a criminal as killed during Chris' police mission (should be counted as such)
    unsigned int bShakeFist : 1; // test shake hand at look entity
    unsigned int bNoCriticalHits : 1; // ped cannot be killed by a single bullet
    unsigned int bHasAlreadyBeenRecorded : 1; // Used for replays
    unsigned int bUpdateMatricesRequired : 1; // if PedIK has altered bones so matrices need updated this frame
    unsigned int bFleeWhenStanding : 1; //

    unsigned int bMiamiViceCop : 1;  //
    unsigned int bMoneyHasBeenGivenByScript : 1; //
    unsigned int bHasBeenPhotographed : 1;  //
    unsigned int bIsDrowning : 1;
    unsigned int bDrownsInWater : 1;
    unsigned int bHeadStuckInCollision : 1;
    unsigned int bDeadPedInFrontOfCar : 1;
    unsigned int bStayInCarOnJack : 1;

    unsigned int bDontFight : 1;
    unsigned int bDoomAim : 1;
    unsigned int bCanBeShotInVehicle : 1;
    unsigned int bPushedAlongByCar : 1; // ped is getting pushed along by car collision (so don't take damage from horz velocity)
    unsigned int bNeverEverTargetThisPed : 1;
    unsigned int bThisPedIsATargetPriority : 1;
    unsigned int bCrouchWhenScared : 1;
    unsigned int bKnockedOffBike : 1;

    unsigned int bDonePositionOutOfCollision : 1;
    unsigned int bDontRender : 1;
    unsigned int bHasBeenAddedToPopulation : 1;
    unsigned int bHasJustLeftCar : 1;
    unsigned int bIsInDisguise : 1;
    unsigned int bDoesntListenToPlayerGroupCommands : 1;
    unsigned int bIsBeingArrested : 1;
    unsigned int bHasJustSoughtCover : 1;

    unsigned int bKilledByStealth : 1;
    unsigned int bDoesntDropWeaponsWhenDead : 1;
    unsigned int bCalledPreRender : 1;
    unsigned int bBloodPuddleCreated : 1; // Has a static puddle of blood been created yet
    unsigned int bPartOfAttackWave : 1;
    unsigned int bClearRadarBlipOnDeath : 1;
    unsigned int bNeverLeavesGroup : 1; // flag that we want to test 3 extra spheres on col model
    unsigned int bTestForBlockedPositions : 1; // this sets these indicator flags for various posisions on the front of the ped

    unsigned int bRightArmBlocked : 1;
    unsigned int bLeftArmBlocked : 1;
    unsigned int bDuckRightArmBlocked : 1;
    unsigned int bMidriffBlockedForJump : 1;
    unsigned int bFallenDown : 1;
    unsigned int bUseAttractorInstantly : 1;
    unsigned int bDontAcceptIKLookAts : 1;
    unsigned int bHasAScriptBrain : 1;

    unsigned int bWaitingForScriptBrainToLoad : 1;
    unsigned int bHasGroupDriveTask : 1;
    unsigned int bCanExitCar : 1;
    unsigned int CantBeKnockedOffBike : 2; // 0=Default(harder for mission peds) 1=Never 2=Always normal(also for mission peds)
    unsigned int bHasBeenRendered : 1;
    unsigned int bIsCached : 1;
    unsigned int bPushOtherPeds : 1; // GETS RESET EVERY FRAME - SET IN TASK: want to push other peds around (eg. leader of a group or ped trying to get in a car)

    unsigned int bHasBulletProofVest : 1;
    unsigned int bUsingMobilePhone : 1;
    unsigned int bUpperBodyDamageAnimsOnly : 1;
    unsigned int bStuckUnderCar : 1;
    unsigned int bKeepTasksAfterCleanUp : 1; // If true ped will carry on with task even after cleanup
    unsigned int bIsDyingStuck : 1;
    unsigned int bIgnoreHeightCheckOnGotoPointTask : 1; // set when walking round buildings, reset when task quits
    unsigned int bForceDieInCar : 1;

    unsigned int bCheckColAboveHead : 1;
    unsigned int bIgnoreWeaponRange : 1;
    unsigned int bDruggedUp : 1;
    unsigned int bWantedByPolice : 1; // if this is set, the cops will always go after this ped when they are doing a KillCriminal task
    unsigned int bSignalAfterKill : 1;
    unsigned int bCanClimbOntoBoat : 1;
    unsigned int bPedHitWallLastFrame : 1; // useful to store this so that AI knows (normal will still be available)
    unsigned int bIgnoreHeightDifferenceFollowingNodes : 1;

    unsigned int bMoveAnimSpeedHasBeenSetByTask : 1;
    unsigned int bGetOutUpsideDownCar : 1;
    unsigned int bJustGotOffTrain : 1;
    unsigned int bDeathPickupsPersist : 1;
    unsigned int bTestForShotInVehicle : 1;

    AnimBlendFrameData *m_apBones[19];
    unsigned int        m_nAnimGroup;
    CVector2D           m_vecAnimMovingShiftLocal;
    CPedAcquaintance    m_acquaintance;
    RpClump            *m_pWeaponObject;
    RwFrame            *m_pGunflashObject;
    RpClump            *m_pGogglesObject;
    bool               *m_pGogglesState;
    short               m_nWeaponGunflashAlphaMP1;
    short               m_nGunFlashBlendOutRate;
    short               m_nWeaponGunflashAlphaMP2;
    short               m_nGunFlashBlendOutRate2;
    CPedIK              m_pedIK;
    unsigned int        m_nAntiSpazTimer;
    eMoveState          m_eMoveStateAnim;
    eMoveState          m_eStoredMoveState;
    float               m_fHealth;
    float               m_fMaxHealth;
    float               m_fArmour;
    unsigned int        m_nTimeTillWeNeedThisPed;
    CVector2D           m_vecAnimMovingShift;
    float               m_fCurrentRotation;
    float               m_fAimingRotation;
    float               m_fHeadingChangeRate;
    float               m_fHeadingChangeRateAccel;
    CPhysical          *m_pGroundPhysical;
    CVector             m_vecGroundOffset;
    CVector             m_vecGroundNormal;
    CEntity            *m_pContactEntity;
    float               m_fHitHeadHeight;
    CVehicle           *m_pVehicle;
    CVehicle           *m_pAccidentVehicle;
    CAccident          *m_pAccident;
    int                 m_nPedType;
    CPedStat           *m_pStats;
    CWeapon             m_aWeapons[13];
    eWeaponType         m_nSavedWeapon;
    eWeaponType         m_nDelayedWeapon;
    unsigned int        m_nDelayedWeaponAmmo;
    signed char         m_nSelectedWepSlot;
    unsigned char       m_nWeaponShootingRate;
    unsigned char       m_nWeaponAccuracy;
    CEntity            *m_pTargetedObject;
    CEntity            *m_pEntMagnetizeTarget;
    CVector             m_vecWeaponPrevPos;
    unsigned char       m_nWeaponSkill;
    unsigned char       m_nFightingStyle; // see eFightingStyle
    unsigned char       m_nAllowedAttackMoves;
    unsigned char       m_nBleedingFrames;
    CFire              *m_pFire;
    float               m_fFireDamageMultiplier;
    CEntity            *m_pLookingAtEntity;
    float               m_fLookingDirection;
    int                 m_nWeaponModelId;
    uint32_t            m_nUnconsciousTimer;
    unsigned int        m_nLookingTime;
    uint32_t            m_nAttackTimer;
    unsigned int        m_nDeathTime;
    signed char         m_nBodypartToRemove;
    unsigned short      m_nMoneyCount;
    float               m_wobble;
    float               m_wobbleSpeed;
    signed char         m_nLastWeaponDamage;
    CEntity            *m_pLastEntityDamage;
    uint32_t            m_nLastDamagedTime;
    CVector             m_vecTurretOffset;
    unsigned short      m_nTurretPosnMode;
    float               m_fTurretAngleA;
    float               m_fTurretAngleB;
    int                 m_nTurretAmmo;
    CCoverPoint        *m_pCoverPoint;
    CEntryExit         *m_pEnex;
    float               m_fRemovalDistMultiplier;
    short               m_nSpecialModelIndex;
    uint32_t            m_nLastTalkSfx;
DECL_CLASS_END()
CHECKSIZE(CPed, 0x7A4, 0x988);



DECL_CLASS_BASED(CCopPed, CPed)
    // Construct/Deconstruct functions
    DECL_CTORCALL_ARG_HEAD(CCopPed, _ZN7CCopPedC2E8eCopType, eCopType CopType)
    DECL_CTORCALL_ARG_TAIL(CopType)
    DECL_DTORCALL_VIRTUAL(CCopPed, _ZN7CCopPedD2Ev, _ZN7CCopPed, _ZTV7CCopPed);

    // Member functions
    DECL_THISCALL_SIMPLE(ClearCriminalsToKill, _ZN7CCopPed20ClearCriminalsToKillEv, void);

    DECL_THISCALL_HEAD(SetPartner, _ZN7CCopPed10SetPartnerEPS_, void, CCopPed *pPed)
    DECL_THISCALL_TAIL(SetPartner, pPed)

    DECL_THISCALL_HEAD(AddCriminalToKill, _ZN7CCopPed17AddCriminalToKillEP4CPed, i32, CPed *pCriminal)
    DECL_THISCALL_TAIL(AddCriminalToKill, pCriminal)

    DECL_THISCALL_HEAD(RemoveCriminalToKill, _ZN7CCopPed20RemoveCriminalToKillEP4CPedi, void, CPed *pCriminal, i32 i)
    DECL_THISCALL_TAIL(RemoveCriminalToKill, pCriminal, i)

    // Member values
    bool           m_bRoadBlockCop;
    bool           m_bRemoveIfNonVisible;
    eCopType       m_copType;
    int            m_nStuckCounter;
    CCopPed       *m_pCopPartner;
    CPed          *m_apCriminalsToKill[5];
    bool           m_bIAmDriver;
DECL_CLASS_END()



DECL_CLASS_BASED(CCivilianPed, CPed)
    DECL_CTORCALL_ARG_HEAD(CCivilianPed, _ZN12CCivilianPedC2E8ePedTypej, ePedType pedType, u32 modelIndex)
    DECL_CTORCALL_ARG_TAIL(pedType, modelIndex)
    DECL_DTORCALL_VIRTUAL(CCivilianPed, _ZN12CCivilianPedD2Ev, _ZN12CCivilianPed, _ZTV12CCivilianPed);
    DECL_NEWCALL(CCivilianPed, BYBIT(_ZN4CPednwEj, _ZN4CPednwEm));
    DECL_DLCALL(CCivilianPed, _ZN4CPeddlEPv);

    DECL_VIRTUALCALL_HEAD(CCivilianPed, ProcessControl, _ZTV12CCivilianPed, 11, void)
    DECL_VIRTUALCALL_TAIL()
DECL_CLASS_END()
CHECKSIZE(CCivilianPed, 0x7A4, 0x988);

DECL_CLASS_BASED(CEmergencyPed, CPed)
    DECL_CTORCALL_ARG_HEAD(CEmergencyPed, _ZN13CEmergencyPedC2Ejj, u32 pedType, u32 modelIndex)
    DECL_CTORCALL_ARG_TAIL(pedType, modelIndex)
    DECL_DTORCALL_VIRTUAL(CEmergencyPed, _ZN4CPedD2Ev, _ZN13CEmergencyPed, _ZTV13CEmergencyPed);
    DECL_NEWCALL(CEmergencyPed, BYBIT(_ZN4CPednwEj, _ZN4CPednwEm));
    DECL_DLCALL(CEmergencyPed, _ZN4CPeddlEPv);

    DECL_VIRTUALCALL_HEAD(CEmergencyPed, ProcessControl, _ZTV13CEmergencyPed, 11, void)
    DECL_VIRTUALCALL_TAIL()

    DECL_THISCALL_HEAD(InRange, _ZN13CEmergencyPed7InRangeEP4CPed, bool, CPed* ped)
    DECL_THISCALL_TAIL(InRange, ped)
DECL_CLASS_END()
CHECKSIZE(CEmergencyPed, 0x7A4, 0x988);

DECL_FASTCALL_SIMPLE_GLO(IsPedPointerValid, _Z17IsPedPointerValidP4CPed, bool, CPed* pPed);
DECL_FASTCALL_SIMPLE_GLO(IsPedPointerValid_NotInWorld, _Z28IsPedPointerValid_NotInWorldP4CPed, bool, CPed* pPed);
DECL_FASTCALL_SIMPLE_GLO(LOSBlockedBetweenPeds, _Z21LOSBlockedBetweenPedsP7CEntityS0_, bool, CEntity* pPed1, CEntity* pPed2);
DECL_FASTCALL_SIMPLE_GLO(SetPedAtomicVisibilityCB, _Z24SetPedAtomicVisibilityCBP8RwObjectPv, RwObject*, RwObject* pObject, void* pData);
DECL_FASTCALL_SIMPLE_GLO(RecurseFrameChildrenVisibilityCB, _Z32RecurseFrameChildrenVisibilityCBP7RwFramePv, RwFrame*, RwFrame* pFrame, void* pData);

#define m_sGunFlashBlendStart m_sGunFlashBlendStart()

#endif // __AML_PSDK_SAPED_H
