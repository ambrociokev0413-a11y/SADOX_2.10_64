#ifndef __AML_PSDK_BASE_H
#define __AML_PSDK_BASE_H

#ifndef BASE_GAME_LIBRARY
    #error Please include <aml-psdk/game_*/plugin.h>!
    #define BASE_GAME_LIBRARY "" // Suppress an error
#endif

#include <mod/amlmod.h>
#include <stdint.h>
#include <math.h>
#include <type_traits>
#include <utility>
#include <new>

#include "sdk_basetypes.h"

inline void* g_hMainGameLibrary = NULL;
inline uptr g_pMainGameAddress = 0;

inline void* GetMainLibrary()
{
    if(!g_hMainGameLibrary)
    {
        g_hMainGameLibrary = aml->GetLibHandle( BASE_GAME_LIBRARY );
    }
    return g_hMainGameLibrary;
}

inline uptr GetMainLibraryAddress()
{
    if(!g_pMainGameAddress)
    {
        g_pMainGameAddress = aml->GetLib( BASE_GAME_LIBRARY );
    }
    return g_pMainGameAddress;
}

template<typename Type = void*>
inline Type GetMainLibrarySymbol(const char* sym)
{
    return (Type)aml->GetSym(GetMainLibrary(), sym);
}

template<class Owner>
inline uptr* GetNativeVtable(const char* symbol)
{
    static uptr* vtable = GetMainLibrarySymbol<uptr*>(symbol);
    return vtable + 2;
}

template<class Owner, class Fn>
inline Fn GetNativeVirtual(const void* self, size_t slot, Fn wrapper, const char* symbol)
{
    Fn func = (Fn)(*(const uptr* const*)self)[slot];
    return func == wrapper ? (Fn)GetNativeVtable<Owner>(symbol)[slot] : func;
}

template<typename Ret = void, typename... Args>
inline Ret CallFnVariadic(uintptr_t address, Args... args)
{
    using FuncPtr = Ret(*)(Args...);
    FuncPtr func = (FuncPtr)(address);
    return func(std::forward<Args>(args)...);
}

#define DECL_VALUE_HEAD(_type, _name) \
    struct ValueProxy_##_name { \
        static inline _type* m_Pointer = NULL;

#define DECL_VALUE_SYM_BASE(_type, _name, _sym) \
        _type& operator()() { return Get(); } \
        static inline _type& Get() { \
            if(!m_Pointer) m_Pointer = GetMainLibrarySymbol<_type*>(_sym); \
            return *m_Pointer; \
        }

#define DECL_VALUE_PLT_BASE(_type, _name, _addr) \
        _type& operator()() { return Get(); } \
        static inline _type& Get() { \
            return **(_type**)(GetMainLibraryAddress() + _addr); \
        }

#define DECL_VALUE_ADDR_BASE(_type, _name, _addr) \
        _type& operator()() { return Get(); } \
        static inline _type& Get() { \
            if(!m_Pointer) m_Pointer = (_type*)(GetMainLibraryAddress() + _addr); \
            return *m_Pointer; \
        }

#define DECL_VALUE_PLTPTR_BASE(_type, _name, _addr) \
        _type& operator()() { return Get(); } \
        static inline _type& Get() { \
            if(!m_Pointer) m_Pointer = (_type*)(GetMainLibraryAddress() + _addr); \
            return *m_Pointer; \
        }

#define DECL_VALUE_NUMBER_BASE(_type) \
        DECL_VALUE_SETTER_BASE(_type) \
        template<class C> \
        const _type& operator=(const C& v) { return Set( (const _type)v ); } \
        template<class C> \
        const _type& operator+=(const C& v) { return Set( Get() + (const _type)v ); } \
        template<class C> \
        const _type& operator-=(const C& v) { return Set( Get() - (const _type)v ); } \
        template<class C> \
        const _type& operator/=(const C& v) { return Set( Get() / (const _type)v ); } \
        template<class C> \
        const _type& operator*=(const C& v) { return Set( Get() * (const _type)v ); } \
        const _type& operator++() { return Set( Get() + (const _type)1 ); } \
        const _type& operator--() { return Set( Get() - (const _type)1 ); } \
        const bool operator!() { return (Get() == (const _type)0); } \
        _type operator++(int unusedVar) { \
            _type tVal = Get(); \
            Set( Get() + (const _type)1 ); \
            return tVal; \
        } \
        _type operator--(int unusedVar) { \
            _type tVal = Get(); \
            Set( Get() - (const _type)1 ); \
            return tVal; \
        }

#define DECL_VALUE_SETTER_BASE(_type) \
        static inline _type& Set(const _type& v) { Get() = v; return Get(); } \

#define DECL_VALUE_GETTER_BASE(_type) \
        static inline _type* Ptr() { return &Get(); } \

#define DECL_VALUE_BITOPS_BASE(_type) \
        template<class C> \
        const _type& operator^=(const C& v) { return Set( Get() ^ (const _type)v ); } \
        template<class C> \
        const _type& operator|=(const C& v) { return Set( Get() | (const _type)v ); } \
        template<class C> \
        const _type& operator&=(const C& v) { return Set( Get() & (const _type)v ); }

#define DECL_VALUE_RETURN_BASE(_type) \
        operator _type() { return (_type)Get(); }

#define DECL_VALUE_RETURN_BASE_REF(_type) \
        operator _type&() { return (_type&)Get(); } \
        operator _type() { return (_type)Get(); }

#define DECL_VALUE_TAIL(_type, _name) \
        DECL_VALUE_GETTER_BASE(_type) \
    }; static inline ValueProxy_##_name _name

#define DECL_VALUE_TAIL_GLOBAL(_type, _name) \
        DECL_VALUE_GETTER_BASE(_type) \
    }; inline ValueProxy_##_name _name

#define DECL_VALUE_OBJECT_BASE(_type) \
        _type* operator->() { return &Get(); }

#define DECL_VALUE_OBJECT_ARRAY_BASE(_type) \
        _type* operator->() { return Get(); } \
        _type& operator[](int i) { return Get()[i]; }

// Values

#define DECL_VALUE_PLT_I32(_name, _addr) \
    DECL_VALUE_HEAD(i32, _name) \
        DECL_VALUE_PLT_BASE(i32, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(i32) \
        DECL_VALUE_BITOPS_BASE(i32) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(i32, _name)

#define DECL_VALUE_PLT_I32_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(i32, _name) \
        DECL_VALUE_PLT_BASE(i32, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(i32) \
        DECL_VALUE_BITOPS_BASE(i32) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL_GLOBAL(i32, _name)

#define DECL_VALUE_ADDR_I32_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(i32, _name) \
        DECL_VALUE_ADDR_BASE(i32, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(i32) \
        DECL_VALUE_BITOPS_BASE(i32) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL_GLOBAL(i32, _name)

#define DECL_VALUE_PLT_BOOL(_name, _addr) \
    DECL_VALUE_HEAD(bool, _name) \
        DECL_VALUE_PLT_BASE(bool, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(bool) \
        DECL_VALUE_BITOPS_BASE(bool) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(bool, _name)

#define DECL_VALUE_PLT_BOOL_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(bool, _name) \
        DECL_VALUE_PLT_BASE(bool, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(bool) \
        DECL_VALUE_BITOPS_BASE(bool) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL_GLOBAL(bool, _name)

#define DECL_VALUE_PLT_U32(_name, _addr) \
    DECL_VALUE_HEAD(u32, _name) \
        DECL_VALUE_PLT_BASE(u32, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(u32) \
        DECL_VALUE_BITOPS_BASE(u32) \
        DECL_VALUE_RETURN_BASE(unsigned int) \
    DECL_VALUE_TAIL(u32, _name)

#define DECL_VALUE_PLT_U32_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(u32, _name) \
        DECL_VALUE_PLT_BASE(u32, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(u32) \
        DECL_VALUE_BITOPS_BASE(u32) \
        DECL_VALUE_RETURN_BASE(unsigned int) \
    DECL_VALUE_TAIL_GLOBAL(u32, _name)

#define DECL_VALUE_PLT_I8(_name, _addr) \
    DECL_VALUE_HEAD(i8, _name) \
        DECL_VALUE_PLT_BASE(i8, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(i8) \
        DECL_VALUE_BITOPS_BASE(i8) \
        DECL_VALUE_RETURN_BASE(char) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(i8, _name)

#define DECL_VALUE_PLT_I16(_name, _addr) \
    DECL_VALUE_HEAD(i16, _name) \
        DECL_VALUE_PLT_BASE(i16, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(i16) \
        DECL_VALUE_BITOPS_BASE(i16) \
        DECL_VALUE_RETURN_BASE(short) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(i16, _name)

#define DECL_VALUE_PLT_U16(_name, _addr) \
    DECL_VALUE_HEAD(u16, _name) \
        DECL_VALUE_PLT_BASE(u16, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(u16) \
        DECL_VALUE_BITOPS_BASE(u16) \
        DECL_VALUE_RETURN_BASE(unsigned short) \
        DECL_VALUE_RETURN_BASE(unsigned int) \
    DECL_VALUE_TAIL(u16, _name)

#define DECL_VALUE_PLT_I8_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(i8, _name) \
        DECL_VALUE_PLT_BASE(i8, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(i8) \
        DECL_VALUE_BITOPS_BASE(i8) \
        DECL_VALUE_RETURN_BASE(char) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL_GLOBAL(i8, _name)

#define DECL_VALUE_PLT_U8(_name, _addr) \
    DECL_VALUE_HEAD(u8, _name) \
        DECL_VALUE_PLT_BASE(u8, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(u8) \
        DECL_VALUE_BITOPS_BASE(u8) \
        DECL_VALUE_RETURN_BASE(unsigned char) \
        DECL_VALUE_RETURN_BASE(unsigned int) \
    DECL_VALUE_TAIL(u8, _name)

#define DECL_VALUE_PLT_U8_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(u8, _name) \
        DECL_VALUE_PLT_BASE(u8, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(u8) \
        DECL_VALUE_BITOPS_BASE(u8) \
        DECL_VALUE_RETURN_BASE(unsigned char) \
        DECL_VALUE_RETURN_BASE(unsigned int) \
    DECL_VALUE_TAIL_GLOBAL(u8, _name)

#define DECL_VALUE_PLT_FLT(_name, _addr) \
    DECL_VALUE_HEAD(float, _name) \
        DECL_VALUE_PLT_BASE(float, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(float) \
        DECL_VALUE_RETURN_BASE(float) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(float, _name)

#define DECL_VALUE_PLT_FLT_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(float, _name) \
        DECL_VALUE_PLT_BASE(float, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(float) \
        DECL_VALUE_RETURN_BASE(float) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL_GLOBAL(float, _name)

#define DECL_VALUE_PLT_CHAR(_name, _addr) \
    DECL_VALUE_HEAD(char*, _name) \
        DECL_VALUE_PLTPTR_BASE(char*, _name, _addr) \
        DECL_VALUE_RETURN_BASE(char*) \
        DECL_VALUE_RETURN_BASE(const char*) \
        DECL_VALUE_RETURN_BASE(uintptr_t) \
    DECL_VALUE_TAIL(char*, _name)

#define DECL_VALUE_PLT_CHAR_GLOBAL(_name, _addr) \
    DECL_VALUE_HEAD(char*, _name) \
        DECL_VALUE_PLTPTR_BASE(char*, _name, _addr) \
        DECL_VALUE_RETURN_BASE(char*) \
        DECL_VALUE_RETURN_BASE(const char*) \
        DECL_VALUE_RETURN_BASE(uintptr_t) \
    DECL_VALUE_TAIL_GLOBAL(char*, _name)

#define DECL_OBJECT_PLT(_type, _name, _addr) \
    DECL_VALUE_HEAD(_type, _name) \
        DECL_VALUE_PLT_BASE(_type, _name, _addr) \
        DECL_VALUE_OBJECT_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type&) \
    DECL_VALUE_TAIL(_type, _name)

#define DECL_OBJECT_ARRAY_PLT(_type, _name, _addr) \
    DECL_VALUE_HEAD(_type*, _name) \
        DECL_VALUE_PLTPTR_BASE(_type*, _name, _addr) \
        DECL_VALUE_OBJECT_ARRAY_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type*&) \
    DECL_VALUE_TAIL(_type*, _name)

#define DECL_OBJECT_ARRAY_PLT_GLOBAL(_type, _name, _addr) \
    DECL_VALUE_HEAD(_type*, _name) \
        DECL_VALUE_PLTPTR_BASE(_type*, _name, _addr) \
        DECL_VALUE_OBJECT_ARRAY_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type*&) \
    DECL_VALUE_TAIL_GLOBAL(_type*, _name)

#define DECL_OBJECT_PLT_GLOBAL(_type, _name, _addr) \
    DECL_VALUE_HEAD(_type, _name) \
        DECL_VALUE_PLT_BASE(_type, _name, _addr) \
        DECL_VALUE_OBJECT_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type&) \
    DECL_VALUE_TAIL_GLOBAL(_type, _name)

#define DECL_VALUE_ADDR_I32(_name, _addr) \
    DECL_VALUE_HEAD(i32, _name) \
        DECL_VALUE_ADDR_BASE(i32, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(i32) \
        DECL_VALUE_BITOPS_BASE(i32) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(i32, _name)

#define DECL_VALUE_ADDR_U32(_name, _addr) \
    DECL_VALUE_HEAD(u32, _name) \
        DECL_VALUE_ADDR_BASE(u32, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(u32) \
        DECL_VALUE_BITOPS_BASE(u32) \
        DECL_VALUE_RETURN_BASE(unsigned int) \
    DECL_VALUE_TAIL(u32, _name)

#define DECL_VALUE_ADDR_U8(_name, _addr) \
    DECL_VALUE_HEAD(u8, _name) \
        DECL_VALUE_ADDR_BASE(u8, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(u8) \
        DECL_VALUE_BITOPS_BASE(u8) \
        DECL_VALUE_RETURN_BASE(unsigned char) \
        DECL_VALUE_RETURN_BASE(unsigned int) \
    DECL_VALUE_TAIL(u8, _name)

#define DECL_VALUE_ADDR_FLT(_name, _addr) \
    DECL_VALUE_HEAD(float, _name) \
        DECL_VALUE_ADDR_BASE(float, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(float) \
        DECL_VALUE_RETURN_BASE(float) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(float, _name)

#define DECL_VALUE_ADDR_BOOL(_name, _addr) \
    DECL_VALUE_HEAD(bool, _name) \
        DECL_VALUE_ADDR_BASE(bool, _name, _addr) \
        DECL_VALUE_NUMBER_BASE(bool) \
        DECL_VALUE_BITOPS_BASE(bool) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(bool, _name)

#define DECL_OBJECT_ADDR(_type, _name, _addr) \
    DECL_VALUE_HEAD(_type, _name) \
        DECL_VALUE_ADDR_BASE(_type, _name, _addr) \
        DECL_VALUE_OBJECT_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type&) \
    DECL_VALUE_TAIL(_type, _name)


#define PSDK_STRINGIFY_(_x) #_x
#define PSDK_SYMBOL_CHECK_N(_first, _second, ...) _second
#define PSDK_SYMBOL_CHECK(...) PSDK_SYMBOL_CHECK_N(__VA_ARGS__, 0)
#define PSDK_SYMBOL_PROBE(...) ~, 1
#define PSDK_SYMBOL_IS_PAREN(_x) PSDK_SYMBOL_CHECK(PSDK_SYMBOL_PROBE _x)
#define PSDK_SYMBOL_REMOVE_PARENS(...) __VA_ARGS__
#define PSDK_SYMBOL_UNWRAP_0(_x) _x
#define PSDK_SYMBOL_UNWRAP_1(_x) PSDK_SYMBOL_REMOVE_PARENS _x
#define PSDK_SYMBOL_UNWRAP_PICK_(_n, _x) PSDK_SYMBOL_UNWRAP_##_n(_x)
#define PSDK_SYMBOL_UNWRAP_PICK(_n, _x) PSDK_SYMBOL_UNWRAP_PICK_(_n, _x)
#define PSDK_STRINGIFY_NORMALIZED(_x) PSDK_STRINGIFY_(_x)
#define PSDK_STRINGIFY(_x) PSDK_STRINGIFY_NORMALIZED(PSDK_SYMBOL_UNWRAP_PICK(PSDK_SYMBOL_IS_PAREN(_x), _x))

#define DECL_VALUE_SYM_I32(_name, _sym) \
    DECL_VALUE_HEAD(i32, _name) \
        DECL_VALUE_SYM_BASE(i32, _name, PSDK_STRINGIFY(_sym)) \
        DECL_VALUE_NUMBER_BASE(i32) \
        DECL_VALUE_BITOPS_BASE(i32) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(i32, _name)

#define DECL_VALUE_SYM_BOOL(_name, _sym) \
    DECL_VALUE_HEAD(bool, _name) \
        DECL_VALUE_SYM_BASE(bool, _name, PSDK_STRINGIFY(_sym)) \
        DECL_VALUE_NUMBER_BASE(bool) \
        DECL_VALUE_BITOPS_BASE(bool) \
        DECL_VALUE_RETURN_BASE(int) \
    DECL_VALUE_TAIL(bool, _name)

#define DECL_OBJECT_SYM(_type, _name, _sym) \
    DECL_VALUE_HEAD(_type, _name) \
        DECL_VALUE_SYM_BASE(_type, _name, PSDK_STRINGIFY(_sym)) \
        DECL_VALUE_OBJECT_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type&) \
    DECL_VALUE_TAIL(_type, _name)

#define DECL_VALUE_ARRAY_SYM_BASE(_type, _name, _sym) \
        _type*& operator()() { return Get(); } \
        static inline _type*& Get() { \
            if(!m_Pointer) m_Pointer = GetMainLibrarySymbol<_type*>(PSDK_STRINGIFY(_sym)); \
            return m_Pointer; \
        }

#define DECL_OBJECT_ARRAY_SYM(_type, _name, _sym) \
    DECL_VALUE_HEAD(_type, _name) \
        DECL_VALUE_ARRAY_SYM_BASE(_type, _name, _sym) \
        DECL_VALUE_OBJECT_ARRAY_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type*&) \
    DECL_VALUE_TAIL(_type*, _name)

#define DECL_OBJECT_ARRAY_SYM_GLOBAL(_type, _name, _sym) \
    DECL_VALUE_HEAD(_type, _name) \
        DECL_VALUE_ARRAY_SYM_BASE(_type, _name, _sym) \
        DECL_VALUE_OBJECT_ARRAY_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type*&) \
    DECL_VALUE_TAIL_GLOBAL(_type*, _name)

#define DECL_OBJECT_ARRAY_ADDR_GLOBAL(_type, _name, _addr) \
    DECL_VALUE_HEAD(_type, _name) \
        _type*& operator()() { return Get(); } \
        static inline _type*& Get() { \
            if(!m_Pointer) m_Pointer = (_type*)(GetMainLibraryAddress() + _addr); \
            return m_Pointer; \
        } \
        DECL_VALUE_OBJECT_ARRAY_BASE(_type) \
        DECL_VALUE_RETURN_BASE(_type*&) \
    DECL_VALUE_TAIL_GLOBAL(_type*, _name)

// Class functions

#define DECL_CTORCALL_PROXY(_clsName, _sym, ...) \
    static inline auto FuncProxy_ctor##_clsName = GetMainLibrarySymbol<void(*)(ThisClass* VA_ARGS(__VA_ARGS__))>(PSDK_STRINGIFY(_sym))

#define DECL_DTORCALL_PROXY(_clsName, _sym) \
    static inline auto FuncProxy_dtor##_clsName = GetMainLibrarySymbol<void(*)(ThisClass*)>(PSDK_STRINGIFY(_sym))

#define DECL_CTORCALL_ARG_HEAD(_clsName, _sym, ...) \
    DECL_CTORCALL_NAMED_ARG_HEAD(_clsName, _clsName, _sym, __VA_ARGS__)

#define DECL_CTORCALL_NAMED_ARG_HEAD(_proxyName, _clsName, _sym, ...) \
    DECL_CTORCALL_PROXY(_proxyName, _sym, __VA_ARGS__); \
    _clsName(__VA_ARGS__) asm("psdk_ctor_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_proxyName) "_" PSDK_STRINGIFY(_sym)); \
    static inline __attribute__((used, visibility("hidden"))) PSDK_LIFETIME_RET(ThisClass) NativeCtor_##_proxyName(ThisClass* _psdkSelf VA_ARGS(__VA_ARGS__)) \
        asm("psdk_ctor_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_proxyName) "_" PSDK_STRINGIFY(_sym)) \
    { FuncProxy_ctor##_proxyName(

#define DECL_CTORCALL_ARG_TAIL(...) \
    _psdkSelf VA_ARGS(__VA_ARGS__)); PSDK_LIFETIME_RETURN(_psdkSelf); }

#define DECL_CTORCALL(_clsName, _sym) \
    DECL_CTORCALL_ARG_HEAD(_clsName, _sym) \
    DECL_CTORCALL_ARG_TAIL()

#define DECL_DTORCALL(_clsName, _sym) \
    DECL_DTORCALL_PROXY(_clsName, _sym); \
    ~_clsName() asm("psdk_dtor_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_sym)); \
    static inline __attribute__((used, visibility("hidden"))) PSDK_LIFETIME_RET(ThisClass) NativeDtor_##_clsName(ThisClass* _psdkSelf) \
        asm("psdk_dtor_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_sym)) \
    { FuncProxy_dtor##_clsName(_psdkSelf); PSDK_LIFETIME_RETURN(_psdkSelf); }

#define DECL_DTORCALL_VIRTUAL(_clsName, _sym, _cppPrefix, _vtblSym) \
    DECL_DTORCALL_VIRTUAL_SLOT(_clsName, _sym, _cppPrefix, _vtblSym, 0)

#define DECL_DTORCALL_VIRTUAL_SLOT(_clsName, _sym, _cppPrefix, _vtblSym, _slot) \
    DECL_DTORCALL_PROXY(_clsName, _sym); \
    DECL_DTORCALL_VIRTUAL_SHIMS(_clsName, _cppPrefix, _vtblSym, _slot)

#define DECL_DTORCALL_VIRTUAL_VTABLE(_clsName, _cppPrefix, _vtblSym) \
    DECL_DTORCALL_VIRTUAL_VTABLE_SLOT(_clsName, _cppPrefix, _vtblSym, 0)

#define DECL_DTORCALL_VIRTUAL_VTABLE_SLOT(_clsName, _cppPrefix, _vtblSym, _slot) \
    static inline void NativeDtorFallback_##_clsName(ThisClass* _psdkSelf) \
    { \
        ((void(*)(ThisClass*))GetNativeVtable<ThisClass>(PSDK_STRINGIFY(_vtblSym))[_slot])(_psdkSelf); \
    } \
    static inline auto FuncProxy_dtor##_clsName = &NativeDtorFallback_##_clsName; \
    DECL_DTORCALL_VIRTUAL_SHIMS(_clsName, _cppPrefix, _vtblSym, _slot)

#define DECL_DTORCALL_VIRTUAL_SHIMS(_clsName, _cppPrefix, _vtblSym, _slot) \
    _Pragma("clang diagnostic push") _Pragma("clang diagnostic ignored \"-Wundefined-inline\"") \
    virtual inline ~_clsName(); \
    _Pragma("clang diagnostic pop") \
    static inline __attribute__((used, visibility("hidden"))) PSDK_LIFETIME_RET(ThisClass) NativeDtor_##_clsName(ThisClass* _psdkSelf) \
        asm(PSDK_STRINGIFY(_cppPrefix) "D2Ev") \
    { FuncProxy_dtor##_clsName(_psdkSelf); PSDK_LIFETIME_RETURN(_psdkSelf); } \
    static inline __attribute__((used, visibility("hidden"))) PSDK_LIFETIME_RET(ThisClass) NativeCompleteDtor_##_clsName(ThisClass* _psdkSelf) \
        asm(PSDK_STRINGIFY(_cppPrefix) "D1Ev") \
    { FuncProxy_dtor##_clsName(_psdkSelf); PSDK_LIFETIME_RETURN(_psdkSelf); } \
    static inline __attribute__((used, noinline, visibility("hidden"))) void NativeDeletingDtor_##_clsName(ThisClass* _psdkSelf) \
        asm(PSDK_STRINGIFY(_cppPrefix) "D0Ev") \
    { \
        auto func = GetNativeVirtual<ThisClass>(_psdkSelf, 1 + _slot, &NativeDeletingDtor_##_clsName, PSDK_STRINGIFY(_vtblSym)); \
        func(_psdkSelf); \
    }

#define DECL_DTORCALL_PLT(_clsName, _addr) \
    static inline auto FuncProxy_dtor##_clsName = (void(*)(ThisClass*))(GetMainLibraryAddress() + _addr); \
    ~_clsName() asm("psdk_dtor_" PSDK_STRINGIFY(_clsName) "_plt"); \
    static inline __attribute__((used, visibility("hidden"))) PSDK_LIFETIME_RET(ThisClass) NativeDtor_##_clsName(ThisClass* _psdkSelf) \
        asm("psdk_dtor_" PSDK_STRINGIFY(_clsName) "_plt") \
    { FuncProxy_dtor##_clsName(_psdkSelf); PSDK_LIFETIME_RETURN(_psdkSelf); }

#define DECL_NEWCALL(_clsName, _sym) \
    static inline auto FuncProxy_opnew##_clsName = GetMainLibrarySymbol<_clsName*(*)(size_t size)>(PSDK_STRINGIFY(_sym)); \
    inline static _clsName* Instantiate(size_t size = sizeof(_clsName)) { return FuncProxy_opnew##_clsName(size); } \
    inline static void* operator new(size_t size) noexcept { return FuncProxy_opnew##_clsName(size); } \
    inline static void* operator new(size_t, void* memory) noexcept { return memory; }
    
#define DECL_DLCALL(_clsName, _sym) \
    static inline auto FuncProxy_opdel##_clsName = GetMainLibrarySymbol<void(*)(void* ptr)>(PSDK_STRINGIFY(_sym)); \
    inline void DeInstantiate() { FuncProxy_opdel##_clsName(this); } \
    inline static void operator delete(void* ptr) noexcept { FuncProxy_opdel##_clsName(ptr); } \
    inline static void operator delete(void*, void*) noexcept {}

#define DECL_VIRTUALCALL_BODY(_name, _vtblSym, _slot) \
    { \
        auto _psdkCall = GetNativeVirtual<ThisClass>(this, _slot, &FuncProxy_virtual_##_name##_##_slot, PSDK_STRINGIFY(_vtblSym));

#define DECL_VIRTUALCALL_HEAD(_clsName, _name, _vtblSym, _slot, _ret, ...) \
    static _ret FuncProxy_virtual_##_name##_##_slot(ThisClass* VA_ARGS(__VA_ARGS__)) \
        asm("psdk_vcall_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_slot)); \
    virtual __attribute__((used, noinline, visibility("hidden"))) _ret _name(__VA_ARGS__) \
        asm("psdk_vcall_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_slot)) \
    DECL_VIRTUALCALL_BODY(_name, _vtblSym, _slot)

#define DECL_VIRTUALCALL_CONST_HEAD(_clsName, _name, _vtblSym, _slot, _ret, ...) \
    static _ret FuncProxy_virtual_##_name##_##_slot(const ThisClass* VA_ARGS(__VA_ARGS__)) \
        asm("psdk_vcall_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_slot)); \
    virtual __attribute__((used, noinline, visibility("hidden"))) _ret _name(__VA_ARGS__) const \
        asm("psdk_vcall_" PSDK_STRINGIFY(_clsName) "_" PSDK_STRINGIFY(_slot)) \
    DECL_VIRTUALCALL_BODY(_name, _vtblSym, _slot)

#define DECL_VIRTUALCALL_TAIL(...) \
        return _psdkCall(this VA_ARGS(__VA_ARGS__)); \
    }

#define DECL_THISCALL_HEAD(_name, _sym, _ret, ...) \
    static inline auto FuncProxy_##_name = GetMainLibrarySymbol<_ret(*)(ThisClass* VA_ARGS(__VA_ARGS__))>(PSDK_STRINGIFY(_sym)); \
    inline _ret _name(__VA_ARGS__) {

#define DECL_THISCALL_NAMED_HEAD(_name, _alias, _sym, _ret, ...) \
    static inline auto FuncProxy_##_name = GetMainLibrarySymbol<_ret(*)(ThisClass* VA_ARGS(__VA_ARGS__))>(PSDK_STRINGIFY(_sym)); \
    inline _ret _alias(__VA_ARGS__) {

#define DECL_THISCALL_ADDR_HEAD(_name, _addr, _ret, ...) \
    static inline auto FuncProxy_##_name = (_ret(*)(ThisClass* VA_ARGS(__VA_ARGS__)))(GetMainLibraryAddress() + _addr); \
    inline _ret _name(__VA_ARGS__) {

#define DECL_THISCALL_ADDR_NAMED_HEAD(_name, _alias, _addr, _ret, ...) \
    static inline auto FuncProxy_##_name = (_ret(*)(ThisClass* VA_ARGS(__VA_ARGS__)))(GetMainLibraryAddress() + _addr); \
    inline _ret _alias(__VA_ARGS__) {

#define DECL_THISCALL_TAIL(_name, ...) \
        return FuncProxy_##_name(this VA_ARGS(__VA_ARGS__)); \
    }

#define CLASS_CONSTRUCT(_clsName, ...) \
    _clsName::FuncProxy_ctor##_clsName(__VA_ARGS__)

#define CLASS_DECONSTRUCT(_clsName, ...) \
    _clsName::FuncProxy_dtor##_clsName(__VA_ARGS__)

#define DECL_THISCALL_SIMPLE(_name, _sym, _ret) \
    DECL_THISCALL_HEAD(_name, _sym, _ret) \
    DECL_THISCALL_TAIL(_name)

#define DECL_THISCALL(_name, _sym, _ret, ...) \
    static inline auto FuncProxy_##_name = GetMainLibrarySymbol<_ret(*)(ThisClass* VA_ARGS(__VA_ARGS__))>(PSDK_STRINGIFY(_sym)); \
    template<class... _PsdkArgs> \
    inline _ret _name(_PsdkArgs&&... _psdkArgs) { \
        return FuncProxy_##_name(this, std::forward<_PsdkArgs>(_psdkArgs)...); \
    }

#define DECL_THISCALL_ADDR(_name, _addr, _ret, ...) \
    static inline auto FuncProxy_##_name = (_ret(*)(ThisClass* VA_ARGS(__VA_ARGS__)))(GetMainLibraryAddress() + _addr); \
    template<class... _PsdkArgs> \
    inline _ret _name(_PsdkArgs&&... _psdkArgs) { \
        return FuncProxy_##_name(this, std::forward<_PsdkArgs>(_psdkArgs)...); \
    }

#define DECL_FASTCALL_SIMPLE(_name, _sym, _ret, ...) \
    static inline auto _name = GetMainLibrarySymbol<_ret(*)(__VA_ARGS__)>(PSDK_STRINGIFY(_sym))

#define DECL_FASTCALL_SIMPLE_PLT(_name, _addr, _ret, ...) \
    static inline auto _name = (_ret(*)(__VA_ARGS__))(GetMainLibraryAddress() + _addr)

#define DECL_FASTCALL_SIMPLE_GLO(_name, _sym, _ret, ...) \
    inline auto _name = GetMainLibrarySymbol<_ret(*)(__VA_ARGS__)>(PSDK_STRINGIFY(_sym))

#define DECL_FASTCALL_SIMPLE_GLO_PLT(_name, _addr, _ret, ...) \
    inline auto _name = (_ret(*)(__VA_ARGS__))(GetMainLibraryAddress() + _addr)

#define GET_THISCALL_ADDR(_clsName, _name) \
    ( (uintptr_t)( _clsName::FuncProxy_##_name ) )

#define GET_CTOR_ADDR(_clsName) \
    ( (uintptr_t)( _clsName::FuncProxy_ctor##_clsName ) )

#define GET_DTOR_ADDR(_clsName) \
    ( (uintptr_t)( _clsName::FuncProxy_dtor##_clsName ) )

#endif // __AML_PSDK_BASE_H
