# GitHub Actions setup (phone-friendly)

This project now includes a GitHub Actions workflow. Codespaces is not required; GitHub-hosted runners perform the Android NDK build.

## 1. Create a private repository

1. Open https://github.com/new and sign in.
2. Name it `SDX-ARM64-Reconstruction`.
3. Choose **Private**. This project contains reverse-engineering material and a copy of the original ARM32 library. Do not publish those files unless you have explicit permission to distribute them.
4. Create the repository.

## 2. Upload the project

1. Download and extract the Stage 1 GitHub Actions-ready ZIP.
2. Open the new repository.
3. Choose **Add file → Upload files**.
4. Upload the extracted project's contents, including the hidden `.github/workflows/android-arm64.yml` file. If your mobile browser hides dot-directories, use GitHub's web editor to create that exact path and paste in the workflow from this ZIP.
5. Commit to the `main` branch.

## 3. Run the build

1. Open the repository's **Actions** tab.
2. Select **Build SDX ARM64 diagnostic plugin**.
3. Tap **Run workflow → Run workflow**.
4. Open the run and check the build log.
5. When successful, download the artifact named `sdx-arm64-stage1-...`.

## Expected output

`out/libs/arm64-v8a/libSDX_ARM64_STAGE1.so`

The workflow installs Android NDK r27d and runs the project's ELF verification script. This output is a Stage 1 diagnostic module, not a replacement for the original SDX plugin. Do not install it over the original library.

## If the build fails

Share the failed Actions log, especially the first compiler `error:` and the surrounding lines. Do not delete headers or randomly change compiler settings; fix the actual error first.
