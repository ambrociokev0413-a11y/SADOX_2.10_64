#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NDK_ROOT="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [[ -z "$NDK_ROOT" || ! -x "$NDK_ROOT/ndk-build" ]]; then
  echo "Set ANDROID_NDK_HOME (or ANDROID_NDK_ROOT) to an installed Android NDK root." >&2
  exit 2
fi
cd "$ROOT"
"$NDK_ROOT/ndk-build" NDK_PROJECT_PATH=. \
  APP_BUILD_SCRIPT=jni/Android.mk \
  NDK_APPLICATION_MK=jni/Application.mk \
  NDK_OUT=out/obj NDK_LIBS_OUT=out/libs
"$ROOT/tools/verify_arm64_output.sh" "$ROOT/out/libs/arm64-v8a/libSDX_ARM64_STAGE2.so"
