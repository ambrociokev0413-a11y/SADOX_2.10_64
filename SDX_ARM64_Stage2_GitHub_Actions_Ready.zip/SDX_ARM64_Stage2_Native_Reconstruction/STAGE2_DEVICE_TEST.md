# Stage 2 device validation

1. Build the Stage 2 artifact in GitHub Actions.
2. Install `libSDX_ARM64_STAGE2.so` as a separate test AML mod. Keep the original SDX library and existing graphics mod backed up and unchanged.
3. Launch GTA SA Android 2.10 and inspect the AML log for `SDX_ARM64_STAGE2`.
4. Confirm the log reports the three render symbols verified and the Cloud render hook installed.
5. Enter gameplay and wait for `Cloud render hook alive; original called`.
6. Test menu-to-game entry, pause/resume, and save reload. Stop testing if the game crashes or rendering becomes unstable. After closing the game process, disable or remove the test mod before the next launch.
7. Send the complete `SDX_ARM64_STAGE2` log. Do not report the visual effects as implemented yet; Stage 2 only proves that a verified render hook can observe the original cloud path.
