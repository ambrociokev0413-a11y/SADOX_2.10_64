#include <mod/amlmod.h>
#include <mod/logger.h>
#include "sdx/hook_registry.h"

#include <atomic>
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>

#if !defined(__aarch64__)
#error "SDX Stage 2 is ARM64-only. Build with APP_ABI=arm64-v8a."
#endif

static_assert(sizeof(void*) == 8, "AArch64 pointer width is required");
static_assert(sizeof(uintptr_t) == 8, "uintptr_t must be 64-bit");

MYMOD(net.sdx.arm64.stage2, SDX_ARM64_Stage2_Native_Reconstruction, 0.3.0, Community_Reconstruction)
NEEDGAME(com.rockstargames.gtasa);

namespace
{
    // Sample RVAs were read from the exact user-supplied GTA SA Android 2.10
    // ARM64 libGTASA.so and independently checked against its ELF symbol table.
    constexpr uintptr_t kCloudsRenderRva = 0x006C2AF8ULL;
    constexpr uintptr_t kInitialiseRenderWareRva = 0x0055B668ULL;
    constexpr uintptr_t kFrameEndRva = 0x004D8058ULL;

    using CloudsRenderFn = void (*)(void* self);
    static sdx::HookDescriptor g_cloudsRenderHook = {
        "CClouds::Render", "_ZN7CClouds6RenderEv", kCloudsRenderRva,
        0, nullptr, sdx::HookState::Unresolved
    };

    static std::atomic<uint64_t> g_cloudRenderCalls{0};
    static bool g_hookInstallAttempted = false;
    static bool g_stage2Loaded = false;

    static uintptr_t ResolveSymbol(IAML* api, uintptr_t gameBase, const char* name)
    {
        if (!api || !gameBase || !name || !*name)
            return 0;
        return api->GetSym(gameBase, name);
    }

    static bool IsInsideModule(uintptr_t address, uintptr_t base, uintptr_t length)
    {
        if (!address || !base || !length || base > UINTPTR_MAX - length)
            return false;
        return address >= base && address < base + length;
    }

    static void AuditLegacyDependencies(const uintptr_t gameBase)
    {
        struct Probe { const char* name; uintptr_t expectedRva; };
        static constexpr Probe probes[] = {
            {"_ZN8CFileMgr12fileDataAreaE", 0x00BC11C8ULL},
            {"_ZN14CRunningScript15StoreParametersEs", 0x003F22D0ULL},
            {"_Z11OS_FileReadPvS_i", 0x0031C190ULL},
            {"_ZN14CRunningScript17CollectParametersEs", 0x003F1FCCULL},
            {"_Z12OS_FileClosePv", 0x0031C04CULL},
            {"_Z11OS_FileSizePv", 0x0031C680ULL},
            {"_Z11NVLogEnable11ENVLogLevelh", 0x0032F070ULL},
            {"_Z18MoveColModelMemoryR9CColModelb", 0x004D6790ULL},
            {"_Z11NVHHDDSLoadPKci", 0x0032B308ULL},
            {"_ZN8CProfile10InitialiseEv", 0x004F2594ULL},
            {"_Z11NvQuatNLerpPfPKfS1_f", 0x00331488ULL},
            {"_ZN14CRunningScript26GetPointerToScriptVariableEh", 0x003F2654ULL},
            {"_ZN8CFileMgr17SetDirMyDocumentsEv", 0x004D29BCULL},
            {"_Z18_rwCameraValRenderP8RwCamera", 0x0026E458ULL},
            {"_Z15nv_load_programPKcS0_", 0x0033170CULL},
            {"_ZN8CFileMgr8OpenFileEPKcS1_", 0x004D2B74ULL},
        };

        unsigned found = 0;
        unsigned exact = 0;
        for (const Probe& probe : probes)
        {
            const uintptr_t address = ResolveSymbol(aml, gameBase, probe.name);
            if (!address)
                continue;
            ++found;
            if (address - gameBase == probe.expectedRva)
                ++exact;
        }
        logger->Info("Legacy SDX dependency audit: %u/%u symbols resolved; %u match the supplied 2.10 sample RVAs",
            found, static_cast<unsigned>(sizeof(probes) / sizeof(probes[0])), exact);
    }

    static bool VerifyRenderAnchors(const uintptr_t gameBase, const uintptr_t gameLength)
    {
        struct Anchor { const char* label; const char* symbol; uintptr_t expectedRva; };
        static constexpr Anchor anchors[] = {
            {"RenderWare initialization", "_ZN5CGame20InitialiseRenderWareEv", kInitialiseRenderWareRva},
            {"end-of-frame callback", "_Z19DoRWStuffEndOfFrameb", kFrameEndRva},
        };

        bool allGood = true;
        for (const Anchor& anchor : anchors)
        {
            const uintptr_t address = ResolveSymbol(aml, gameBase, anchor.symbol);
            if (!IsInsideModule(address, gameBase, gameLength))
            {
                logger->Error("Stage 2 anchor unavailable: %s (%s)", anchor.label, anchor.symbol);
                allGood = false;
                continue;
            }

            const uintptr_t actualRva = address - gameBase;
            if (actualRva != anchor.expectedRva)
            {
                logger->Error("Stage 2 anchor offset mismatch: %s expected=+0x%llX actual=+0x%llX",
                    anchor.label,
                    static_cast<unsigned long long>(anchor.expectedRva),
                    static_cast<unsigned long long>(actualRva));
                allGood = false;
                continue;
            }

            logger->Info("Stage 2 anchor verified: %s at +0x%llX", anchor.label,
                static_cast<unsigned long long>(actualRva));
        }
        return allGood;
    }

    static void HookedCloudsRender(void* self)
    {
        const auto original = reinterpret_cast<CloudsRenderFn>(g_cloudsRenderHook.original);
        if (!original)
            return;

        // Preserve the original game renderer. Stage 2 only observes that the
        // cloud path ran; it does not modify cloud data, shaders, or RenderWare state.
        original(self);

        const uint64_t count = g_cloudRenderCalls.fetch_add(1, std::memory_order_relaxed) + 1;
        if (count == 1 || (count % 600) == 0)
        {
            logger->Info("Cloud render hook alive; original called; observations=%llu",
                static_cast<unsigned long long>(count));
        }
    }

    static bool InstallCloudRenderHook(const uintptr_t gameBase, const uintptr_t gameLength)
    {
        if (g_hookInstallAttempted)
            return g_cloudsRenderHook.state == sdx::HookState::Installed;
        g_hookInstallAttempted = true;

        if (!sdx::ResolveVerifiedSymbol(aml, gameBase, gameLength, g_cloudsRenderHook))
        {
            logger->Error("Cloud hook not installed: %s (%s)",
                g_cloudsRenderHook.label, sdx::HookStateName(g_cloudsRenderHook.state));
            return false;
        }

        logger->Info("Cloud target verified: %s at +0x%llX",
            g_cloudsRenderHook.label,
            static_cast<unsigned long long>(g_cloudsRenderHook.address - gameBase));

        if (!sdx::InstallVerifiedHook(aml, g_cloudsRenderHook,
                reinterpret_cast<void*>(&HookedCloudsRender)))
        {
            logger->Error("Cloud hook installation failed: %s", sdx::HookStateName(g_cloudsRenderHook.state));
            return false;
        }

        logger->Info("Cloud render hook installed through AML; original trampoline=%p",
            g_cloudsRenderHook.original);
        return true;
    }
}

ON_MOD_PRELOAD()
{
    if (logger)
    {
        logger->SetTag("SDX_ARM64_STAGE2");
        logger->Info("Stage 2 AArch64 hook foundation preload reached");
    }
}

ON_MOD_LOAD()
{
    if (logger)
        logger->SetTag("SDX_ARM64_STAGE2");

    if (!aml || !logger)
    {
        if (logger) logger->Error("AML interface unavailable; Stage 2 remains inactive");
        return;
    }

    if (g_stage2Loaded)
    {
        logger->Info("Stage 2 already initialized; duplicate load ignored");
        return;
    }

    const char* currentGame = aml->GetCurrentGame();
    logger->Info("AML game identifier: %s", currentGame ? currentGame : "<null>");

    const uintptr_t gameBase = aml->GetLib("libGTASA.so");
    const uintptr_t gameLength = aml->GetLibLength("libGTASA.so");
    if (!gameBase || !gameLength)
    {
        logger->Error("libGTASA.so not ready; no hook attempted");
        return;
    }

    logger->Info("AArch64 libGTASA base=%p length=0x%llX",
        reinterpret_cast<void*>(gameBase),
        static_cast<unsigned long long>(gameLength));

    AuditLegacyDependencies(gameBase);
    const bool anchorsVerified = VerifyRenderAnchors(gameBase, gameLength);
    if (!anchorsVerified)
    {
        logger->Error("Render anchors do not match the supplied GTA SA 2.10 sample; Stage 2 hook blocked");
        return;
    }

    const bool hookInstalled = InstallCloudRenderHook(gameBase, gameLength);
    if (!hookInstalled)
    {
        logger->Error("Stage 2 loaded in audit-only mode; cloud hook was not installed");
        g_stage2Loaded = true;
        return;
    }

    g_stage2Loaded = true;
    logger->Info("Stage 2 ready: AArch64 symbol validation and original-preserving CloudWorks hook foundation active");
}

ON_MOD_UNLOAD()
{
    if (logger)
    {
        logger->Info("SDX Stage 2 unload requested. IAML::Hook does not return a removable hook handle in this API; restart the game process before disabling or removing this test module.");
    }
}
