LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := SDX_ARM64_STAGE2
LOCAL_CPP_EXTENSION := .cpp .cc
LOCAL_SRC_FILES := main.cpp logger.cpp sdx/hook_registry.cpp
LOCAL_CXXFLAGS += -O2 -DNDEBUG -std=c++17 -fexceptions -frtti -Wall -Wextra
LOCAL_C_INCLUDES += $(LOCAL_PATH)
LOCAL_LDLIBS += -llog -ldl -landroid
include $(BUILD_SHARED_LIBRARY)
