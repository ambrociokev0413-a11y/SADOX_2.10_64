#include "hook_registry.h"

#include <time.h>
#include <mod/iaml.h>
#include <limits>

namespace sdx
{
    bool ResolveVerifiedSymbol(IAML* aml, uintptr_t moduleBase, uintptr_t moduleLength,
        HookDescriptor& hook)
    {
        hook.address = 0;
        hook.original = nullptr;
        hook.state = HookState::Unresolved;

        if (!aml || !moduleBase || !moduleLength || !hook.symbol || !*hook.symbol)
        {
            hook.state = HookState::Missing;
            return false;
        }

        if (moduleBase > (std::numeric_limits<uintptr_t>::max() - moduleLength))
        {
            hook.state = HookState::OutsideModule;
            return false;
        }

        const uintptr_t moduleEnd = moduleBase + moduleLength;
        const uintptr_t address = aml->GetSym(moduleBase, hook.symbol);
        if (!address)
        {
            hook.state = HookState::Missing;
            return false;
        }

        if (address < moduleBase || address >= moduleEnd)
        {
            hook.state = HookState::OutsideModule;
            return false;
        }

        const uintptr_t actualRva = address - moduleBase;
        if (hook.expectedRva && actualRva != hook.expectedRva)
        {
            hook.address = address;
            hook.state = HookState::OffsetMismatch;
            return false;
        }

        hook.address = address;
        hook.state = HookState::Verified;
        return true;
    }

    bool InstallVerifiedHook(IAML* aml, HookDescriptor& hook, void* detour)
    {
        if (!aml || !detour || hook.state != HookState::Verified || !hook.address)
            return false;

        void* original = nullptr;
        const bool installed = aml->Hook(reinterpret_cast<void*>(hook.address), detour, &original);
        if (!installed || !original)
        {
            hook.original = original;
            hook.state = HookState::InstallFailed;
            return false;
        }

        hook.original = original;
        hook.state = HookState::Installed;
        return true;
    }

    const char* HookStateName(HookState state)
    {
        switch (state)
        {
            case HookState::Unresolved: return "unresolved";
            case HookState::Verified: return "verified";
            case HookState::Installed: return "installed";
            case HookState::Missing: return "missing";
            case HookState::OutsideModule: return "outside-module";
            case HookState::OffsetMismatch: return "offset-mismatch";
            case HookState::InstallFailed: return "install-failed";
            default: return "unknown";
        }
    }
}
