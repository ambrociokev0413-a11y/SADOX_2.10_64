#pragma once

#include <cstdint>
class IAML;

namespace sdx
{
    enum class HookState : uint8_t
    {
        Unresolved,
        Verified,
        Installed,
        Missing,
        OutsideModule,
        OffsetMismatch,
        InstallFailed
    };

    struct HookDescriptor
    {
        const char* label;
        const char* symbol;
        uintptr_t expectedRva;
        uintptr_t address;
        void* original;
        HookState state;
    };

    bool ResolveVerifiedSymbol(IAML* aml, uintptr_t moduleBase, uintptr_t moduleLength,
        HookDescriptor& hook);
    bool InstallVerifiedHook(IAML* aml, HookDescriptor& hook, void* detour);
    const char* HookStateName(HookState state);
}
