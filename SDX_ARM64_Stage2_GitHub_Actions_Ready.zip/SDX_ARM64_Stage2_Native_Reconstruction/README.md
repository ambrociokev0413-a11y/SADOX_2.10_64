# SDX ARM64 Stage 2 — Native Hook Foundation

Stage 2 advances the Stage 1 diagnostic library with a verified AArch64 hook registry and one AML-managed, original-preserving hook at GTA SA Android 2.10's `CClouds::Render` entry.

**This is not the finished SDX graphics port.** It does not yet change volumetric clouds or any other rendering effect. The immediate purpose is to prove that the exact target build can be identified, that AML can install a native hook safely, and that the original cloud renderer still runs.

See `STAGE2_IMPLEMENTATION_REPORT.md` and `STAGE2_DEVICE_TEST.md` before installing.
