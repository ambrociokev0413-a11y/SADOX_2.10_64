# SDX ARM64 Reconstruction — Stage 2

## Implemented

- Added a reusable verified-symbol / hook registry (`jni/sdx/hook_registry.*`).
- A hook target is resolved by its mangled symbol, checked to lie inside `libGTASA.so`, and required to match the sample GTA SA Android 2.10 ARM64 ELF virtual-address offset before AML is allowed to install it.
- Verified the cloud-render entry `_ZN7CClouds6RenderEv` at RVA `0x006C2AF8` in the supplied target library.
- Verified RenderWare lifecycle anchors `_ZN5CGame20InitialiseRenderWareEv` at RVA `0x0055B668` and `_Z19DoRWStuffEndOfFrameb` at RVA `0x004D8058`.
- Added one AML-managed AArch64 hook on `CClouds::Render`. The detour calls the original trampoline once, then records a low-frequency diagnostic counter.
- Kept the original Stage 1 dependency symbol audit.
- Updated the native build target to `libSDX_ARM64_STAGE2.so`.

## Explicit safety boundary

Stage 2 is a hook-foundation and runtime-path verification build, not a graphics enhancement release. It does **not** patch cloud parameters, replace shaders, alter RenderWare state, run legacy ARM32 patches, modify the script VM, or change game memory directly. The cloud hook is installed only if all required render anchors match the supplied GTA SA 2.10 ARM64 sample offsets.

The hook is installed through AML's `IAML::Hook` API. No handwritten AArch64 trampoline or instruction patcher is included. AML manages hook installation and trampoline creation. The legacy `IAML::Hook` API used here does not return a `PHookHandle`; therefore the test module should remain loaded for the game process lifetime, and the game process must be restarted before disabling or removing the test module.

## Still required

1. Build with Android NDK 27.2.12479018 in GitHub Actions.
2. Install only as a test AML mod on the target device; do not replace the original `libSDX.so` yet.
3. Capture the `SDX_ARM64_STAGE2` log through game startup, entering gameplay, cloud rendering, pause/resume, and save reload.
4. Confirm that the cloud hook counter appears and the original rendering remains stable before implementing any visual changes.


## Stage 2.1 ABI correction

The first Stage 2 test artifact compiled successfully, but review identified that `_ZN7CClouds6RenderEv` is a non-static C++ member function. Its AArch64 entry ABI carries the `this` pointer in `x0`. The detour and original trampoline are therefore now typed as `void (*)(void* self)` and forward that pointer unchanged. Rebuild this corrected source before any device test; the earlier Stage 2 binary should not be installed for runtime testing.
